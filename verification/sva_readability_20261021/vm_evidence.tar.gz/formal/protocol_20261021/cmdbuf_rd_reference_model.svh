// Included inside cmdbuf_rd_port_sva; all state below is checker-local.
// 参考模型只读顶层端口，不读 DUT entry、窗口、选择结果或 done 标记。
// m_live/m_sent/m_done = 已接收 / 已成功发射 / 已捕获 MEM。
// m_age = 全局接收年龄排名；0 最老。m_* 不是 DUT 层次路径。
// m_due/m_due_e = 固定 4 拍返回日历；m_attempt/m_attempt_e = 请求流水项。
// head/eligible = 各源最老事务 / 已完成且 ready；m_rr = 下次 RR 起点。
// pending -> pool -> window -> candidate -> selected 是预选组合计算。
// 成功当拍从 pool 扣除、补入原第 6 项；失败不扣除，可立即重选。

    reg [8:0] m_live, m_sent, m_done, m_pc;
    reg [3:0] m_due;
    // Independent scoreboard: a compact rank (0=oldest) instead of the DUT's
    // pairwise age matrix. It never reads DUT window/done/selection to decide
    // the expected command. The lowest free logical slot is an implementation detail of this checker.
    // It does not predict or assert the physical allocation slot of the DUT.
    reg [17:0] m_addr [0:8];
    reg [1:0] m_src [0:8], m_err [0:8];
    reg [7:0] m_id [0:8];
    reg [4:0] m_port [0:8];
    reg [3:0] m_age [0:8];
    reg [127:0] m_data [0:8];
    reg [1:0] m_rr;
    reg m_attempt;
    reg [3:0] m_attempt_e;
    reg [3:0] m_due_e [0:3];
    wire mem_capture_due = m_due[3];
    wire [3:0] mem_capture_slot = m_due_e[3];
    reg [8:0] pending, pool, window, idle, candidate, selected;
    reg [3:0] select_e;
    wire select_valid = |selected;
    reg [3:0] head [0:2];
    reg [2:0] head_valid, eligible, expected_rvalid;
    reg model_retire;
    reg [1:0] winner;
    reg [3:0] rsp_e, alloc_e;
    reg free_found;
    reg [2:0] expected_ready;
    integer used, waiting, shared_cost, quota_cost;
    integer occ [0:2];
    integer after_occ [0:2];
    integer used_after, shared_after;
    integer ranks [0:8];
    integer best_age, scan;
    integer i, j, x, off;

    always @* begin
        // 1. 统计当前占用以及预留预算。
        used = 0; waiting = 0; shared_cost = 0; quota_cost = 0;
        for (x=0; x<3; x=x+1) occ[x] = 0;
        for (i=0; i<9; i=i+1) begin
            if (m_live[i]) begin
                used = used+1;
                if (!m_sent[i]) waiting = waiting+1;
                if (m_src[i]<3) occ[m_src[i]] = occ[m_src[i]]+1;
            end
        end
        for (x=0; x<3; x=x+1) begin
            if (occ[x]>0) shared_cost = shared_cost+occ[x]-1;
            quota_cost = quota_cost+((occ[x]>0)?occ[x]:1);
        end
        // Find the oldest live head first; only then consult done and ready.
        head_valid = 0; eligible = 0;
        for (x=0; x<3; x=x+1) begin
            head[x] = 0; best_age = 9;
            for (i=0; i<9; i=i+1)
                if (m_live[i] && m_src[i]==x && m_age[i]<best_age) begin
                    head_valid[x]=1; head[x]=i; best_age=m_age[i];
                end
            if (head_valid[x]) eligible[x] = m_done[head[x]] && rready[x];
        end
        // 2. 从 RR 起点扫描，最多选择一个可响应队头。
        expected_rvalid=0; winner=0; rsp_e=0; scan=0;
        for (off=0; off<3; off=off+1) begin
            scan=m_rr+off; if(scan>=3) scan=scan-3;
            if (expected_rvalid==0 && eligible[scan]) begin
                expected_rvalid[scan]=1; winner=scan; rsp_e=head[scan];
            end
        end
        if(!rst_n) expected_rvalid=0;
        model_retire = |expected_rvalid;
        // 3. 先计入本拍 R 回收，再计算各源 AR ready 与逻辑分配槽。
        used_after=0; shared_after=0;
        for(x=0;x<3;x=x+1) begin
            after_occ[x]=occ[x]-((model_retire && winner==x)?1:0);
            used_after=used_after+after_occ[x];
            if(after_occ[x]>0) shared_after=shared_after+after_occ[x]-1;
        end
        expected_ready=0;
        for(x=0;x<3;x=x+1)
            expected_ready[x]=rst_n && used_after<9 &&
                               (after_occ[x]==0 || shared_after<6);
        alloc_e=0; free_found=0;
        for(i=0;i<9;i=i+1)
            if(!free_found && (!m_live[i] || (model_retire && rsp_e==i))) begin
                free_found=1; alloc_e=i;
            end
        // 4. 只从最老五条未成功发射命令中筛选空闲半区，再选最老。
        pending=m_live & ~m_sent;
        pool=pending;
        // 6B: remove only a successful current issue from the rank pool.
        if(issue_fire && m_attempt_e<9) pool[m_attempt_e]=0;
        window=0; idle=0; candidate=0; selected=0; select_e=0;
        for(i=0;i<9;i=i+1) begin
            ranks[i]=0;
            for(j=0;j<9;j=j+1)
                if(pool[j] && m_age[j]<m_age[i]) ranks[i]=ranks[i]+1;
            window[i]=pool[i] && ranks[i]<5;
            idle[i]=!rd_mem_status[m_addr[i][5:3]][m_addr[i][6]];
            // Failed attempts retain their age and may be selected immediately.
            candidate[i]=window[i] && idle[i];
        end
        best_age=9;
        for(i=0;i<9;i=i+1)
            if(candidate[i] && m_age[i]<best_age) begin
                best_age=m_age[i]; select_e=i;
            end
        if(best_age<9) selected[select_e]=1;
    end

    integer e,k;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            m_live<=0; m_sent<=0; m_done<=0; m_pc<=0; m_rr<=0;
            m_attempt<=0; m_attempt_e<=0; m_due<=0;
            for(k=0;k<4;k=k+1) m_due_e[k]<=0;
            for(e=0;e<9;e=e+1) begin
                m_addr[e]<=0; m_src[e]<=0; m_err[e]<=0; m_id[e]<=0;
                m_port[e]<=0; m_age[e]<=0; m_data[e]<=0;
            end
        end else begin
            // N 拍成功发射 -> N+4 拍捕获；done 在捕获沿后更新，R 最早 N+5。
            m_due<={m_due[2:0],issue_fire};
            m_due_e[0]<=issue_fire?m_attempt_e:4'd0;
            for(k=1;k<4;k=k+1) m_due_e[k]<=m_due[k-1]?m_due_e[k-1]:4'd0;
            m_attempt<=select_valid;
            m_attempt_e<=select_valid?select_e:4'd0;
            if(model_retire) m_rr<=(winner==2)?2'd0:winner+2'd1;
            for(e=0;e<9;e=e+1) begin
                // 同拍回收并复用同一逻辑槽时，新事务写入优先。
                if(ar_fire && alloc_e==e) begin
                    m_live[e]<=1; m_sent[e]<=0; m_done[e]<=0; m_pc[e]<=0;
                    m_addr[e]<=araddr; m_src[e]<=src; m_err[e]<=arresp;
                    m_id[e]<=arid; m_port[e]<=ar_port_id;
                    m_age[e]<=used-(model_retire?1:0); m_data[e]<=0;
                end else if(model_retire && rsp_e==e) begin
                    m_live[e]<=0; m_sent[e]<=0; m_done[e]<=0; m_pc[e]<=0;
                    m_addr[e]<=0; m_src[e]<=0; m_err[e]<=0; m_id[e]<=0;
                    m_port[e]<=0; m_age[e]<=0; m_data[e]<=0;
                end else begin
                    if(model_retire && m_live[e] && m_age[e]>m_age[rsp_e])
                        m_age[e]<=m_age[e]-1'b1;
                    if(issue_fire && m_attempt_e==e) m_sent[e]<=1;
                    if(mem_capture_due && mem_capture_slot==e) begin
                        m_done[e]<=1; m_data[e]<=mem_rdata; m_pc[e]<=pc_err;
                    end
                end
            end
        end
    end

    wire [7:0] expected_req=(rst_n && m_attempt)?(8'b1<<m_addr[m_attempt_e][5:3]):8'd0;
    wire [11:0] expected_addr=(rst_n && m_attempt)?m_addr[m_attempt_e][17:6]:12'd0;
    wire [1:0] expected_resp=(m_err[rsp_e]==2'b11)?2'b11:(m_pc[rsp_e]?2'b01:2'b00);


    // [REF_MODEL] 以下状态只用于记录覆盖见证，不增加输入约束。
    // Covers confirm the corrected cases are reachable under E06.
    reg retry_selected, refill_selected, nonhead_refill_selected;
    reg [11:0] last_retry_addr, last_refill_addr;
    reg [7:0] last_retry_req, last_refill_req;
    reg [2:0] blocked_streak;
    reg [3:0] issue_streak;
    integer selected_old_rank;
    integer c;
    always @* begin
        selected_old_rank=0;
        for(c=0;c<9;c=c+1)
            if(pending[c] && m_age[c]<m_age[select_e]) selected_old_rank=selected_old_rank+1;
    end
    wire blocked_six=waiting>=6 && (window & idle)==0 && (pool & ~window & idle)!=0 && !m_attempt;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            retry_selected<=0;refill_selected<=0;nonhead_refill_selected<=0;
            last_retry_addr<=0;last_refill_addr<=0;last_retry_req<=0;last_refill_req<=0;
            blocked_streak<=0;issue_streak<=0;
        end else begin
            retry_selected<=m_attempt && !issue_fire && select_valid && select_e==m_attempt_e;
            refill_selected<=issue_fire && select_valid && selected_old_rank==5;
            nonhead_refill_selected<=issue_fire && select_valid && selected_old_rank==5 && ranks[m_attempt_e]!=0;
            last_retry_addr<=expected_addr;last_retry_req<=expected_req;
            last_refill_addr<=m_addr[select_e][17:6];
            last_refill_req<=8'b1<<m_addr[select_e][5:3];
            if(blocked_six) begin if(blocked_streak!=7)blocked_streak<=blocked_streak+1'b1;end
            else blocked_streak<=0;
            if(issue_fire) begin if(issue_streak!=15)issue_streak<=issue_streak+1'b1;end
            else issue_streak<=0;
        end
    end
