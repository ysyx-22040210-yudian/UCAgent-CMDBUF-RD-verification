// Included inside sources[g]. No DUT-internal signals are observed.
// 独立 FIFO：source_ar 入队；只有 source_r 才出队。
// oldest 指向最早接受且尚未返回的命令，与发射/MEM 返回顺序无关。
// 命令3先到 OTB 不能移动队头；同拍出入时，新项追加到剩余项之后。
// order_phase 仅记录 cover：0等待三项，1等待3先发，2等待3先捕获，
// 3等待R1，4等待R2，5等待R3；它不约束 DUT 或环境。

        reg [1:0] bypass_count;
        always @(posedge clk or negedge rst_n)
            if(!rst_n) bypass_count<=0;
            else if(!eligible[g] || rvalid[g]) bypass_count<=0;
            else if(r_fire) bypass_count<=bypass_count+1'b1;

        // [REF_MODEL] Explicit per-XAU acceptance-order FIFO.
        // Push ONLY on accepted AR for this source. Pop ONLY on actual R
        // handshake for this source, never on issue or MEM completion.
        // Tokens are checker-local transaction slots, NOT arid or DUT entries.
        // R payload is checked against this FIFO head independently of RR choice.
        reg [3:0] order_count;
        reg [3:0] order_slot [0:8];
        wire source_ar = ar_fire && src==g;
        wire source_r = rvalid[g] && rready[g];
        wire [3:0] oldest = order_slot[0];
        wire oldest_valid = order_count!=0 && oldest<9 &&
                            m_live[oldest] && m_src[oldest]==g;
        wire [1:0] oldest_resp = m_err[oldest]==2'b11 ? 2'b11 :
                                (m_pc[oldest] ? 2'b01 : 2'b00);
        wire head_payload_matches = oldest_valid &&
            {raddr,rid,r_port_id,rdata,rresp} ==
            {m_addr[oldest][2:0],m_id[oldest],m_port[oldest],m_data[oldest],oldest_resp};
        integer qi;
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                order_count<=0;
                for(qi=0;qi<9;qi=qi+1) order_slot[qi]<=0;
            end else begin
                order_count<=order_count+{3'b0,source_ar}-{3'b0,source_r};
                if(source_r) begin
                    for(qi=0;qi<8;qi=qi+1) order_slot[qi]<=order_slot[qi+1];
                    order_slot[8]<=0;
                end
                // Simultaneous pop/push appends after the surviving old items.
                if(source_ar && order_count>=source_r &&
                   (order_count-{3'b0,source_r})<9)
                    order_slot[order_count-{3'b0,source_r}]<=alloc_e;
            end
        end

        // [REF_MODEL] Witness: ar_fire 1,2,3; issue/capture 3 before 1/2;
        // wait at the source head; eventually return complete payloads 1,2,3.
        // No input restriction is added by this monitor.
        reg [2:0] order_phase;
        reg [3:0] first_token, second_token, third_token;
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                order_phase<=0; first_token<=0; second_token<=0; third_token<=0;
            end else begin
                case(order_phase)
                    0: if(order_count>=3 &&
                          !m_sent[order_slot[0]] && !m_sent[order_slot[1]] &&
                          !m_sent[order_slot[2]] && !source_r) begin
                        first_token<=order_slot[0]; second_token<=order_slot[1];
                        third_token<=order_slot[2]; order_phase<=1;
                    end
                    1: begin
                        if(source_r) order_phase<=0;
                        else if(issue_fire && m_attempt_e==third_token &&
                                !m_sent[first_token] && !m_sent[second_token])
                            order_phase<=2;
                        else if(issue_fire && (m_attempt_e==first_token || m_attempt_e==second_token))
                            order_phase<=0;
                    end
                    2: begin
                        if(source_r) order_phase<=0;
                        else if(mem_capture_due && mem_capture_slot==third_token &&
                                !m_done[first_token] && !m_done[second_token])
                            order_phase<=3;
                    end
                    3: if(source_r)
                        order_phase<=(oldest==first_token && head_payload_matches)?3'd4:3'd0;
                    4: if(source_r)
                        order_phase<=(oldest==second_token && head_payload_matches)?3'd5:3'd0;
                    5: if(source_r) order_phase<=0;
                    default: order_phase<=0;
                endcase
            end
        end
