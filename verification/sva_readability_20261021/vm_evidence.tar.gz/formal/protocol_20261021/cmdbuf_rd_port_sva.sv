// CMDBUF RD 顶层端口 SVA 阅读入口
// 1 环境假设 -> 2 端口/历史检查 -> 3 发射与 RR -> 4 单 XAU 保序
// -> 5 参考模型自检 -> 6 业务场景覆盖。
// 所有属性显式写出 posedge clk / disable iff (!rst_n)，不检查复位协议。
// |-> 表示同一采样拍；此文件不把本拍义务推迟到下一拍。
// [NO_REF_MODEL_PORTS] 仅本拍端口；[NO_REF_MODEL_HISTORY] 仅端口历史；
// [NO_REF_MODEL_ENV] 环境责任；[REF_MODEL] 依赖事务参考记录；
// [MODEL_SELF_CHECK] 检查器自洽检查，不等于验证 DUT 物理 entry。
// 属性标签保持不变，以便对照测试点、反例和历史结果。
`default_nettype none
module cmdbuf_rd_port_sva (
    input wire clk,
    input wire rst_n,
    // AR: one shared command, source selected by src.
    input wire arvalid,
    input wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    // R: one shared payload, destination selected by rvalid.
    input wire [2:0] rvalid, rready,
    input wire [127:0] rdata,
    input wire [7:0] rid,
    input wire [4:0] r_port_id,
    input wire [2:0] raddr,
    input wire [1:0] rresp,
    // Arbit: issue succeeds only with req and BOTH grants.
    input wire [7:0] req,
    input wire [11:0] arb_addr,
    input wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt, rw_rd_gnt,
    // MEM: status[bank][half], 0=idle, 1=busy; one merged data return.
    input bit [1:0] rd_mem_status [7:0],
    input wire [127:0] mem_rdata,
    input wire pc_err

);

    // Public-port events. These names always mean actual observed handshakes.
    wire ar_fire = arvalid && (src < 3) &&
                   ((src < 3) ? arready[src] : 1'b0);
    wire issue_fire = |(req & ar_rd_gnt & rw_rd_gnt);
    wire r_fire = |(rvalid & rready);

    // 参考状态的更新细节单独存放；阅读属性时不必先展开模型。
    `include "cmdbuf_rd_reference_model.svh"

    // ----------------------------------------------------------------
    // 1. 环境 assume：只描述已对齐的输入契约
    // ----------------------------------------------------------------
    // [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 有效 AR 必须来自 XAU0、XAU1 或 XAU2；无效拍不约束 src。
    E03_SRC: assume property (
        @(posedge clk) disable iff (!rst_n)
        (arvalid)
        |-> (src < 2'd3)
    );

    // [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 有效 AR 的上游状态只允许正常 00 或地址越界 11。
    E04_ARRESP: assume property (
        @(posedge clk) disable iff (!rst_n)
        (arvalid)
        |-> (arresp == 2'b00 || arresp == 2'b11)
    );

    // [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 三个来源都不能接收时，上游不得发送有效 AR。
    E05_ZERO_READY: assume property (
        @(posedge clk) disable iff (!rst_n)
        (arready == 3'b000)
        |-> (!arvalid)
    );

    genvar bank_env;
    generate for (bank_env = 0; bank_env < 8; bank_env = bank_env + 1) begin : status_contract
        wire requested_half_busy = rd_mem_status[bank_env][arb_addr[0]];
        // [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 本拍该 Bank 双 grant 成功时，被访问的奇偶半区本拍必须报告占用。
        E06_SUCCESS_BUSY: assume property (
            @(posedge clk) disable iff (!rst_n)
            (req[bank_env] && ar_rd_gnt[bank_env] && rw_rd_gnt[bank_env])
            |-> (requested_half_busy)
        );

    end endgenerate

    // ----------------------------------------------------------------
    // 2. 无事务参考模型的 assert：端口合法性与计数递推
    // ----------------------------------------------------------------
    // [NO_REF_MODEL_HISTORY] 只保存上拍公开 pending_cnt，不复制 entry。
    reg [3:0] last_pending;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            last_pending <= 0;
        else
            last_pending <= pending_cnt;
    end

    // x & (x-1) == 0 与 onehot0 等价，允许无请求的全零值。
    // [NO_REF_MODEL_PORTS] 下游每拍最多请求一个 Bank；全零合法。
    A_REQ_ONEHOT: assert property (
        @(posedge clk) disable iff (!rst_n)
        (req & (req-8'd1)) == 0
    );

    // [NO_REF_MODEL_PORTS] 共享 R 负载每拍最多发往一个 XAU；全零合法。
    A_R_ONEHOT: assert property (
        @(posedge clk) disable iff (!rst_n)
        (rvalid & (rvalid-3'd1)) == 0
    );

    // [NO_REF_MODEL_PORTS] rvalid 只能在对应 rready 已经为 1 的通道拉高。
    A_R_READY: assert property (
        @(posedge clk) disable iff (!rst_n)
        (rvalid & ~rready) == 0
    );

    // [NO_REF_MODEL_PORTS] 待发命令数不能超过共享容量 9。
    A_PENDING_RANGE: assert property (
        @(posedge clk) disable iff (!rst_n)
        pending_cnt <= 9
    );

    // [NO_REF_MODEL_HISTORY] 本拍计数 = 上拍计数 + 本拍 AR 握手 - 本拍成功发射。
    A_PENDING_RECURRENCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        pending_cnt == (last_pending+{3'b0,ar_fire}-{3'b0,issue_fire})
    );

    // ----------------------------------------------------------------
    // 3. 依赖参考记录的 assert：容量、乱序发射、RR 与有效负载
    // ----------------------------------------------------------------
    // [REF_MODEL] arready 必须符合容量预留规则，并计入本拍 R 回收。
    A_READY: assert property (
        @(posedge clk) disable iff (!rst_n)
        arready == expected_ready
    );

    // [REF_MODEL] 待发数含本拍新 AR，扣除本拍双 grant 成功；仲裁失败不扣除。
    A_PENDING: assert property (
        @(posedge clk) disable iff (!rst_n)
        pending_cnt == (waiting+(ar_fire?1:0)-(issue_fire?1:0))
    );

    // [REF_MODEL] 当前 req 必须对应上一拍窗口内选出的最老可发命令。
    A_REQ: assert property (
        @(posedge clk) disable iff (!rst_n)
        req == expected_req
    );

    // [REF_MODEL] req 有效时检查完整下游地址 araddr[17:6]；无效时不检查负载。
    A_ARB_ADDR: assert property (
        @(posedge clk) disable iff (!rst_n)
        (req != 8'b0)
        |-> (arb_addr == expected_addr)
    );

    // [REF_MODEL] 只在 ready 且最老队头已完成的来源间按 RR 选择。
    A_RR_CHOICE: assert property (
        @(posedge clk) disable iff (!rst_n)
        rvalid == expected_rvalid
    );

    // [REF_MODEL] R 握手时，ID、port_id、地址低三位必须属于同一预期事务。
    A_R_METADATA: assert property (
        @(posedge clk) disable iff (!rst_n)
        (r_fire)
        |-> ((rid == m_id[rsp_e] && r_port_id == m_port[rsp_e] && raddr == m_addr[rsp_e][2:0]))
    );

    // [REF_MODEL] R 错误状态来自预期事务；地址越界优先于奇偶校验异常。
    A_R_RESP: assert property (
        @(posedge clk) disable iff (!rst_n)
        (r_fire)
        |-> (rresp == expected_resp)
    );

    // [REF_MODEL] R 数据必须等于预期事务在成功发射后第 4 拍捕获的数据。
    A_R_DATA: assert property (
        @(posedge clk) disable iff (!rst_n)
        (r_fire)
        |-> (rdata == m_data[rsp_e])
    );

    // ----------------------------------------------------------------
    // 4. 单 XAU 顺序：AR 接收 FIFO 的队头必须先返回
    // ----------------------------------------------------------------
    genvar g, h;
    generate for (g = 0; g < 3; g = g + 1) begin : sources
        // 本地状态只记录该源接收顺序以及 cover 进度。
        `include "cmdbuf_rd_xau_order_model.svh"

        // [REF_MODEL] 该源持续可响应且已被另外两次响应越过时，本拍必须轮到它。
        A_RR_BOUND: assert property (
            @(posedge clk) disable iff (!rst_n)
            (eligible[g] && bypass_count >= 2)
            |-> (rvalid[g])
        );

        // [REF_MODEL] 该 XAU 的 rvalid 有效时，必须存在已接受但尚未返回的最老事务。
        A_XAU_R_HAS_PENDING: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> (oldest_valid)
        );

        // [REF_MODEL] 只允许响应已成功发射且已捕获 MEM 数据的 FIFO 队头。
        A_XAU_R_HEAD_COMPLETE: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && m_sent[oldest] && m_done[oldest]))
        );

        // [REF_MODEL] 队头未完成时，年轻命令即使已完成，也不能让该源提前响应。
        A_XAU_R_NO_EARLY_BYPASS: assert property (
            @(posedge clk) disable iff (!rst_n)
            (oldest_valid && !m_done[oldest])
            |-> (!rvalid[g])
        );

        // [REF_MODEL] 有效 R 的 raddr 必须等于该源接收 FIFO 队头的 araddr[2:0]。
        A_XAU_R_ADDR_ORDER: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && raddr == m_addr[oldest][2:0]))
        );

        // [REF_MODEL] 有效 R 的 rid 必须属于队头；不按 ID 数值排序，也不要求 ID 唯一。
        A_XAU_R_ID_ORDER: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && rid == m_id[oldest]))
        );

        // [REF_MODEL] 有效 R 的 port_id 必须透传同一个队头命令的 port_id。
        A_XAU_R_PORT_ORDER: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && r_port_id == m_port[oldest]))
        );

        // [REF_MODEL] 有效 R 的 128 位数据必须来自同一个队头事务的 MEM 捕获记录。
        A_XAU_R_DATA_ORDER: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && rdata == m_data[oldest]))
        );

        // [REF_MODEL] 有效 R 的错误状态必须由同一个队头事务的 arresp 和 pc_err 形成。
        A_XAU_R_RESP_ORDER: assert property (
            @(posedge clk) disable iff (!rst_n)
            (rvalid[g])
            |-> ((oldest_valid && rresp == oldest_resp))
        );

        // 下列两项是 FIFO 与事务表互相核对，不是 DUT 存储探针。
        // [MODEL_SELF_CHECK] 独立接收 FIFO 的长度必须与事务表该源占用数一致，且不超过 7。
        M_XAU_FIFO_COUNT: assert property (
            @(posedge clk) disable iff (!rst_n)
            order_count == occ[g] && order_count <= 7
        );

        // [MODEL_SELF_CHECK] 独立 FIFO 队头必须与事务表按年龄计算的最老事务一致。
        M_XAU_FIFO_HEAD: assert property (
            @(posedge clk) disable iff (!rst_n)
            (order_count != 0) == head_valid[g] &&
            (order_count == 0 || (oldest_valid &&
            oldest == head[g]))
        );

        // cover 的 && 是同拍条件共现；不能改成蕴含后靠空真命中。
        // [REF_MODEL] 命令 3 先捕获，命令 1 未完成；即使 ready=1，该源仍无响应。
        C_XAU_EARLY_THIRD_BLOCKED: cover property (
            @(posedge clk) disable iff (!rst_n)
            order_phase == 3 && m_done[third_token] && !m_done[first_token] && rready[g] && !rvalid[g]
        );

        // [REF_MODEL] 完整见证：3 先发射及捕获，但 R 按 1、2、3 返回对应整组负载。
        C_XAU_R_123_AFTER_ISSUE3_FIRST: cover property (
            @(posedge clk) disable iff (!rst_n)
            order_phase == 5 && source_r && oldest == third_token && head_payload_matches
        );

        // [REF_MODEL] 该源因旧命令未完成而等待时，另一个 XAU 仍能返回。
        C_XAU_OTHER_SOURCE_PROGRESS: cover property (
            @(posedge clk) disable iff (!rst_n)
            order_phase == 3 && m_done[third_token] && !m_done[first_token] && (|(rvalid & ~(3'b1<<g)))
        );

        // [REF_MODEL] 同一个 XAU 同拍返回旧命令、接受新命令。
        C_XAU_SAME_CYCLE_POP_PUSH: cover property (
            @(posedge clk) disable iff (!rst_n)
            source_ar && source_r && order_count>0 && head_payload_matches
        );

        // [REF_MODEL] 队列中 ID 重复且年轻项已完成时，响应仍匹配最老队头。
        C_XAU_REPEAT_ID_HEAD_R: cover property (
            @(posedge clk) disable iff (!rst_n)
            order_count >= 2 &&
            m_id[order_slot[0]] == m_id[order_slot[1]] &&
            m_done[order_slot[1]] &&
            source_r &&
            head_payload_matches
        );

    end endgenerate

    // ----------------------------------------------------------------
    // 5. 模型自检 assert：检验参考记录的一致性
    // ----------------------------------------------------------------
    // [MODEL_SELF_CHECK] 模型接收 AR 时必须找到合法逻辑槽；不检查 DUT 物理分配编号。
    M_ALLOC: assert property (
        @(posedge clk) disable iff (!rst_n)
        (ar_fire)
        |-> ((free_found && alloc_e<9))
    );

    // [MODEL_SELF_CHECK] 实际 R 握手必须对应模型的合法、已发射、已完成事务。
    M_RETIRE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (r_fire)
        |-> ((model_retire && rsp_e<9 && m_live[rsp_e] && m_sent[rsp_e] && m_done[rsp_e]))
    );

    // [MODEL_SELF_CHECK] 实际发射成功必须对应模型当前请求中的未发射事务。
    M_SUCCESS: assert property (
        @(posedge clk) disable iff (!rst_n)
        (issue_fire)
        |-> ((m_attempt && m_attempt_e<9 && m_live[m_attempt_e] && !m_sent[m_attempt_e]))
    );

    // [MODEL_SELF_CHECK] 返回日历到期必须对应仍在途且尚未捕获的事务。
    M_DUE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (mem_capture_due)
        |-> ((mem_capture_slot<9 &&
              m_live[mem_capture_slot] &&
              m_sent[mem_capture_slot] &&
              !m_done[mem_capture_slot]))
    );

    // [MODEL_SELF_CHECK] 本拍刚捕获 MEM 的事务不得在同拍 R 返回，最快下一拍。
    M_NO_BYPASS: assert property (
        @(posedge clk) disable iff (!rst_n)
        (mem_capture_due && r_fire)
        |-> (mem_capture_slot != rsp_e)
    );

    // [MODEL_SELF_CHECK] 模型完成集合是已发射集合的子集；已发射集合是有效集合的子集。
    M_STATE: assert property (
        @(posedge clk) disable iff (!rst_n)
        ((m_sent & ~m_live) == 0 && (m_done & ~m_sent) == 0)
    );

    // [MODEL_SELF_CHECK] 模型待发数不超过占用数，占用数不超过 9。
    M_RANGE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (waiting >= 0 && waiting <= used && used <= 9)
    );

    // [MODEL_SELF_CHECK] 模型的共享池与空源保留预算均不得超限。
    M_QUOTA: assert property (
        @(posedge clk) disable iff (!rst_n)
        (shared_cost <= 6 && quota_cost <= 9)
    );

    // [MODEL_SELF_CHECK] 模型请求流水项必须指向合法、有效、未成功发射的事务。
    M_ATTEMPT: assert property (
        @(posedge clk) disable iff (!rst_n)
        (m_attempt)
        |-> ((m_attempt_e<9 && m_live[m_attempt_e] && !m_sent[m_attempt_e]))
    );

    generate for (g = 0; g < 9; g = g + 1) begin : slots
        wire [3:0] calendar_count =
            {3'b0, (m_due[0] && m_due_e[0] == g)} +
            {3'b0, (m_due[1] && m_due_e[1] == g)} +
            {3'b0, (m_due[2] && m_due_e[2] == g)} +
            {3'b0, (m_due[3] && m_due_e[3] == g)};
        // [MODEL_SELF_CHECK] 每个有效逻辑槽的年龄排名必须落在当前有效事务范围内。
        M_AGE_RANGE: assert property (
            @(posedge clk) disable iff (!rst_n)
            (m_live[g])
            |-> (m_age[g]<used)
        );

        // [MODEL_SELF_CHECK] 每个已发射未完成事务在 4 拍返回日历中恰好有一项。
        M_CALENDAR: assert property (
            @(posedge clk) disable iff (!rst_n)
            calendar_count == {3'b0,(m_live[g] && m_sent[g] && !m_done[g])}
        );

        for (h = 0; h < 9; h = h + 1) begin : pairs
            if (g != h) begin : distinct
                // [MODEL_SELF_CHECK] 任意两个不同的有效逻辑槽不得使用相同年龄排名。
                M_AGE_UNIQUE: assert property (
                    @(posedge clk) disable iff (!rst_n)
                    (m_live[g] && m_live[h])
                    |-> (m_age[g] != m_age[h])
                );

            end
        end
    end endgenerate

    // ----------------------------------------------------------------
    // 6. cover：要求业务事件真实发生，不对输入增加 assume
    // ----------------------------------------------------------------
    // [REF_MODEL] 仲裁失败后本拍重选同一命令，下一拍继续发出该请求。
    C_RETRY_NEXT_CYCLE: cover property (
        @(posedge clk) disable iff (!rst_n)
        retry_selected && req == last_retry_req && arb_addr == last_retry_addr && req != 0
    );

    // [REF_MODEL] 当前请求失败且对应半区忙，本拍选中窗口内另一条命令。
    C_FAILURE_SELECT_OTHER: cover property (
        @(posedge clk) disable iff (!rst_n)
        m_attempt && !issue_fire && !idle[m_attempt_e] && select_valid && select_e != m_attempt_e
    );

    // [REF_MODEL] 成功当拍补入原第 6 条命令，下一拍请求它。
    C_REFILL_NEXT_CYCLE: cover property (
        @(posedge clk) disable iff (!rst_n)
        refill_selected && req == last_refill_req && arb_addr == last_refill_addr
    );

    // [REF_MODEL] 窗口非队头成功后，原第 6 条同拍补入并于下一拍请求。
    C_NONHEAD_REFILL: cover property (
        @(posedge clk) disable iff (!rst_n)
        nonhead_refill_selected && req == last_refill_req && arb_addr == last_refill_addr
    );

    // [REF_MODEL] 窗口五条均不匹配、窗口外第六条匹配，连续等待仍不能越窗发射。
    C_BLOCKED_SIX: cover property (
        @(posedge clk) disable iff (!rst_n)
        blocked_six && blocked_streak >= 3
    );

    // [REF_MODEL] 原待发 5 条，本拍只成功发射一条，pending_cnt 本拍为 4。
    C_PENDING5_DEC: cover property (
        @(posedge clk) disable iff (!rst_n)
        waiting == 5 && !ar_fire && issue_fire && pending_cnt == 4
    );

    // [REF_MODEL] 原待发 5 条，本拍同收同发，pending_cnt 本拍仍为 5。
    C_PENDING5_BOTH: cover property (
        @(posedge clk) disable iff (!rst_n)
        waiting == 5 && ar_fire && issue_fire && pending_cnt == 5
    );

    // [REF_MODEL] 原待发 5 条，本拍只接收一条，pending_cnt 本拍为 6。
    C_PENDING5_ADD: cover property (
        @(posedge clk) disable iff (!rst_n)
        waiting == 5 && ar_fire && !issue_fire && pending_cnt == 6
    );

    // [REF_MODEL] 9 项满占用时，同拍 R 回收并接收新 AR。
    C_FULL_REUSE: cover property (
        @(posedge clk) disable iff (!rst_n)
        used == 9 && ar_fire && r_fire
    );

    // [REF_MODEL] 同拍发生 AR 接收、成功发射、MEM 捕获和 R 返回。
    C_ALL_FOUR_EVENTS: cover property (
        @(posedge clk) disable iff (!rst_n)
        ar_fire && issue_fire && mem_capture_due && r_fire
    );

    // [REF_MODEL] 占用为 7/0/0 时，仍允许其余两个 XAU 各接收第一条命令。
    C_CAPACITY700: cover property (
        @(posedge clk) disable iff (!rst_n)
        occ[0] == 7 && occ[1] == 0 && occ[2] == 0 && !r_fire && arready == 6
    );

    // [REF_MODEL] 占用为 4/4/0 时，最后空源仍可接收，已有两个源暂不可接收。
    C_CAPACITY440: cover property (
        @(posedge clk) disable iff (!rst_n)
        occ[0] == 4 && occ[1] == 4 && occ[2] == 0 && !r_fire && arready == 4
    );

    // [REF_MODEL] 同一事务越界与校验异常同时存在，最终响应越界 11。
    C_RETURN_ERROR_PRIORITY: cover property (
        @(posedge clk) disable iff (!rst_n)
        r_fire && m_err[rsp_e] == 3 && m_pc[rsp_e] && rresp == 3
    );

    // [REF_MODEL] 部分通道不 ready 时，RR 仍能选出可响应来源。
    C_READY_MASK_RR: cover property (
        @(posedge clk) disable iff (!rst_n)
        eligible != 0 && rready != 7 && r_fire
    );

    // [NO_REF_MODEL_HISTORY] 连续四拍成功发射，仅使用成功发射事件历史。
    C_FOUR_SUCCESS: cover property (
        @(posedge clk) disable iff (!rst_n)
        issue_streak >= 3 && issue_fire
    );

    genvar cb, ch;
    generate for (cb = 0; cb < 8; cb = cb + 1) begin : bank_covers
        for (ch = 0; ch < 2; ch = ch + 1) begin : half_covers
            wire this_half_busy = rd_mem_status[cb][ch];
            // [NO_REF_MODEL_PORTS] 逐 Bank、逐奇偶半区命中成功发射且状态报告占用。
            C_SUCCESS_BUSY_TARGET: cover property (
                @(posedge clk) disable iff (!rst_n)
                req[cb] && ar_rd_gnt[cb] && rw_rd_gnt[cb] && arb_addr[0] == ch && this_half_busy
            );

        end
    end endgenerate
endmodule
`default_nettype wire
