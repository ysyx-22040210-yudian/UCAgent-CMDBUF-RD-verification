// One expression source for native concurrent SVA and Yosys immediate properties.
// Native tasks select CMDBUF_NATIVE_SVA and use disable iff (!rst_n).
// Procedural simulation/legacy frontend fallbacks gate the same sampled expressions.
`ifdef TP_SIM
  `define TP_ASSERT(name, expr) always @(posedge clk) begin : name if (rst_n && !(expr)) $fatal(1, "ASSERT_FAIL %s", `"name`" ); end
  `define TP_ASSUME(name, expr) always @(posedge clk) begin : name if (rst_n && !(expr)) $fatal(1, "ENV_FAIL %s", `"name`" ); end
  `define TP_COVER(name, expr) reg name``_seen = 1'b0; always @(posedge clk) begin if (rst_n && !name``_seen && (expr)) begin name``_seen <= 1'b1; $display("COVER_HIT %s %0t", `"name`", $time); end end
`elsif CMDBUF_NATIVE_SVA
  `define TP_ASSERT(name, expr) name: assert property (@(posedge clk) disable iff (!rst_n) (expr));
  `define TP_ASSUME(name, expr) name: assume property (@(posedge clk) disable iff (!rst_n) (expr));
  `define TP_COVER(name, expr) name: cover property (@(posedge clk) disable iff (!rst_n) (expr));
`else
  `define TP_ASSERT(name, expr) always @(posedge clk) begin : name if (rst_n) assert (expr); end
  `define TP_ASSUME(name, expr) always @(posedge clk) begin : name if (rst_n) assume (expr); end
  `define TP_COVER(name, expr) always @(posedge clk) begin : name if (rst_n) cover (expr); end
`endif
