// Port-only specification checker. Exactly the 24 public DUT ports.
// All m_* state is local verification state, never a physical DUT observation.
// Sampling: an issue at N is captured at N+4; earliest R is N+5.
`default_nettype none
`include "cmdbuf_rd_port_macros.svh"
module cmdbuf_rd_port_sva (
    input wire clk, rst_n, arvalid,
    input wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    input wire [2:0] rvalid, rready,
    input wire [127:0] rdata,
    input wire [7:0] rid,
    input wire [4:0] r_port_id,
    input wire [2:0] raddr,
    input wire [1:0] rresp,
    input wire [7:0] req,
    input wire [11:0] arb_addr,
    input wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt, rw_rd_gnt,
    input bit [1:0] rd_mem_status [7:0],
    input wire [127:0] mem_rdata,
    input wire pc_err

);
    // Every property is disabled by !rst_n in the common SVA macros.
    // No startup flags and no reset-sequence assumptions are used here.
    wire accept = arvalid && (src < 3) && ((src < 3) ? arready[src] : 1'b0);
    wire success = |(req & ar_rd_gnt & rw_rd_gnt);
    wire retire = |(rvalid & rready);
    reg [8:0] m_live, m_sent, m_done, m_pc;
    reg [3:0] m_due;

    // Environment assumptions apply only outside reset.
    /* [NO_REF_MODEL_PORTS] */`TP_ASSUME(E03_SRC, !arvalid || src < 3)
    /* [NO_REF_MODEL_PORTS] */`TP_ASSUME(E04_ARRESP, !arvalid || arresp == 2'b00 || arresp == 2'b11)
    /* [NO_REF_MODEL_PORTS] */`TP_ASSUME(E05_ZERO_READY, arready != 0 || !arvalid) // [NO_REF_MODEL_PORTS]

    // [NO_REF_MODEL_PORTS] Same sampled cycle (|->), not a one-cycle delay.
    // This is an ENVIRONMENT obligation; never gate the DUT request with it.
    genvar bank_env;
    generate for(bank_env=0;bank_env<8;bank_env=bank_env+1) begin : status_contract
        // Scalar name for this bank's selected half; the port remains unpacked.
        wire requested_half_busy = rd_mem_status[bank_env][arb_addr[0]];
        /* [NO_REF_MODEL_PORTS] */`TP_ASSUME(E06_SUCCESS_BUSY, !(req[bank_env] && ar_rd_gnt[bank_env] && rw_rd_gnt[bank_env]) || requested_half_busy)
    end endgenerate

    // Independent scoreboard: a compact rank (0=oldest) instead of the DUT's
    // pairwise age matrix. It never reads DUT window/done/selection to decide
    // the expected command. The lowest free logical slot is an implementation detail of this checker.
    // It does not predict or assert the physical allocation slot of the DUT.
    reg [17:0] m_addr [0:8];
    reg [1:0] m_src [0:8], m_err [0:8];
    reg [7:0] m_id [0:8];
    reg [4:0] m_port [0:8];
    reg [3:0] m_age [0:8];
    reg [127:0] m_data [0:8];
    reg [1:0] m_rr;
    reg m_attempt;
    reg [3:0] m_attempt_e;
    reg [3:0] m_due_e [0:3];
    wire due = m_due[3];
    wire [3:0] due_e = m_due_e[3];
    reg [8:0] pending, pool, window, idle, candidate, selected;
    reg [3:0] select_e;
    wire select_valid = |selected;
    reg [3:0] head [0:2];
    reg [2:0] head_valid, eligible, expected_rvalid;
    reg model_retire;
    reg [1:0] winner;
    reg [3:0] rsp_e, alloc_e;
    reg free_found;
    reg [2:0] expected_ready;
    integer used, waiting, shared_cost, quota_cost;
    integer occ [0:2];
    integer after_occ [0:2];
    integer used_after, shared_after;
    integer ranks [0:8];
    integer best_age, scan;
    integer i, j, x, off;

    always @* begin
        used = 0; waiting = 0; shared_cost = 0; quota_cost = 0;
        for (x=0; x<3; x=x+1) occ[x] = 0;
        for (i=0; i<9; i=i+1) begin
            if (m_live[i]) begin
                used = used+1;
                if (!m_sent[i]) waiting = waiting+1;
                if (m_src[i]<3) occ[m_src[i]] = occ[m_src[i]]+1;
            end
        end
        for (x=0; x<3; x=x+1) begin
            if (occ[x]>0) shared_cost = shared_cost+occ[x]-1;
            quota_cost = quota_cost+((occ[x]>0)?occ[x]:1);
        end
        // Find the oldest live head first; only then consult done and ready.
        head_valid = 0; eligible = 0;
        for (x=0; x<3; x=x+1) begin
            head[x] = 0; best_age = 9;
            for (i=0; i<9; i=i+1)
                if (m_live[i] && m_src[i]==x && m_age[i]<best_age) begin
                    head_valid[x]=1; head[x]=i; best_age=m_age[i];
                end
            if (head_valid[x]) eligible[x] = m_done[head[x]] && rready[x];
        end
        expected_rvalid=0; winner=0; rsp_e=0; scan=0;
        for (off=0; off<3; off=off+1) begin
            scan=m_rr+off; if(scan>=3) scan=scan-3;
            if (expected_rvalid==0 && eligible[scan]) begin
                expected_rvalid[scan]=1; winner=scan; rsp_e=head[scan];
            end
        end
        if(!rst_n) expected_rvalid=0;
        model_retire = |expected_rvalid;
        used_after=0; shared_after=0;
        for(x=0;x<3;x=x+1) begin
            after_occ[x]=occ[x]-((model_retire && winner==x)?1:0);
            used_after=used_after+after_occ[x];
            if(after_occ[x]>0) shared_after=shared_after+after_occ[x]-1;
        end
        expected_ready=0;
        for(x=0;x<3;x=x+1)
            expected_ready[x]=rst_n && used_after<9 &&
                               (after_occ[x]==0 || shared_after<6);
        alloc_e=0; free_found=0;
        for(i=0;i<9;i=i+1)
            if(!free_found && (!m_live[i] || (model_retire && rsp_e==i))) begin
                free_found=1; alloc_e=i;
            end
        pending=m_live & ~m_sent;
        pool=pending;
        // 6B: remove only a successful current issue from the rank pool.
        if(success && m_attempt_e<9) pool[m_attempt_e]=0;
        window=0; idle=0; candidate=0; selected=0; select_e=0;
        for(i=0;i<9;i=i+1) begin
            ranks[i]=0;
            for(j=0;j<9;j=j+1)
                if(pool[j] && m_age[j]<m_age[i]) ranks[i]=ranks[i]+1;
            window[i]=pool[i] && ranks[i]<5;
            idle[i]=!rd_mem_status[m_addr[i][5:3]][m_addr[i][6]];
            // Failed attempts retain their age and may be selected immediately.
            candidate[i]=window[i] && idle[i];
        end
        best_age=9;
        for(i=0;i<9;i=i+1)
            if(candidate[i] && m_age[i]<best_age) begin
                best_age=m_age[i]; select_e=i;
            end
        if(best_age<9) selected[select_e]=1;
    end

    integer e,k;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            m_live<=0; m_sent<=0; m_done<=0; m_pc<=0; m_rr<=0;
            m_attempt<=0; m_attempt_e<=0; m_due<=0;
            for(k=0;k<4;k=k+1) m_due_e[k]<=0;
            for(e=0;e<9;e=e+1) begin
                m_addr[e]<=0; m_src[e]<=0; m_err[e]<=0; m_id[e]<=0;
                m_port[e]<=0; m_age[e]<=0; m_data[e]<=0;
            end
        end else begin
            m_due<={m_due[2:0],success};
            m_due_e[0]<=success?m_attempt_e:4'd0;
            for(k=1;k<4;k=k+1) m_due_e[k]<=m_due[k-1]?m_due_e[k-1]:4'd0;
            m_attempt<=select_valid;
            m_attempt_e<=select_valid?select_e:4'd0;
            if(model_retire) m_rr<=(winner==2)?2'd0:winner+2'd1;
            for(e=0;e<9;e=e+1) begin
                if(accept && alloc_e==e) begin
                    m_live[e]<=1; m_sent[e]<=0; m_done[e]<=0; m_pc[e]<=0;
                    m_addr[e]<=araddr; m_src[e]<=src; m_err[e]<=arresp;
                    m_id[e]<=arid; m_port[e]<=ar_port_id;
                    m_age[e]<=used-(model_retire?1:0); m_data[e]<=0;
                end else if(model_retire && rsp_e==e) begin
                    m_live[e]<=0; m_sent[e]<=0; m_done[e]<=0; m_pc[e]<=0;
                    m_addr[e]<=0; m_src[e]<=0; m_err[e]<=0; m_id[e]<=0;
                    m_port[e]<=0; m_age[e]<=0; m_data[e]<=0;
                end else begin
                    if(model_retire && m_live[e] && m_age[e]>m_age[rsp_e])
                        m_age[e]<=m_age[e]-1'b1;
                    if(success && m_attempt_e==e) m_sent[e]<=1;
                    if(due && due_e==e) begin
                        m_done[e]<=1; m_data[e]<=mem_rdata; m_pc[e]<=pc_err;
                    end
                end
            end
        end
    end

    wire [7:0] expected_req=(rst_n && m_attempt)?(8'b1<<m_addr[m_attempt_e][5:3]):8'd0;
    wire [11:0] expected_addr=(rst_n && m_attempt)?m_addr[m_attempt_e][17:6]:12'd0;
    wire [1:0] expected_resp=(m_err[rsp_e]==2'b11)?2'b11:(m_pc[rsp_e]?2'b01:2'b00);

    // DUT obligations: all compare externally observable behavior.
    `TP_ASSERT(A_READY, arready==expected_ready) // [REF_MODEL]
    // Width-explicit onehot0 identity also supported by the VM read_slang frontend.
    /* [NO_REF_MODEL_PORTS] */`TP_ASSERT(A_REQ_ONEHOT, (req & (req-8'd1))==0) // [NO_REF_MODEL_PORTS]
    /* [NO_REF_MODEL_PORTS] */`TP_ASSERT(A_R_ONEHOT, (rvalid & (rvalid-3'd1))==0) // [NO_REF_MODEL_PORTS]
    /* [NO_REF_MODEL_PORTS] */`TP_ASSERT(A_R_READY, (rvalid & ~rready)==0) // [NO_REF_MODEL_PORTS]
    `TP_ASSERT(A_PENDING, pending_cnt==(waiting+(accept?1:0)-(success?1:0))) // [REF_MODEL]
    `TP_ASSERT(A_REQ, req==expected_req) // [REF_MODEL]
    `TP_ASSERT(A_ARB_ADDR, req==0 || arb_addr==expected_addr) // [REF_MODEL]
    `TP_ASSERT(A_RR_CHOICE, rvalid==expected_rvalid) // [REF_MODEL]
    `TP_ASSERT(A_R_METADATA, !retire || (rid==m_id[rsp_e] && r_port_id==m_port[rsp_e] && raddr==m_addr[rsp_e][2:0])) // [REF_MODEL]
    `TP_ASSERT(A_R_RESP, !retire || rresp==expected_resp) // [REF_MODEL]
    `TP_ASSERT(A_R_DATA, !retire || rdata==m_data[rsp_e]) // [REF_MODEL]
    // Model sanity properties are not evidence of physical DUT storage state.
    `TP_ASSERT(M_ALLOC, !accept || (free_found && alloc_e<9)) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_RETIRE, !retire || (model_retire && rsp_e<9 && m_live[rsp_e] && m_sent[rsp_e] && m_done[rsp_e])) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_SUCCESS, !success || (m_attempt && m_attempt_e<9 && m_live[m_attempt_e] && !m_sent[m_attempt_e])) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_DUE, !due || (due_e<9 && m_live[due_e] && m_sent[due_e] && !m_done[due_e])) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_NO_BYPASS, !due || !retire || due_e!=rsp_e) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_STATE, ((m_sent & ~m_live)==0 && (m_done & ~m_sent)==0)) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_RANGE, (waiting>=0 && waiting<=used && used<=9)) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_QUOTA, (shared_cost<=6 && quota_cost<=9)) // [MODEL_SELF_CHECK]
    `TP_ASSERT(M_ATTEMPT, !m_attempt || (m_attempt_e<9 && m_live[m_attempt_e] && !m_sent[m_attempt_e])) // [MODEL_SELF_CHECK]
    genvar g,h;
    generate for(g=0;g<9;g=g+1) begin : slots
        `TP_ASSERT(M_AGE_RANGE, !m_live[g] || m_age[g]<used) // [MODEL_SELF_CHECK]
        wire [3:0] calendar_count = {3'b0,(m_due[0] && m_due_e[0]==g)} + {3'b0,(m_due[1] && m_due_e[1]==g)} + {3'b0,(m_due[2] && m_due_e[2]==g)} + {3'b0,(m_due[3] && m_due_e[3]==g)};
        `TP_ASSERT(M_CALENDAR, calendar_count=={3'b0,(m_live[g] && m_sent[g] && !m_done[g])}) // [MODEL_SELF_CHECK]
        for(h=0;h<9;h=h+1) begin : pairs
            if(g!=h) begin : distinct
                `TP_ASSERT(M_AGE_UNIQUE, !m_live[g] || !m_live[h] || m_age[g]!=m_age[h]) // [MODEL_SELF_CHECK]
            end
        end
    end
    for(g=0;g<3;g=g+1) begin : sources
        reg [1:0] bypass_count;
        always @(posedge clk or negedge rst_n)
            if(!rst_n) bypass_count<=0;
            else if(!eligible[g] || rvalid[g]) bypass_count<=0;
            else if(retire) bypass_count<=bypass_count+1'b1;
        `TP_ASSERT(A_RR_BOUND, !eligible[g] || bypass_count<2 || rvalid[g]) // [REF_MODEL]

        // [REF_MODEL] Explicit per-XAU acceptance-order FIFO.
        // Push ONLY on accepted AR for this source. Pop ONLY on actual R
        // handshake for this source, never on issue or MEM completion.
        // Tokens are checker-local transaction slots, NOT arid or DUT entries.
        // R payload is checked against this FIFO head independently of RR choice.
        reg [3:0] order_count;
        reg [3:0] order_slot [0:8];
        wire source_ar = accept && src==g;
        wire source_r = rvalid[g] && rready[g];
        wire [3:0] oldest = order_slot[0];
        wire oldest_valid = order_count!=0 && oldest<9 &&
                            m_live[oldest] && m_src[oldest]==g;
        wire [1:0] oldest_resp = m_err[oldest]==2'b11 ? 2'b11 :
                                (m_pc[oldest] ? 2'b01 : 2'b00);
        wire head_payload_matches = oldest_valid &&
            {raddr,rid,r_port_id,rdata,rresp} ==
            {m_addr[oldest][2:0],m_id[oldest],m_port[oldest],m_data[oldest],oldest_resp};
        integer qi;
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                order_count<=0;
                for(qi=0;qi<9;qi=qi+1) order_slot[qi]<=0;
            end else begin
                order_count<=order_count+{3'b0,source_ar}-{3'b0,source_r};
                if(source_r) begin
                    for(qi=0;qi<8;qi=qi+1) order_slot[qi]<=order_slot[qi+1];
                    order_slot[8]<=0;
                end
                // Simultaneous pop/push appends after the surviving old items.
                if(source_ar && order_count>=source_r &&
                   (order_count-{3'b0,source_r})<9)
                    order_slot[order_count-{3'b0,source_r}]<=alloc_e;
            end
        end
        `TP_ASSERT(A_XAU_R_HAS_PENDING, !rvalid[g] || oldest_valid) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_HEAD_COMPLETE, !rvalid[g] || (oldest_valid && m_sent[oldest] && m_done[oldest])) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_NO_EARLY_BYPASS, !(oldest_valid && !m_done[oldest]) || !rvalid[g]) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_ADDR_ORDER, !rvalid[g] || (oldest_valid && raddr==m_addr[oldest][2:0])) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_ID_ORDER, !rvalid[g] || (oldest_valid && rid==m_id[oldest])) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_PORT_ORDER, !rvalid[g] || (oldest_valid && r_port_id==m_port[oldest])) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_DATA_ORDER, !rvalid[g] || (oldest_valid && rdata==m_data[oldest])) // [REF_MODEL]
        `TP_ASSERT(A_XAU_R_RESP_ORDER, !rvalid[g] || (oldest_valid && rresp==oldest_resp)) // [REF_MODEL]
        `TP_ASSERT(M_XAU_FIFO_COUNT, order_count==occ[g] && order_count<=7) // [MODEL_SELF_CHECK]
        `TP_ASSERT(M_XAU_FIFO_HEAD, (order_count!=0)==head_valid[g] && (order_count==0 || (oldest_valid && oldest==head[g]))) // [MODEL_SELF_CHECK]

        // [REF_MODEL] Witness: accept 1,2,3; issue/capture 3 before 1/2;
        // wait at the source head; eventually return complete payloads 1,2,3.
        // No input restriction is added by this monitor.
        reg [2:0] order_phase;
        reg [3:0] first_token, second_token, third_token;
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                order_phase<=0; first_token<=0; second_token<=0; third_token<=0;
            end else begin
                case(order_phase)
                    0: if(order_count>=3 &&
                          !m_sent[order_slot[0]] && !m_sent[order_slot[1]] &&
                          !m_sent[order_slot[2]] && !source_r) begin
                        first_token<=order_slot[0]; second_token<=order_slot[1];
                        third_token<=order_slot[2]; order_phase<=1;
                    end
                    1: begin
                        if(source_r) order_phase<=0;
                        else if(success && m_attempt_e==third_token &&
                                !m_sent[first_token] && !m_sent[second_token])
                            order_phase<=2;
                        else if(success && (m_attempt_e==first_token || m_attempt_e==second_token))
                            order_phase<=0;
                    end
                    2: begin
                        if(source_r) order_phase<=0;
                        else if(due && due_e==third_token &&
                                !m_done[first_token] && !m_done[second_token])
                            order_phase<=3;
                    end
                    3: if(source_r)
                        order_phase<=(oldest==first_token && head_payload_matches)?3'd4:3'd0;
                    4: if(source_r)
                        order_phase<=(oldest==second_token && head_payload_matches)?3'd5:3'd0;
                    5: if(source_r) order_phase<=0;
                    default: order_phase<=0;
                endcase
            end
        end
        `TP_COVER(C_XAU_EARLY_THIRD_BLOCKED, order_phase==3 && m_done[third_token] && !m_done[first_token] && rready[g] && !rvalid[g]) // [REF_MODEL]
        `TP_COVER(C_XAU_R_123_AFTER_ISSUE3_FIRST, order_phase==5 && source_r && oldest==third_token && head_payload_matches) // [REF_MODEL]
        `TP_COVER(C_XAU_OTHER_SOURCE_PROGRESS, order_phase==3 && m_done[third_token] && !m_done[first_token] && (|(rvalid & ~(3'b1<<g)))) // [REF_MODEL]
        `TP_COVER(C_XAU_SAME_CYCLE_POP_PUSH, source_ar && source_r && order_count>0 && head_payload_matches) // [REF_MODEL]
        `TP_COVER(C_XAU_REPEAT_ID_HEAD_R, order_count>=2 && m_id[order_slot[0]]==m_id[order_slot[1]] && m_done[order_slot[1]] && source_r && head_payload_matches) // [REF_MODEL]
    end endgenerate

    // [NO_REF_MODEL_HISTORY] Arithmetic recurrence needs only port history.
    reg [3:0] last_pending;
    always @(posedge clk or negedge rst_n) if(!rst_n) last_pending<=0; else last_pending<=pending_cnt;
    /* [NO_REF_MODEL_HISTORY] */`TP_ASSERT(A_PENDING_RECURRENCE, pending_cnt==(last_pending+{3'b0,accept}-{3'b0,success}))
    /* [NO_REF_MODEL_PORTS] */`TP_ASSERT(A_PENDING_RANGE, pending_cnt<=9)

    // Covers confirm the corrected cases are reachable under E06.
    reg retry_selected, refill_selected, nonhead_refill_selected;
    reg [11:0] last_retry_addr, last_refill_addr;
    reg [7:0] last_retry_req, last_refill_req;
    reg [2:0] blocked_streak;
    reg [3:0] issue_streak;
    integer selected_old_rank;
    integer c;
    always @* begin
        selected_old_rank=0;
        for(c=0;c<9;c=c+1)
            if(pending[c] && m_age[c]<m_age[select_e]) selected_old_rank=selected_old_rank+1;
    end
    wire blocked_six=waiting>=6 && (window & idle)==0 && (pool & ~window & idle)!=0 && !m_attempt;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            retry_selected<=0;refill_selected<=0;nonhead_refill_selected<=0;
            last_retry_addr<=0;last_refill_addr<=0;last_retry_req<=0;last_refill_req<=0;
            blocked_streak<=0;issue_streak<=0;
        end else begin
            retry_selected<=m_attempt && !success && select_valid && select_e==m_attempt_e;
            refill_selected<=success && select_valid && selected_old_rank==5;
            nonhead_refill_selected<=success && select_valid && selected_old_rank==5 && ranks[m_attempt_e]!=0;
            last_retry_addr<=expected_addr;last_retry_req<=expected_req;
            last_refill_addr<=m_addr[select_e][17:6];
            last_refill_req<=8'b1<<m_addr[select_e][5:3];
            if(blocked_six) begin if(blocked_streak!=7)blocked_streak<=blocked_streak+1'b1;end
            else blocked_streak<=0;
            if(success) begin if(issue_streak!=15)issue_streak<=issue_streak+1'b1;end
            else issue_streak<=0;
        end
    end
    `TP_COVER(C_RETRY_NEXT_CYCLE, retry_selected && req==last_retry_req && arb_addr==last_retry_addr && req!=0) // [REF_MODEL]
    `TP_COVER(C_FAILURE_SELECT_OTHER, m_attempt && !success && !idle[m_attempt_e] && select_valid && select_e!=m_attempt_e) // [REF_MODEL]
    `TP_COVER(C_REFILL_NEXT_CYCLE, refill_selected && req==last_refill_req && arb_addr==last_refill_addr) // [REF_MODEL]
    `TP_COVER(C_NONHEAD_REFILL, nonhead_refill_selected && req==last_refill_req && arb_addr==last_refill_addr) // [REF_MODEL]
    `TP_COVER(C_BLOCKED_SIX, blocked_six && blocked_streak>=3) // [REF_MODEL]
    `TP_COVER(C_PENDING5_DEC, waiting==5 && !accept && success && pending_cnt==4) // [REF_MODEL]
    `TP_COVER(C_PENDING5_BOTH, waiting==5 && accept && success && pending_cnt==5) // [REF_MODEL]
    `TP_COVER(C_PENDING5_ADD, waiting==5 && accept && !success && pending_cnt==6) // [REF_MODEL]
    `TP_COVER(C_FULL_REUSE, used==9 && accept && retire) // [REF_MODEL]
    `TP_COVER(C_ALL_FOUR_EVENTS, accept && success && due && retire) // [REF_MODEL]
    `TP_COVER(C_CAPACITY700, occ[0]==7 && occ[1]==0 && occ[2]==0 && !retire && arready==6) // [REF_MODEL]
    `TP_COVER(C_CAPACITY440, occ[0]==4 && occ[1]==4 && occ[2]==0 && !retire && arready==4) // [REF_MODEL]
    `TP_COVER(C_RETURN_ERROR_PRIORITY, retire && m_err[rsp_e]==3 && m_pc[rsp_e] && rresp==3) // [REF_MODEL]
    `TP_COVER(C_READY_MASK_RR, eligible!=0 && rready!=7 && retire) // [REF_MODEL]
    /* [NO_REF_MODEL_HISTORY] */`TP_COVER(C_FOUR_SUCCESS, issue_streak>=3 && success)
    genvar cb,ch;
    generate for(cb=0;cb<8;cb=cb+1) begin : bank_covers
        for(ch=0;ch<2;ch=ch+1) begin : half_covers
            wire this_half_busy = rd_mem_status[cb][ch];
            /* [NO_REF_MODEL_PORTS] */`TP_COVER(C_SUCCESS_BUSY_TARGET, req[cb] && ar_rd_gnt[cb] && rw_rd_gnt[cb] && arb_addr[0]==ch && this_half_busy)
        end
    end endgenerate
endmodule
`undef TP_ASSERT
`undef TP_ASSUME
`undef TP_COVER
`default_nettype wire
