from pathlib import Path
import hashlib,json,re,tarfile
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
normal_roots=['build/formal','build/formal_retry','build/formal_guided']
witnesses=[];jobs=[]
for name in normal_roots:
    for folder in sorted((ROOT/name).iterdir()):
        if not folder.is_dir() or not (folder/'result.json').exists():continue
        result=json.loads((folder/'result.json').read_text(encoding='utf-8'));result['folder']=str(folder.relative_to(ROOT));jobs.append(result)
        pending=[]
        for line in (folder/'console.log').read_text(encoding='utf-8',errors='replace').splitlines():
            match=re.search(r'Reached cover statement in step (\d+) at .*?checks\.(\S+)',line)
            if match:pending.append((match[2],int(match[1])))
            trace=re.search(r'Writing trace to VCD file: (\S+)',line)
            if trace:
                for label,step in pending:
                    witnesses.append(dict(label=label,step=step,job=str(folder.relative_to(ROOT)),
                        trace=str((folder/'run'/trace[1]).relative_to(ROOT)),guided='guided' in name))
                pending=[]
new_labels={w['label'] for w in witnesses if w['label'].startswith('C_CC_')}
replay=json.loads((ROOT/'build/replay_all/summary.json').read_text(encoding='utf-8'))
negative=json.loads((ROOT/'build/negative/results.json').read_text(encoding='utf-8'))
sim=[]
for p in (ROOT/'build/business_simulation').glob('*.json'):
    r=json.loads(p.read_text(encoding='utf-8'))
    if 'checks_failed' in r:
        assert r['status']=='pass',p
        sim.append(dict(name=p.stem,checks=r['checks'],cycles=r['cycles']))
assert len(sim)==32,len(sim)
assert len(new_labels)==547,len(new_labels)
assert not replay['failed'],replay['failed']
assert set(new_labels)<=set(replay['native_cover_labels'])
assert all(x['experiment_pass'] for x in negative)
checks={j['name']:j for j in jobs if j['name'] in ('bmc','prove') and j['status'].startswith('PASS')}
assert checks['bmc']['depth']==10 and checks['bmc']['counts']['assert']==156
summary={
 'status':'COMPLETED_WITH_EXPLICIT_LIMITS','normal_case_count':139,'cases_with_positive_witness':143,
 'normal_environment_assume_instances':11,'assert_instances':156,'dut_assert_instances':51,'model_self_check_instances':105,
 'bmc':dict(depth=10,status=checks['bmc']['status'],folder=checks['bmc']['folder']),
 'unbounded_proved':['A_REQ_ONEHOT','A_R_ONEHOT','A_R_READY'],
 'new_cover_bins':547,'unguided_new_cover_bins':546,'guided_new_cover_bins':1,
 'guided_case':'ENT-12','guided_step':next(w['step'] for w in witnesses if w['label']=='C_CC_ENT_12_MAIN'),
 'guided_assume_instances':22,'guided_count_note':'Initial runner recorded W_LONG_STATUS as one label; elaborated multiplicity is eight, so total is 22, not raw result.json 15. Normal profile count 11 is unchanged.',
 'baseline_cover_instances':46,'native_replay':{k:replay[k] for k in ('traces','cycles','failed')},
 'simulation':dict(cases=len(sim),checks=sum(x['checks'] for x in sim),cycles=sum(x['cycles'] for x in sim),details=sim,
                   reset_test_excluded='15_reset_clean.case'),
 'negative_experiments':negative,
 'not_directly_port_coverable':['CAP-20','CAP-21','ENT-10','ENT-11','CON-05','MEM-14','AR-15','ENV-07','ENV-08'],
 'limits':['All-property unbounded proof is not established.','12-step full BMC timed out; 10-step BMC passed.',
           'Capacity unbounded PDR timed out; no counterexample reported, but not a proof.',
           'ENT-12 unguided cover timed out; separate declared legal-input schedule reached it at step 33 and native replay passed.',
           'Four negative runs check environment monitors; their expected FAIL is not a DUT bug.',
           'No new physical-entry mutation campaign, FormalMC 2024 execution, encrypted-RTL equivalence, reset or four-state campaign.',
           '32 business simulations use reset only to establish initial state; dedicated reset_clean case excluded.'],
 'jobs':jobs,
}
(ROOT/'cover_witnesses.json').write_text(json.dumps(witnesses,indent=2)+'\n',encoding='utf-8')
(ROOT/'closure_summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
selected=set()
for name in ['rtl','formal/protocol_20261021','formal/corner_20261021']:
    for p in (ROOT/name).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:selected.add(p)
for name in normal_roots+['build/negative']:
    for p in (ROOT/name).rglob('*'):
        if not p.is_file():continue
        if p.parent.name in ('src','model','engine_0'):
            if p.suffix=='.vcd' or p.name=='design.log':selected.add(p)
        elif p.suffix in ('.json','.sv','.sby','.log') or p.name in ('status','PASS','TIMEOUT','ERROR','FAIL'):
            selected.add(p)
for name in ['build/replay_all','build/business_simulation']:
    for p in (ROOT/name).glob('*'):
        if p.is_file() and p.suffix in ('.json','.txt','.log','.dat'):selected.add(p)
for p in ROOT.glob('*.py'):selected.add(p)
for p in ROOT.glob('*.log'):selected.add(p)
for name in ['summary.json','closure_summary.json','cover_witnesses.json','build/business_case_selection.json',
             'build/business_regression.log','build/native_lint.log','build/native_regression.log',
             'build/replay_current_build.log','build/replay_all.log']:
    p=ROOT/name
    if p.exists():selected.add(p)
manifest={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(selected)}
(ROOT/'evidence_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
selected.add(ROOT/'evidence_manifest.json')
with tarfile.open(ROOT/'compact_evidence.tar.gz','w:gz') as tar:
    for p in sorted(selected):tar.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
print(json.dumps({'files':len(selected),'archive_bytes':(ROOT/'compact_evidence.tar.gz').stat().st_size,
                  'new_bins':len(new_labels),'replay_traces':replay['traces'],'business_cases':len(sim)}),flush=True)
