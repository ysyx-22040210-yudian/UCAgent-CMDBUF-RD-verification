from pathlib import Path
import json,os,subprocess
ROOT=Path(__file__).resolve().parent
TOOLS=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
env=os.environ.copy();env['PATH']=str(TOOLS)+os.pathsep+env['PATH'];env['LIBRARY_PATH']='/usr/lib/gcc/x86_64-redhat-linux/4.8.5';env['PYTHONIOENCODING']='utf-8'
args=[str(TOOLS/'verilator'),'--cc','--exe','--build','--assert','--coverage-user','--top-module','cmdbuf_rd_formal','--prefix','Vcmdbuf_rd',
      '--Mdir',str(ROOT/'build/replay_current'),'-o','replay','-j','2','--language','1800-2017','-Wno-WIDTHEXPAND','-Wno-WIDTHTRUNC',
      '-f','formal/corner_20261021/native.f',str(ROOT/'formal/corner_20261021/replay.cpp')]
with (ROOT/'build/replay_current_build.log').open('w') as f:
    p=subprocess.run(['/bin/bash','-c','source /opt/rh/devtoolset-11/enable && exec "$@"','build-replay']+args,cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'replay build'
with (ROOT/'build/replay_all.log').open('w') as f:
    p=subprocess.run(['python3','formal/corner_20261021/replay.py','--formal','build/formal','--formal','build/formal_retry','--formal','build/formal_guided',
        '--sim','build/replay_current/replay','--output','build/replay_all'],cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'replay failed'
result=json.loads((ROOT/'build/replay_all/summary.json').read_text(encoding='utf-8'))
print(json.dumps({'traces':result['traces'],'cycles':result['cycles'],'failures':len(result['failed']),
                  'corner_labels':len([x for x in result['native_cover_labels'] if x.startswith('C_CC_')])}),flush=True)
