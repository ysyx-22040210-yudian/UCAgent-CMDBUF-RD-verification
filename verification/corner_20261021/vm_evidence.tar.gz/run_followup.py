from pathlib import Path
import json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parent
TOOLS=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
env=os.environ.copy();env['PATH']=str(TOOLS)+os.pathsep+env['PATH'];env['LIBRARY_PATH']='/usr/lib/gcc/x86_64-redhat-linux/4.8.5';env['PYTHONIOENCODING']='utf-8'
case_dir=ROOT/'build/business_cases';case_dir.mkdir(exist_ok=False)
selected=[];excluded=[]
for p in (ROOT/'simulation/env_base/cases/cmdbuf_rd_sv').glob('*.case'):
    if 'reset_clean' in p.read_text(encoding='utf-8'):excluded.append(p.name)
    else:shutil.copyfile(str(p),str(case_dir/p.name));selected.append(p.name)
(ROOT/'build/business_case_selection.json').write_text(json.dumps(dict(selected=selected,excluded_reset_cases=excluded),indent=2)+'\n',encoding='utf-8')
with (ROOT/'build/business_regression.log').open('w') as f:
    p=subprocess.run(['make','-f','simulation/env_base/env/Makefile','PROJECT_CONFIG=simulation/env_base/projects/cmdbuf_rd_corner_sva.mk',
        'VERILATOR='+str(TOOLS/'verilator'),'BUILD_DIR='+str(ROOT/'build/verilator'),'RESULT_DIR='+str(ROOT/'build/business_simulation'),
        'CASE_DIR='+str(case_dir),'JOBS=2','run-all'],cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'business regression'
args=[str(TOOLS/'verilator'),'--cc','--exe','--build','--assert','--coverage-user','--top-module','cmdbuf_rd_formal','--prefix','Vcmdbuf_rd',
      '--Mdir',str(ROOT/'build/replay_bin'),'-o','replay','-j','2','--language','1800-2017','-Wno-WIDTHEXPAND','-Wno-WIDTHTRUNC',
      '-f','formal/corner_20261021/native.f',str(ROOT/'formal/corner_20261021/replay.cpp')]
# Compiler environment only; no command or path derived from untrusted trace content.
with (ROOT/'build/replay_build.log').open('w') as f:
    p=subprocess.run(['/bin/bash','-c','source /opt/rh/devtoolset-11/enable && exec "$@"','build-replay']+args,cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'replay build'
print(json.dumps({'business_cases':len(selected),'excluded':excluded,'replay_build':'PASS'}),flush=True)
