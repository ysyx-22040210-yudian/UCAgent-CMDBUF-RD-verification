from pathlib import Path
import concurrent.futures,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
TOOLS=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
ENV=os.environ.copy();ENV['PATH']=str(TOOLS)+os.pathsep+ENV['PATH']
ENV['LIBRARY_PATH']='/usr/lib/gcc/x86_64-redhat-linux/4.8.5'+os.pathsep+ENV.get('LIBRARY_PATH','')
ENV['PYTHONIOENCODING']='utf-8'
records=[]
def run(name,args,timeout=3600):
    log=BUILD/(name+'.log');start=time.time()
    with log.open('w',encoding='utf-8') as f:
        proc=subprocess.run(args,cwd=str(ROOT),env=ENV,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
    rec=dict(name=name,returncode=proc.returncode,seconds=round(time.time()-start,2),log=str(log.relative_to(ROOT)))
    records.append(rec);print(json.dumps(rec),flush=True)
    return rec
try:
    lint=run('native_lint',[str(TOOLS/'verilator'),'--lint-only','--assert','-Wno-WIDTHEXPAND','-Wno-WIDTHTRUNC','--top-module','cmdbuf_rd_formal','-f','formal/corner_20261021/native.f'])
    if lint['returncode']:raise RuntimeError('native lint failed')
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        a=pool.submit(run,'native_regression',['make','-f','simulation/env_base/env/Makefile','PROJECT_CONFIG=simulation/env_base/projects/cmdbuf_rd_corner_sva.mk',
            'VERILATOR='+str(TOOLS/'verilator'),'BUILD_DIR='+str(BUILD/'verilator'),'RESULT_DIR='+str(BUILD/'simulation'),'JOBS=2','lint','run-all'])
        b=pool.submit(run,'sby',['python3','formal/corner_20261021/run.py','--output',str(BUILD/'formal'),'--tools',str(TOOLS),'--jobs','3','--timeout','360'])
        a.result();b.result()
    results=json.loads((BUILD/'formal/results.json').read_text(encoding='utf-8'))
    summary=dict(status='PASS' if all(x['returncode']==0 for x in records) else 'FAIL',records=records,formal=results)
except Exception as e:summary=dict(status='FAIL',records=records,error=str(e))
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':summary['status']}),flush=True)
