`default_nettype none
module cmdbuf_rd_formal (
    input wire clk,
    input wire rst_n,
    input wire arvalid,
    output wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    output wire [2:0] rvalid,
    input wire [2:0] rready,
    output wire [127:0] rdata,
    output wire [7:0] rid,
    output wire [4:0] r_port_id,
    output wire [2:0] raddr,
    output wire [1:0] rresp,
    output wire [7:0] req,
    output wire [11:0] arb_addr,
    output wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt,
    // [7:0]: even banks; [15:8]: odd banks, matching the original packed order.
    input wire [15:0] rd_mem_status,
    input wire [127:0] mem_rdata,
    input wire pc_err,
    input wire [7:0] rw_rd_gnt
);
wire o_alloc;
wire o_retire;
wire o_issue;
wire o_capture;
wire [3:0] o_alloc_e;
wire [3:0] o_retire_e;
wire [3:0] o_issue_e;
wire [3:0] o_capture_e;
wire [3:0] o_rsp_e;
wire [8:0] o_valid;
wire [8:0] o_issued;
wire [8:0] o_done;
wire [161:0] o_addr;
wire [17:0] o_src;
wire [17:0] o_arresp;
wire [71:0] o_id;
wire [44:0] o_port;
wire [80:0] o_older;
wire [11:0] o_occ;
wire [1:0] o_rr;
wire o_attempt;
wire o_select;
wire [3:0] o_select_e;
wire [8:0] o_pending;
wire [8:0] o_pool;
wire [8:0] o_window;
wire [8:0] o_idle;
wire [8:0] o_candidate;
wire [8:0] o_selected;
wire [1151:0] o_data;
wire [8:0] o_pc;
wire [8:0] o_reserved;
wire [8:0] o_otb_done;
wire [3:0] o_ret_valid;
wire [15:0] o_ret_entry;
cmdbuf_rd_observed dut (
    .clk(clk),
    .rst_n(rst_n),
    .arvalid(arvalid),
    .arready(arready),
    .araddr(araddr),
    .src(src),
    .arid(arid),
    .ar_port_id(ar_port_id),
    .arresp(arresp),
    .rvalid(rvalid),
    .rready(rready),
    .rdata(rdata),
    .rid(rid),
    .r_port_id(r_port_id),
    .raddr(raddr),
    .rresp(rresp),
    .req(req),
    .arb_addr(arb_addr),
    .pending_cnt(pending_cnt),
    .ar_rd_gnt(ar_rd_gnt),
    .rd_mem_status(rd_mem_status),
    .mem_rdata(mem_rdata),
    .pc_err(pc_err),
    .rw_rd_gnt(rw_rd_gnt),
    .o_alloc(o_alloc),
    .o_retire(o_retire),
    .o_issue(o_issue),
    .o_capture(o_capture),
    .o_alloc_e(o_alloc_e),
    .o_retire_e(o_retire_e),
    .o_issue_e(o_issue_e),
    .o_capture_e(o_capture_e),
    .o_rsp_e(o_rsp_e),
    .o_valid(o_valid),
    .o_issued(o_issued),
    .o_done(o_done),
    .o_addr(o_addr),
    .o_src(o_src),
    .o_arresp(o_arresp),
    .o_id(o_id),
    .o_port(o_port),
    .o_older(o_older),
    .o_occ(o_occ),
    .o_rr(o_rr),
    .o_attempt(o_attempt),
    .o_select(o_select),
    .o_select_e(o_select_e),
    .o_pending(o_pending),
    .o_pool(o_pool),
    .o_window(o_window),
    .o_idle(o_idle),
    .o_candidate(o_candidate),
    .o_selected(o_selected),
    .o_data(o_data),
    .o_pc(o_pc),
    .o_reserved(o_reserved),
    .o_otb_done(o_otb_done),
    .o_ret_valid(o_ret_valid),
    .o_ret_entry(o_ret_entry)
);
cmdbuf_rd_sva tp_check (
    .clk(clk),
    .rst_n(rst_n),
    .arvalid(arvalid),
    .arready(arready),
    .araddr(araddr),
    .src(src),
    .arid(arid),
    .ar_port_id(ar_port_id),
    .arresp(arresp),
    .rvalid(rvalid),
    .rready(rready),
    .rdata(rdata),
    .rid(rid),
    .r_port_id(r_port_id),
    .raddr(raddr),
    .rresp(rresp),
    .req(req),
    .arb_addr(arb_addr),
    .pending_cnt(pending_cnt),
    .ar_rd_gnt(ar_rd_gnt),
    .rd_mem_status(rd_mem_status),
    .mem_rdata(mem_rdata),
    .pc_err(pc_err),
    .rw_rd_gnt(rw_rd_gnt),
    .o_alloc(o_alloc),
    .o_retire(o_retire),
    .o_issue(o_issue),
    .o_capture(o_capture),
    .o_alloc_e(o_alloc_e),
    .o_retire_e(o_retire_e),
    .o_issue_e(o_issue_e),
    .o_capture_e(o_capture_e),
    .o_rsp_e(o_rsp_e),
    .o_valid(o_valid),
    .o_issued(o_issued),
    .o_done(o_done),
    .o_addr(o_addr),
    .o_src(o_src),
    .o_arresp(o_arresp),
    .o_id(o_id),
    .o_port(o_port),
    .o_older(o_older),
    .o_occ(o_occ),
    .o_rr(o_rr),
    .o_attempt(o_attempt),
    .o_select(o_select),
    .o_select_e(o_select_e),
    .o_pending(o_pending),
    .o_pool(o_pool),
    .o_window(o_window),
    .o_idle(o_idle),
    .o_candidate(o_candidate),
    .o_selected(o_selected),
    .o_data(o_data),
    .o_pc(o_pc),
    .o_reserved(o_reserved),
    .o_otb_done(o_otb_done),
    .o_ret_valid(o_ret_valid),
    .o_ret_entry(o_ret_entry)
);
endmodule
`default_nettype wire
