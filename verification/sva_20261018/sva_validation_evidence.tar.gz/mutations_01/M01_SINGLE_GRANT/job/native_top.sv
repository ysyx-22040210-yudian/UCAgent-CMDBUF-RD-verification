`default_nettype none
module cmdbuf_rd_native_formal (
    input wire clk,
    input wire rst_n,
    input wire arvalid,
    output wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    output wire [2:0] rvalid,
    input wire [2:0] rready,
    output wire [127:0] rdata,
    output wire [7:0] rid,
    output wire [4:0] r_port_id,
    output wire [2:0] raddr,
    output wire [1:0] rresp,
    output wire [7:0] req,
    output wire [11:0] arb_addr,
    output wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt,
    // [7:0]: even banks; [15:8]: odd banks, matching the original packed order.
    input wire [15:0] rd_mem_status,
    input wire [127:0] mem_rdata,
    input wire pc_err,
    input wire [7:0] rw_rd_gnt
);
cmdbuf_rd dut (.clk(clk), .rst_n(rst_n), .arvalid(arvalid), .arready(arready), .araddr(araddr), .src(src), .arid(arid), .ar_port_id(ar_port_id), .arresp(arresp), .rvalid(rvalid), .rready(rready), .rdata(rdata), .rid(rid), .r_port_id(r_port_id), .raddr(raddr), .rresp(rresp), .req(req), .arb_addr(arb_addr), .pending_cnt(pending_cnt), .ar_rd_gnt(ar_rd_gnt), .rd_mem_status(rd_mem_status), .mem_rdata(mem_rdata), .pc_err(pc_err), .rw_rd_gnt(rw_rd_gnt));
endmodule
`default_nettype wire
