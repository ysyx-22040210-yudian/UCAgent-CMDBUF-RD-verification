+incdir+.
+define+CMDBUF_NATIVE_SVA
+define+SYNTHESIS
cmdbuf_rd_cmd_observed.v
cmdbuf_rd_otb_observed.v
cmdbuf_rd_observed.v
cmdbuf_rd_sva.sv
formal_top.sv
