// Synthesizable Verilog-2001; preserves the aligned CMDBUF/OTB behavior.
`default_nettype none
module cmdbuf_rd_observed (
    input wire clk,
    input wire rst_n,
    input wire arvalid,
    output wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    output wire [2:0] rvalid,
    input wire [2:0] rready,
    output wire [127:0] rdata,
    output wire [7:0] rid,
    output wire [4:0] r_port_id,
    output wire [2:0] raddr,
    output wire [1:0] rresp,
    output wire [7:0] req,
    output wire [11:0] arb_addr,
    output wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt,
    // [7:0]: even banks; [15:8]: odd banks, matching the original packed order.
    input wire [15:0] rd_mem_status,
    input wire [127:0] mem_rdata,
    input wire pc_err,
    input wire [7:0] rw_rd_gnt,
    output wire o_alloc,
    output wire o_retire,
    output wire o_issue,
    output wire o_capture,
    output wire [3:0] o_alloc_e,
    output wire [3:0] o_retire_e,
    output wire [3:0] o_issue_e,
    output wire [3:0] o_capture_e,
    output wire [3:0] o_rsp_e,
    output wire [8:0] o_valid,
    output wire [8:0] o_issued,
    output wire [8:0] o_done,
    output wire [161:0] o_addr,
    output wire [17:0] o_src,
    output wire [17:0] o_arresp,
    output wire [71:0] o_id,
    output wire [44:0] o_port,
    output wire [80:0] o_older,
    output wire [11:0] o_occ,
    output wire [1:0] o_rr,
    output wire o_attempt,
    output wire o_select,
    output wire [3:0] o_select_e,
    output wire [8:0] o_pending,
    output wire [8:0] o_pool,
    output wire [8:0] o_window,
    output wire [8:0] o_idle,
    output wire [8:0] o_candidate,
    output wire [8:0] o_selected,
    output wire [1151:0] o_data,
    output wire [8:0] o_pc,
    output wire [8:0] o_reserved,
    output wire [8:0] o_otb_done,
    output wire [3:0] o_ret_valid,
    output wire [15:0] o_ret_entry
);
    wire alloc_fire, retire_fire, issue_success, capture_valid;
    wire [3:0] alloc_entry, retire_entry, issue_entry, capture_entry, rsp_entry;
    wire [127:0] rsp_data;
    wire rsp_pc_err;

    cmdbuf_rd_cmd_observed u_cmd (
        .clk(clk), .rst_n(rst_n), .arvalid(arvalid), .arready(arready), .araddr(araddr), .src(src), .arid(arid),
        .ar_port_id(ar_port_id), .arresp(arresp), .rvalid(rvalid), .rready(rready), .rid(rid), .r_port_id(r_port_id),
        .raddr(raddr), .rresp(rresp), .req(req), .arb_addr(arb_addr), .pending_cnt(pending_cnt), .ar_rd_gnt(ar_rd_gnt),
        .rd_mem_status(rd_mem_status), .rw_rd_gnt(rw_rd_gnt), .alloc_fire(alloc_fire), .alloc_entry(alloc_entry),
        .retire_fire(retire_fire), .retire_entry(retire_entry), .issue_success(issue_success), .issue_entry(issue_entry),
        .capture_valid(capture_valid), .capture_entry(capture_entry), .rsp_entry(rsp_entry), .rsp_pc_err(rsp_pc_err),
        .o_valid(o_valid),
        .o_issued(o_issued),
        .o_done(o_done),
        .o_addr(o_addr),
        .o_src(o_src),
        .o_arresp(o_arresp),
        .o_id(o_id),
        .o_port(o_port),
        .o_older(o_older),
        .o_occ(o_occ),
        .o_rr(o_rr),
        .o_attempt(o_attempt),
        .o_select(o_select),
        .o_select_e(o_select_e),
        .o_pending(o_pending),
        .o_pool(o_pool),
        .o_window(o_window),
        .o_idle(o_idle),
        .o_candidate(o_candidate),
        .o_selected(o_selected)
    );
    cmdbuf_rd_otb_observed u_otb (
        .clk(clk), .rst_n(rst_n), .alloc_fire(alloc_fire), .alloc_entry(alloc_entry), .retire_fire(retire_fire),
        .retire_entry(retire_entry), .issue_success(issue_success), .issue_entry(issue_entry), .capture_valid(capture_valid),
        .capture_entry(capture_entry), .mem_rdata(mem_rdata), .pc_err(pc_err), .rsp_entry(rsp_entry), .rsp_data(rsp_data),
        .rsp_pc_err(rsp_pc_err),
        .o_data(o_data),
        .o_pc(o_pc),
        .o_reserved(o_reserved),
        .o_otb_done(o_otb_done),
        .o_ret_valid(o_ret_valid),
        .o_ret_entry(o_ret_entry)
    );
    assign rdata = (|rvalid) ? (rsp_data ^ (128'b1 << 127)) : 128'b0;

// Read-only formal observation ports. No driver of DUT state.
assign o_alloc = alloc_fire;
assign o_retire = retire_fire;
assign o_issue = issue_success;
assign o_capture = capture_valid;
assign o_alloc_e = alloc_entry;
assign o_retire_e = retire_entry;
assign o_issue_e = issue_entry;
assign o_capture_e = capture_entry;
assign o_rsp_e = rsp_entry;
endmodule
`default_nettype wire
