`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  wire [0:0] PI_clk = clock;
  reg [127:0] PI_mem_rdata;
  reg [1:0] PI_arresp;
  reg [0:0] PI_pc_err;
  reg [1:0] PI_src;
  reg [2:0] PI_rready;
  reg [7:0] PI_rw_rd_gnt;
  reg [15:0] PI_rd_mem_status;
  reg [7:0] PI_ar_rd_gnt;
  reg [0:0] PI_rst_n;
  reg [17:0] PI_araddr;
  reg [7:0] PI_arid;
  reg [0:0] PI_arvalid;
  reg [4:0] PI_ar_port_id;
  cmdbuf_rd_formal UUT (
    .clk(PI_clk),
    .mem_rdata(PI_mem_rdata),
    .arresp(PI_arresp),
    .pc_err(PI_pc_err),
    .src(PI_src),
    .rready(PI_rready),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .rd_mem_status(PI_rd_mem_status),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .rst_n(PI_rst_n),
    .araddr(PI_araddr),
    .arid(PI_arid),
    .arvalid(PI_arvalid),
    .ar_port_id(PI_ar_port_id)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    UUT.dut.u_cmd._witness_.anyinit_procdff_19153 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19158 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19163 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19168 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19173 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19178 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19183 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19188 = 3'b000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19193 = 12'b000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19208 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19213 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19218 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19223 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19228 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19233 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19238 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19243 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19248 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19253 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19258 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19263 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19268 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19273 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19278 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19283 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19288 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19293 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19298 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19303 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19308 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19313 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19318 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19323 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19328 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19333 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19338 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19343 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19348 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19353 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19358 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19363 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19368 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19373 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19378 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19383 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19388 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19393 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19398 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19403 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19408 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19413 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19418 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19423 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19428 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19433 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19438 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19443 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19448 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19453 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19458 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19463 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19468 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19473 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19478 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19483 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_19488 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19058 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19063 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19068 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19073 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19088 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19093 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19098 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19103 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19108 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19113 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19118 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19123 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19128 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19133 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19138 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19143 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_19148 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    // UUT.tp_check.$auto$async2sync.\cc:116:execute$19705  = 1'b1;
    // UUT.tp_check.$auto$async2sync.\cc:116:execute$19729  = 1'b1;
    // UUT.tp_check.$auto$async2sync.\cc:116:execute$19735  = 1'b1;
    // UUT.tp_check.$auto$async2sync.\cc:116:execute$19741  = 1'b1;
    UUT.tp_check.started = 1'b0;

    // state 0
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_arresp = 2'b00;
    PI_pc_err = 1'b0;
    PI_src = 2'b00;
    PI_rready = 3'b000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_ar_rd_gnt = 8'b00000000;
    PI_rst_n = 1'b0;
    PI_araddr = 18'b000000000000000000;
    PI_arid = 8'b00000000;
    PI_arvalid = 1'b0;
    PI_ar_port_id = 5'b00000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b11;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b000000000000000000;
      PI_arid <= 8'b00000000;
      PI_arvalid <= 1'b1;
      PI_ar_port_id <= 5'b00000;
    end

    // state 2
    if (cycle == 1) begin
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b000000000000000000;
      PI_arid <= 8'b00000000;
      PI_arvalid <= 1'b0;
      PI_ar_port_id <= 5'b00000;
    end

    genclock <= cycle < 2;
    cycle <= cycle + 1;
  end
endmodule
