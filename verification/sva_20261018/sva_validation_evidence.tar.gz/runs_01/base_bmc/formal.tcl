# Native SVA candidate; real FormalMC 2024 execution is not certified.
set here [file dirname [file normalize [info script]]]
cd $here
read_design -top cmdbuf_rd_formal -sysv -mfcu -f native_instrumented.f
def_clk clk
prove
show_prop -summary
exit
