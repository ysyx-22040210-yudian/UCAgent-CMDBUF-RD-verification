from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, time

ROOT=Path(__file__).resolve().parent
BUILD=ROOT/'build'; BUILD.mkdir(exist_ok=True)
TOOLS=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
ENV=os.environ.copy(); ENV['PATH']=str(TOOLS)+os.pathsep+ENV['PATH']
records=[]

def run(name, command, expected_failure=False, required_text=None, timeout=600):
    start=time.time()
    log=BUILD/(name+'.log')
    with log.open('w') as handle:
        proc=subprocess.run(command,cwd=str(ROOT),env=ENV,stdout=handle,stderr=subprocess.STDOUT,timeout=timeout)
    text=log.read_text(errors='replace')
    passed=(proc.returncode!=0 if expected_failure else proc.returncode==0)
    if required_text: passed=passed and required_text in text
    rec={'name':name,'command':command,'status':'PASS' if passed else 'FAIL','returncode':proc.returncode,
         'expected_failure':expected_failure,'elapsed_seconds':round(time.time()-start,2),'log':str(log.relative_to(ROOT))}
    records.append(rec); print(json.dumps(rec),flush=True)
    if not passed: raise RuntimeError(name+' failed; see '+str(log))
    return rec

try:
    run('iverilog_version',['/usr/local/bin/iverilog','-V'])
    run('verilator_version',[str(TOOLS/'verilator'),'--version'])
    rtl=['rtl/cmdbuf_rd.sv','rtl/cmdbuf_rd_cmd.sv','rtl/cmdbuf_rd_otb.sv']
    tb='simulation/four_state/rd_mem_status_four_state_tb.sv'
    run('four_state_compile',['/usr/local/bin/iverilog','-g2012','-DSYNTHESIS','-s','rd_mem_status_four_state_tb','-o','build/four_state.vvp',*rtl,tb])
    run('four_state_sim',['/usr/local/bin/vvp','build/four_state.vvp'],required_text='PASS FOUR_STATE_INTERFACE combinations=64 observations=128')
    # A local control copy recreates the old two-state ports, without altering
    # the actual validation inputs. The same test must catch the lost X.
    legacy=BUILD/'old_bit_control'; legacy.mkdir()
    legacy_files=[]
    for source in rtl:
        text=(ROOT/source).read_text(encoding='utf-8')
        if source.endswith(('cmdbuf_rd.sv','cmdbuf_rd_cmd.sv')):
            assert text.count('input wire [1:0] rd_mem_status [7:0]')==1
            text=text.replace('input wire [1:0] rd_mem_status [7:0]','input bit [1:0] rd_mem_status [7:0]')
        dest=legacy/Path(source).name;dest.write_text(text,encoding='utf-8');legacy_files.append(str(dest))
    run('old_bit_compile',['/usr/local/bin/iverilog','-g2012','-DSYNTHESIS','-s','rd_mem_status_four_state_tb','-o','build/old_bit.vvp',*legacy_files,tb])
    run('old_bit_error_reproduced',['/usr/local/bin/vvp','build/old_bit.vvp'],expected_failure=True,required_text='FOUR_STATE_MISMATCH')
    run('native_formal_compile',[str(TOOLS/'verilator'),'--lint-only','--assert','-Wno-WIDTHEXPAND','-Wno-WIDTHTRUNC','--top-module','cmdbuf_rd_formal','-f','formal/protocol_20261021/native.f'])
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures=[
            pool.submit(run,'native_sva_regression',['make','-f','simulation/env_base/env/Makefile',
                'PROJECT_CONFIG=simulation/env_base/projects/cmdbuf_rd_sva.mk','VERILATOR='+str(TOOLS/'verilator'),
                'BUILD_DIR='+str(BUILD/'verilator'),'RESULT_DIR='+str(BUILD/'simulation'),'JOBS=2','lint','run-all']),
            pool.submit(run,'sby_regression',['python3','formal/protocol_20261021/run.py','--output',str(BUILD/'formal'),'--tools',str(TOOLS),'--jobs','2'],timeout=900),
        ]
        for future in futures: future.result()
    cases=[]
    for path in sorted((BUILD/'simulation').glob('*.json')):
        entry=json.loads(path.read_text())
        if 'checks_failed' in entry:
            assert entry['status']=='pass',path.name
            cases.append({'name':path.stem,'checks':entry['checks'],'cycles':entry['cycles'],'status':entry['status']})
    assert len(cases)==33,len(cases)
    formal=json.loads((BUILD/'formal/results.json').read_text())
    assert all(job['status'].startswith('PASS') for job in formal)
    summary={'status':'PASS','workspace':str(ROOT),'records':records,'four_state_combinations':64,'four_state_observations':128,
             'old_bit_control':'Expected mismatch reproduced; X was converted to zero.',
             'simulation_cases':cases,'formal_jobs':formal,
             'scope':'Four-state simulator checks port transport of 0/1/X/Z. Verilator/SBY cover defined binary transactions, not four-state functional correctness. FormalMC and encrypted-RTL equivalence were not run.'}
except Exception as exc:
    summary={'status':'FAIL','workspace':str(ROOT),'records':records,'error':str(exc)}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'summary':'summary.json'}),flush=True)
raise SystemExit(0 if summary['status']=='PASS' else 1)
