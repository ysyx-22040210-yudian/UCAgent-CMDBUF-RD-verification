from pathlib import Path
import json, os, subprocess, time

root=Path(__file__).resolve().parent
build=root/'build'
tools=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
env=os.environ.copy()
env['PATH']=str(tools)+os.pathsep+env['PATH']
# The VM has libatomic, but devtoolset-11 does not search this linker directory.
# Add it only for this build process; do not change the VM or RTL.
env['LIBRARY_PATH']='/usr/lib/gcc/x86_64-redhat-linux/4.8.5'+os.pathsep+env.get('LIBRARY_PATH','')
command=['make','-f','simulation/env_base/env/Makefile',
 'PROJECT_CONFIG=simulation/env_base/projects/cmdbuf_rd_sva.mk','VERILATOR='+str(tools/'verilator'),
 'BUILD_DIR='+str(build/'verilator'),'RESULT_DIR='+str(build/'simulation'),'JOBS=2','lint','run-all']
started=time.time()
with (build/'native_sva_linkfix.log').open('w') as log:
    proc=subprocess.run(command,cwd=str(root),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
cases=[]
for path in sorted((build/'simulation').glob('*.json')):
    data=json.loads(path.read_text(encoding='utf-8'))
    if 'checks_failed' in data:
        cases.append({'name':path.stem,'checks':data['checks'],'cycles':data['cycles'],'status':data['status'],'checks_failed':data['checks_failed']})
passed=proc.returncode==0 and len(cases)==33 and all(c['status']=='pass' and c['checks_failed']==0 for c in cases)
report={'status':'PASS' if passed else 'FAIL','command':command,'returncode':proc.returncode,
        'environment_change':{'LIBRARY_PATH':env['LIBRARY_PATH']},'source_change':False,
        'elapsed_seconds':round(time.time()-started,2),'simulation_cases':cases,
        'log':'build/native_sva_linkfix.log'}
(root/'simulation_retry.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'cases':len(cases)}),flush=True)
