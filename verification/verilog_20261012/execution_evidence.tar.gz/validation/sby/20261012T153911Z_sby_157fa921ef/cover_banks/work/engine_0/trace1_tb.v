`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [7:0] PI_arid;
  reg [1:0] PI_src;
  reg [2:0] PI_rready;
  reg [4:0] PI_ar_port_id;
  reg [7:0] PI_ar_rd_gnt;
  reg [127:0] PI_mem_rdata;
  reg [0:0] PI_arvalid;
  wire [0:0] PI_clk = clock;
  reg [15:0] PI_rd_mem_status;
  reg [7:0] PI_rw_rd_gnt;
  reg [0:0] PI_rst_n;
  reg [17:0] PI_araddr;
  reg [1:0] PI_arresp;
  reg [0:0] PI_pc_err;
  cmdbuf_rd_formal UUT (
    .arid(PI_arid),
    .src(PI_src),
    .rready(PI_rready),
    .ar_port_id(PI_ar_port_id),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .mem_rdata(PI_mem_rdata),
    .arvalid(PI_arvalid),
    .clk(PI_clk),
    .rd_mem_status(PI_rd_mem_status),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .rst_n(PI_rst_n),
    .araddr(PI_araddr),
    .arresp(PI_arresp),
    .pc_err(PI_pc_err)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18066  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18072  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18078  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18084  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18090  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18096  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18102  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18108  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18114  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18120  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18126  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18132  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18138  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18144  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18150  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$18156  = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16849 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16850 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16851 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16852 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16853 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16854 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16855 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16856 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16857 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16858 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16859 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16860 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16861 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16862 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16863 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16864 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16865 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16866 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16867 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16868 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16869 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16870 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16871 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16872 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16873 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16874 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16875 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16876 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16877 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16878 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16879 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16880 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16881 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16882 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16883 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16884 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16885 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16886 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16887 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16888 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16889 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16890 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16891 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16892 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16893 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16894 = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16895 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16896 = 18'b000000000000000101;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17231 = 9'b111000110;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17236 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17241 = 9'b000001000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17246 = 4'b0001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17251 = 2'b01;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17256 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17261 = 4'b0010;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17266 = 3'b010;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17271 = 12'b000000000100;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17286 = 4'b0001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17291 = 4'b0001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17296 = 4'b0001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17301 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17306 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17311 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17316 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17321 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17326 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17331 = 18'b000000000000000100;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17336 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17341 = 18'b000000000000000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17346 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17351 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17356 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17361 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17366 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17371 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17376 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17381 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17386 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17391 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17396 = 8'b00000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17401 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17406 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17411 = 8'b00000010;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17416 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17421 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17426 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17431 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17436 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17441 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17446 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17451 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17456 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17461 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17466 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17471 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17476 = 5'b00001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17481 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17486 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17491 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17496 = 2'b01;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17501 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17506 = 2'b10;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17511 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17516 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17521 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17526 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17531 = 9'b111110111;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17536 = 9'b111111111;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17541 = 9'b010000001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17546 = 9'b000001111;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17551 = 9'b010010110;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17556 = 9'b001100001;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17561 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17566 = 9'b101000011;
    UUT.dut.u_cmd.cv_hist = 8'b00000000;
    UUT.dut.u_cmd.\fm_addr_q[0]  = 18'b000000000000010000;
    UUT.dut.u_cmd.\fm_addr_q[1]  = 18'b000000000001000000;
    UUT.dut.u_cmd.\fm_addr_q[2]  = 18'b000000000000110000;
    UUT.dut.u_cmd.\fm_addr_q[3]  = 18'b000000000000001000;
    UUT.dut.u_cmd.\fm_addr_q[4]  = 18'b000000000000110000;
    UUT.dut.u_cmd.\fm_addr_q[5]  = 18'b000000000000110000;
    UUT.dut.u_cmd.\fm_addr_q[6]  = 18'b000000000001001000;
    UUT.dut.u_cmd.\fm_addr_q[7]  = 18'b000000000000010000;
    UUT.dut.u_cmd.\fm_addr_q[8]  = 18'b000000000000110000;
    UUT.dut.u_cmd.\fm_age_q[0]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[1]  = 4'b1100;
    UUT.dut.u_cmd.\fm_age_q[2]  = 4'b0100;
    UUT.dut.u_cmd.\fm_age_q[3]  = 4'b0001;
    UUT.dut.u_cmd.\fm_age_q[4]  = 4'b1110;
    UUT.dut.u_cmd.\fm_age_q[5]  = 4'b1010;
    UUT.dut.u_cmd.\fm_age_q[6]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[7]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[8]  = 4'b0011;
    UUT.dut.u_cmd.fm_attempt_bank_q = 3'b000;
    UUT.dut.u_cmd.fm_attempt_id_q = 4'b1000;
    UUT.dut.u_cmd.fm_attempt_q = 1'b1;
    UUT.dut.u_cmd.fm_done_q = 9'b000000000;
    UUT.dut.u_cmd.fm_issued_q = 9'b000100000;
    UUT.dut.u_cmd.\fm_left_q[0]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[1]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[2]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[3]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[4]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[5]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[6]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[7]  = 3'b000;
    UUT.dut.u_cmd.\fm_left_q[8]  = 3'b000;
    UUT.dut.u_cmd.fm_live_q = 9'b010111111;
    UUT.dut.u_cmd.fm_rr_q = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[0]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[1]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[2]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[3]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[4]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[5]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[6]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[7]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[8]  = 2'b00;
    UUT.dut.u_otb._witness_.anyinit_procdff_16758 = 9'b000000001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16763 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16768 = 9'b000000001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16773 = 9'b000000001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16788 = 4'b0001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16793 = 4'b0001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16798 = 4'b0001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16803 = 4'b0010;
    UUT.dut.u_otb._witness_.anyinit_procdff_16808 = 128'b01000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16813 = 128'b00000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16818 = 128'b00000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16823 = 128'b00000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16828 = 128'b00000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16833 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16838 = 128'b00000000000000001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16843 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001;
    UUT.dut.u_otb._witness_.anyinit_procdff_16848 = 128'b00000000000010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.f_started = 1'b0;
    UUT.dut.u_otb.f_data_entry = 4'b0000;

    // state 0
    PI_arid = 8'b00000000;
    PI_src = 2'b00;
    PI_rready = 3'b000;
    PI_ar_port_id = 5'b00000;
    PI_ar_rd_gnt = 8'b00000000;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_arvalid = 1'b0;
    PI_rd_mem_status = 16'b0000000000000100;
    PI_rw_rd_gnt = 8'b00000000;
    PI_rst_n = 1'b0;
    PI_araddr = 18'b000000000000000000;
    PI_arresp = 2'b00;
    PI_pc_err = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_arid <= 8'b00000001;
      PI_src <= 2'b00;
      PI_rready <= 3'b000;
      PI_ar_port_id <= 5'b00001;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arvalid <= 1'b1;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b010000000000101001;
      PI_arresp <= 2'b11;
      PI_pc_err <= 1'b0;
    end

    // state 2
    if (cycle == 1) begin
      PI_arid <= 8'b00001000;
      PI_src <= 2'b00;
      PI_rready <= 3'b011;
      PI_ar_port_id <= 5'b00000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arvalid <= 1'b0;
      PI_rd_mem_status <= 16'b1111111111011111;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b000000000000000001;
      PI_arresp <= 2'b01;
      PI_pc_err <= 1'b0;
    end

    // state 3
    if (cycle == 2) begin
      PI_arid <= 8'b00000100;
      PI_src <= 2'b00;
      PI_rready <= 3'b000;
      PI_ar_port_id <= 5'b00010;
      PI_ar_rd_gnt <= 8'b00100000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arvalid <= 1'b0;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rw_rd_gnt <= 8'b00100000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b000000000000000001;
      PI_arresp <= 2'b10;
      PI_pc_err <= 1'b0;
    end

    // state 4
    if (cycle == 3) begin
      PI_arid <= 8'b00000000;
      PI_src <= 2'b00;
      PI_rready <= 3'b000;
      PI_ar_port_id <= 5'b00000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arvalid <= 1'b0;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rst_n <= 1'b1;
      PI_araddr <= 18'b000000000000000000;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
