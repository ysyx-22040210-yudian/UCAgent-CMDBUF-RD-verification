`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [4:0] PI_ar_port_id;
  reg [17:0] PI_araddr;
  reg [1:0] PI_arresp;
  reg [15:0] PI_rd_mem_status;
  reg [7:0] PI_rw_rd_gnt;
  reg [0:0] PI_pc_err;
  reg [1:0] PI_src;
  reg [7:0] PI_arid;
  reg [127:0] PI_mem_rdata;
  reg [0:0] PI_arvalid;
  reg [7:0] PI_ar_rd_gnt;
  wire [0:0] PI_clk = clock;
  reg [2:0] PI_rready;
  reg [0:0] PI_rst_n;
  cmdbuf_rd_wrapper UUT (
    .ar_port_id(PI_ar_port_id),
    .araddr(PI_araddr),
    .arresp(PI_arresp),
    .rd_mem_status(PI_rd_mem_status),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .pc_err(PI_pc_err),
    .src(PI_src),
    .arid(PI_arid),
    .mem_rdata(PI_mem_rdata),
    .arvalid(PI_arvalid),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .clk(PI_clk),
    .rready(PI_rready),
    .rst_n(PI_rst_n)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5031  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5037  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5043  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5049  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5055  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5061  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5067  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5073  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5079  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5085  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5091  = 1'b1;
    // UUT.u_checker.$auto$async2sync.\cc:116:execute$5103  = 1'b1;
    UUT.u_checker._witness_.anyinit_procdff_4485 = 1'b0;
    UUT.u_checker.uc_past_valid = 1'b0;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4587 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4592 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4597 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4602 = 4'b0000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4607 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4612 = 1'b0;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4617 = 4'b0000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4622 = 3'b000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4627 = 12'b000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4642 = 4'b0000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4647 = 4'b0000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4652 = 4'b0000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4657 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4662 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4667 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4672 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4677 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4682 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4687 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4692 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4697 = 18'b000000000000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4702 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4707 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4712 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4717 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4722 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4727 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4732 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4737 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4742 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4747 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4752 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4757 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4762 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4767 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4772 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4777 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4782 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4787 = 8'b00000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4792 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4797 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4802 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4807 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4812 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4817 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4822 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4827 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4832 = 5'b00000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4837 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4842 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4847 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4852 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4857 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4862 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4867 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4872 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4877 = 2'b00;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4882 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4887 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4892 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4897 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4902 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4907 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4912 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4917 = 9'b000000000;
    UUT.u_dut.u_cmd._witness_.anyinit_procdff_4922 = 9'b000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4497 = 4'b0000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4502 = 9'b000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4522 = 4'b0000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4527 = 4'b0000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4532 = 4'b0000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4537 = 4'b0000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4542 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4547 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4552 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4557 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4562 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4567 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4572 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4577 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.u_dut.u_otb._witness_.anyinit_procdff_4582 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.uc_reset_count = 1'b0;

    // state 0
    PI_ar_port_id = 5'b00000;
    PI_araddr = 18'b000000000000000000;
    PI_arresp = 2'b00;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_pc_err = 1'b0;
    PI_src = 2'b00;
    PI_arid = 8'b00000000;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_arvalid = 1'b0;
    PI_ar_rd_gnt = 8'b00000000;
    PI_rready = 3'b000;
    PI_rst_n = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_ar_port_id <= 5'b00000;
      PI_araddr <= 18'b000000000000000000;
      PI_arresp <= 2'b00;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_arid <= 8'b00000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_arvalid <= 1'b0;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_rst_n <= 1'b1;
    end

    genclock <= cycle < 1;
    cycle <= cycle + 1;
  end
endmodule
