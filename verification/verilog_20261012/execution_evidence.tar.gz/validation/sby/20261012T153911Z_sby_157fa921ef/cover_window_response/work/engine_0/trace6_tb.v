`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [1:0] PI_arresp;
  reg [127:0] PI_mem_rdata;
  reg [0:0] PI_rst_n;
  reg [7:0] PI_ar_rd_gnt;
  reg [2:0] PI_rready;
  reg [7:0] PI_rw_rd_gnt;
  reg [7:0] PI_arid;
  reg [0:0] PI_pc_err;
  wire [0:0] PI_clk = clock;
  reg [1:0] PI_src;
  reg [4:0] PI_ar_port_id;
  reg [15:0] PI_rd_mem_status;
  reg [17:0] PI_araddr;
  reg [0:0] PI_arvalid;
  cmdbuf_rd_formal UUT (
    .arresp(PI_arresp),
    .mem_rdata(PI_mem_rdata),
    .rst_n(PI_rst_n),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .rready(PI_rready),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .arid(PI_arid),
    .pc_err(PI_pc_err),
    .clk(PI_clk),
    .src(PI_src),
    .ar_port_id(PI_ar_port_id),
    .rd_mem_status(PI_rd_mem_status),
    .araddr(PI_araddr),
    .arvalid(PI_arvalid)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17747  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17753  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17759  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17765  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17771  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17777  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17783  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17789  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17795  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17801  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17807  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17813  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17819  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17825  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17831  = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16578 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16579 = 16'b0000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16580 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16581 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16582 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16583 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16584 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16585 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16586 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16587 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16588 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16589 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16590 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16899 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16904 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16909 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16914 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16919 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16924 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16929 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16934 = 3'b000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16939 = 12'b000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16954 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16959 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16964 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16969 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16974 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16979 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16984 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16989 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16994 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16999 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17004 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17009 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17014 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17019 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17024 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17029 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17034 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17039 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17044 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17049 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17054 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17059 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17064 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17069 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17074 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17079 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17084 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17089 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17094 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17099 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17104 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17109 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17114 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17119 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17124 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17129 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17134 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17139 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17144 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17149 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17154 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17159 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17164 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17169 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17174 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17179 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17184 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17189 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17194 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17199 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17204 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17209 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17214 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17219 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17224 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17229 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17234 = 9'b000000000;
    UUT.dut.u_cmd.cv_hist = 8'b00000000;
    UUT.dut.u_cmd.cv_mask_state = 4'b0000;
    UUT.dut.u_cmd.cv_rr_state = 4'b0000;
    UUT.dut.u_cmd.\fm_addr_q[0]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[1]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[2]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[3]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[4]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[5]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[6]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[7]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[8]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_age_q[0]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[1]  = 4'b1000;
    UUT.dut.u_cmd.\fm_age_q[2]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[3]  = 4'b0001;
    UUT.dut.u_cmd.\fm_age_q[4]  = 4'b0001;
    UUT.dut.u_cmd.\fm_age_q[5]  = 4'b0010;
    UUT.dut.u_cmd.\fm_age_q[6]  = 4'b0011;
    UUT.dut.u_cmd.\fm_age_q[7]  = 4'b0110;
    UUT.dut.u_cmd.\fm_age_q[8]  = 4'b0111;
    UUT.dut.u_cmd.fm_attempt_bank_q = 3'b000;
    UUT.dut.u_cmd.fm_attempt_id_q = 4'b0000;
    UUT.dut.u_cmd.fm_attempt_q = 1'b0;
    UUT.dut.u_cmd.fm_done_q = 9'b000000000;
    UUT.dut.u_cmd.\fm_id_q[0]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[1]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[2]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[3]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[4]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[5]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[6]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[7]  = 8'b00000000;
    UUT.dut.u_cmd.\fm_id_q[8]  = 8'b00000000;
    UUT.dut.u_cmd.fm_issued_q = 9'b000000000;
    UUT.dut.u_cmd.\fm_left_q[0]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[1]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[2]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[3]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[4]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[5]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[6]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[7]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[8]  = 3'b100;
    UUT.dut.u_cmd.fm_live_q = 9'b000000000;
    UUT.dut.u_cmd.fm_rr_q = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[0]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[1]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[2]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[3]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[4]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[5]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[6]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[7]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[8]  = 2'b00;
    UUT.dut.u_otb._witness_.anyinit_procdff_16487 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16492 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16497 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16502 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16517 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16522 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16527 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16532 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16537 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16542 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16547 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16552 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16557 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16562 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16567 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16572 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16577 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.f_started = 1'b0;
    UUT.dut.u_otb.f_data_entry = 4'b0000;

    // state 0
    PI_arresp = 2'b00;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_rst_n = 1'b0;
    PI_ar_rd_gnt = 8'b00000000;
    PI_rready = 3'b000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_arid = 8'b00000000;
    PI_pc_err = 1'b0;
    PI_src = 2'b00;
    PI_ar_port_id = 5'b00000;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_araddr = 18'b000000000000000000;
    PI_arvalid = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_araddr <= 18'b000000000001000000;
      PI_arvalid <= 1'b1;
    end

    // state 3
    if (cycle == 2) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000001;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000100000000;
      PI_araddr <= 18'b000000000001100000;
      PI_arvalid <= 1'b1;
    end

    // state 4
    if (cycle == 3) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000100010001;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b1;
    end

    // state 5
    if (cycle == 4) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00010001;
      PI_rready <= 3'b000;
      PI_rw_rd_gnt <= 8'b00010000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0001000100000001;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b1;
    end

    // state 6
    if (cycle == 5) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_rready <= 3'b110;
      PI_rw_rd_gnt <= 8'b00010001;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0001000100000001;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b1;
    end

    // state 7
    if (cycle == 6) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b10000001;
      PI_rready <= 3'b011;
      PI_rw_rd_gnt <= 8'b10000001;
      PI_arid <= 8'b11111111;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b1;
    end

    // state 8
    if (cycle == 7) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b100;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b0;
    end

    // state 9
    if (cycle == 8) begin
      PI_arresp <= 2'b00;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b001;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arid <= 8'b00000000;
      PI_pc_err <= 1'b0;
      PI_src <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_araddr <= 18'b000000000000000000;
      PI_arvalid <= 1'b0;
    end

    genclock <= cycle < 9;
    cycle <= cycle + 1;
  end
endmodule
