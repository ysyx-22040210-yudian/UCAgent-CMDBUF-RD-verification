`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [0:0] PI_pc_err;
  reg [7:0] PI_arid;
  reg [7:0] PI_rw_rd_gnt;
  reg [1:0] PI_arresp;
  reg [17:0] PI_araddr;
  reg [127:0] PI_mem_rdata;
  reg [0:0] PI_rst_n;
  reg [1:0] PI_src;
  reg [15:0] PI_rd_mem_status;
  reg [7:0] PI_ar_rd_gnt;
  reg [2:0] PI_rready;
  reg [0:0] PI_arvalid;
  reg [4:0] PI_ar_port_id;
  wire [0:0] PI_clk = clock;
  cmdbuf_rd_formal UUT (
    .pc_err(PI_pc_err),
    .arid(PI_arid),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .arresp(PI_arresp),
    .araddr(PI_araddr),
    .mem_rdata(PI_mem_rdata),
    .rst_n(PI_rst_n),
    .src(PI_src),
    .rd_mem_status(PI_rd_mem_status),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .rready(PI_rready),
    .arvalid(PI_arvalid),
    .ar_port_id(PI_ar_port_id),
    .clk(PI_clk)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.dut.u_cmd.$auto$async2sync.\cc:107:execute$17736  = 1'b0;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17740  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17746  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17752  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17758  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17764  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17770  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17776  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17782  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17788  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17794  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17800  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17806  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17812  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17818  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17824  = 1'b1;
    // UUT.dut.u_cmd.$auto$async2sync.\cc:116:execute$17830  = 1'b1;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16544 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16545 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16546 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16547 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16548 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16549 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16550 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16551 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16552 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16553 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16554 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16555 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16556 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16557 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16558 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16559 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16560 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16561 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16562 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16563 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16564 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16565 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16566 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16567 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16568 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16569 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16570 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16571 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16572 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16573 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16574 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16575 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16576 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16577 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16578 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16579 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16580 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16581 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16582 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16583 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16584 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16585 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16586 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16587 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16588 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16589 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16590 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16591 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16592 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16593 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16594 = 4'b1000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16595 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16596 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16597 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16598 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16599 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16600 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16601 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16904 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16909 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16914 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16919 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16924 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16929 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16934 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16939 = 3'b000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16944 = 12'b000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16959 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16964 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16969 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16974 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16979 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16984 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16989 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16994 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16999 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17004 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17009 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17014 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17019 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17024 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17029 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17034 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17039 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17044 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17049 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17054 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17059 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17064 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17069 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17074 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17079 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17084 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17089 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17094 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17099 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17104 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17109 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17114 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17119 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17124 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17129 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17134 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17139 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17144 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17149 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17154 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17159 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17164 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17169 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17174 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17179 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17184 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17189 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17194 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17199 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17204 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17209 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17214 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17219 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17224 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17229 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17234 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_17239 = 9'b000000000;
    UUT.dut.u_cmd.cv_5a_a = 4'b0000;
    UUT.dut.u_cmd.cv_5a_b = 4'b0000;
    UUT.dut.u_cmd.cv_5a_state = 4'b0000;
    UUT.dut.u_cmd.cv_aronly = 9'b000000000;
    UUT.dut.u_cmd.cv_failed = 9'b000000000;
    UUT.dut.u_cmd.cv_hist = 8'b00000000;
    UUT.dut.u_cmd.cv_rejected = 1'b0;
    UUT.dut.u_cmd.cv_rejected_src = 2'b00;
    UUT.dut.u_cmd.\fm_addr_q[0]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[1]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[2]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[3]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[4]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[5]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[6]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[7]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_addr_q[8]  = 18'b000000000000000000;
    UUT.dut.u_cmd.\fm_age_q[0]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[1]  = 4'b1000;
    UUT.dut.u_cmd.\fm_age_q[2]  = 4'b0000;
    UUT.dut.u_cmd.\fm_age_q[3]  = 4'b0001;
    UUT.dut.u_cmd.\fm_age_q[4]  = 4'b0001;
    UUT.dut.u_cmd.\fm_age_q[5]  = 4'b0010;
    UUT.dut.u_cmd.\fm_age_q[6]  = 4'b0011;
    UUT.dut.u_cmd.\fm_age_q[7]  = 4'b0110;
    UUT.dut.u_cmd.\fm_age_q[8]  = 4'b0111;
    UUT.dut.u_cmd.fm_attempt_bank_q = 3'b000;
    UUT.dut.u_cmd.fm_attempt_id_q = 4'b0000;
    UUT.dut.u_cmd.fm_attempt_q = 1'b0;
    UUT.dut.u_cmd.fm_done_q = 9'b000000000;
    UUT.dut.u_cmd.fm_issued_q = 9'b000000000;
    UUT.dut.u_cmd.\fm_left_q[0]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[1]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[2]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[3]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[4]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[5]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[6]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[7]  = 3'b100;
    UUT.dut.u_cmd.\fm_left_q[8]  = 3'b100;
    UUT.dut.u_cmd.fm_live_q = 9'b000000000;
    UUT.dut.u_cmd.fm_rr_q = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[0]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[1]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[2]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[3]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[4]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[5]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[6]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[7]  = 2'b00;
    UUT.dut.u_cmd.\fm_src_q[8]  = 2'b00;
    UUT.dut.u_otb._witness_.anyinit_procdff_16453 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16458 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16463 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16468 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16483 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16488 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16493 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16498 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16503 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16508 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16513 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16518 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16523 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16528 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16533 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16538 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16543 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.f_started = 1'b0;
    UUT.dut.u_otb.f_data_entry = 4'b0000;

    // state 0
    PI_pc_err = 1'b0;
    PI_arid = 8'b00000000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_arresp = 2'b00;
    PI_araddr = 18'b000000000000000000;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_rst_n = 1'b0;
    PI_src = 2'b00;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_ar_rd_gnt = 8'b00000000;
    PI_rready = 3'b000;
    PI_arvalid = 1'b0;
    PI_ar_port_id = 5'b00000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_pc_err <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arresp <= 2'b00;
      PI_araddr <= 18'b000000000001000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_src <= 2'b01;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_arvalid <= 1'b1;
      PI_ar_port_id <= 5'b00000;
    end

    // state 2
    if (cycle == 1) begin
      PI_pc_err <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arresp <= 2'b00;
      PI_araddr <= 18'b000000000000000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_src <= 2'b01;
      PI_rd_mem_status <= 16'b0000000000000001;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_arvalid <= 1'b1;
      PI_ar_port_id <= 5'b00000;
    end

    // state 3
    if (cycle == 2) begin
      PI_pc_err <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000001;
      PI_arresp <= 2'b00;
      PI_araddr <= 18'b000000000000000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_src <= 2'b01;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_rready <= 3'b000;
      PI_arvalid <= 1'b0;
      PI_ar_port_id <= 5'b00000;
    end

    // state 4
    if (cycle == 3) begin
      PI_pc_err <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000001;
      PI_arresp <= 2'b00;
      PI_araddr <= 18'b000000000000000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_src <= 2'b01;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_rready <= 3'b000;
      PI_arvalid <= 1'b1;
      PI_ar_port_id <= 5'b00000;
    end

    // state 5
    if (cycle == 4) begin
      PI_pc_err <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_arresp <= 2'b00;
      PI_araddr <= 18'b000000000000000000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
      PI_src <= 2'b00;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_rready <= 3'b000;
      PI_arvalid <= 1'b0;
      PI_ar_port_id <= 5'b00000;
    end

    genclock <= cycle < 5;
    cycle <= cycle + 1;
  end
endmodule
