`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [1:0] PI_src;
  reg [7:0] PI_ar_rd_gnt;
  reg [17:0] PI_araddr;
  reg [7:0] PI_rw_rd_gnt;
  wire [0:0] PI_clk = clock;
  reg [15:0] PI_rd_mem_status;
  reg [2:0] PI_rready;
  reg [0:0] PI_pc_err;
  reg [1:0] PI_arresp;
  reg [0:0] PI_arvalid;
  reg [7:0] PI_arid;
  reg [4:0] PI_ar_port_id;
  reg [127:0] PI_mem_rdata;
  reg [0:0] PI_rst_n;
  cmdbuf_rd_formal UUT (
    .src(PI_src),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .araddr(PI_araddr),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .clk(PI_clk),
    .rd_mem_status(PI_rd_mem_status),
    .rready(PI_rready),
    .pc_err(PI_pc_err),
    .arresp(PI_arresp),
    .arvalid(PI_arvalid),
    .arid(PI_arid),
    .ar_port_id(PI_ar_port_id),
    .mem_rdata(PI_mem_rdata),
    .rst_n(PI_rst_n)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    // UUT.dut.$auto$async2sync.\cc:107:execute$17026  = 1'b0;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17030  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17036  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17042  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17048  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17054  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17060  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17066  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17072  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17078  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17084  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17090  = 1'b1;
    // UUT.dut.$auto$async2sync.\cc:116:execute$17096  = 1'b1;
    UUT.dut._witness_.anyinit_procdff_16042 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16043 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16044 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16045 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16046 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16047 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16048 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16049 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16050 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16051 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16052 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16053 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16054 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16055 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16056 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16057 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16058 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16059 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16060 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16061 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16062 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16063 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16064 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16065 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16066 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16067 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16068 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16069 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16070 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16071 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16072 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16073 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16074 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16075 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16076 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16077 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16078 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16079 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16080 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16081 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16082 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16083 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16084 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16085 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16086 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16087 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16088 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16089 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16090 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16091 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16092 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16093 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16094 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16095 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16096 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16097 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16098 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16099 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16100 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16101 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16102 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16103 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16104 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16105 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16106 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16107 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16108 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16109 = 1'b0;
    UUT.dut._witness_.anyinit_procdff_16110 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16111 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16112 = 4'b0000;
    UUT.dut._witness_.anyinit_procdff_16113 = 4'b0000;
    UUT.dut.\ct_addr[0]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[1]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[2]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[3]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[4]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[5]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[6]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[7]  = 18'b000000000000000000;
    UUT.dut.\ct_addr[8]  = 18'b000000000000000000;
    UUT.dut.ct_done = 9'b000000000;
    UUT.dut.ct_first_data = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.ct_first_data_seen = 1'b0;
    UUT.dut.\ct_id[0]  = 8'b00000000;
    UUT.dut.\ct_id[1]  = 8'b00000000;
    UUT.dut.\ct_id[2]  = 8'b00000000;
    UUT.dut.\ct_id[3]  = 8'b00000000;
    UUT.dut.\ct_id[4]  = 8'b00000000;
    UUT.dut.\ct_id[5]  = 8'b00000000;
    UUT.dut.\ct_id[6]  = 8'b00000000;
    UUT.dut.\ct_id[7]  = 8'b00000000;
    UUT.dut.\ct_id[8]  = 8'b00000000;
    UUT.dut.ct_issued = 9'b000000000;
    UUT.dut.ct_live = 9'b000000000;
    UUT.dut.ct_no_ready = 9'b000000000;
    UUT.dut.ct_pair_ok = 1'b0;
    UUT.dut.ct_pair_state = 4'b0000;
    UUT.dut.\ct_port[0]  = 5'b00000;
    UUT.dut.\ct_port[1]  = 5'b00000;
    UUT.dut.\ct_port[2]  = 5'b00000;
    UUT.dut.\ct_port[3]  = 5'b00000;
    UUT.dut.\ct_port[4]  = 5'b00000;
    UUT.dut.\ct_port[5]  = 5'b00000;
    UUT.dut.\ct_port[6]  = 5'b00000;
    UUT.dut.\ct_port[7]  = 5'b00000;
    UUT.dut.\ct_port[8]  = 5'b00000;
    UUT.dut.\ct_resp[0]  = 2'b00;
    UUT.dut.\ct_resp[1]  = 2'b00;
    UUT.dut.\ct_resp[2]  = 2'b00;
    UUT.dut.\ct_resp[3]  = 2'b00;
    UUT.dut.\ct_resp[4]  = 2'b00;
    UUT.dut.\ct_resp[5]  = 2'b00;
    UUT.dut.\ct_resp[6]  = 2'b00;
    UUT.dut.\ct_resp[7]  = 2'b00;
    UUT.dut.\ct_resp[8]  = 2'b00;
    UUT.dut.ct_reused = 9'b000000000;
    UUT.dut.\ct_src[0]  = 2'b00;
    UUT.dut.\ct_src[1]  = 2'b00;
    UUT.dut.\ct_src[2]  = 2'b00;
    UUT.dut.\ct_src[3]  = 2'b00;
    UUT.dut.\ct_src[4]  = 2'b00;
    UUT.dut.\ct_src[5]  = 2'b00;
    UUT.dut.\ct_src[6]  = 2'b00;
    UUT.dut.\ct_src[7]  = 2'b00;
    UUT.dut.\ct_src[8]  = 2'b00;
    UUT.dut.ct_types = 4'b0000;
    UUT.dut.\fd_data_q[0]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[1]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[2]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[3]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[4]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[5]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[6]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[7]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.\fd_data_q[8]  = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.fd_history_q = 4'b0000;
    UUT.dut.fd_pc_q = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16554 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16559 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16564 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16569 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16574 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16579 = 1'b0;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16584 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16589 = 3'b000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16594 = 12'b000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16609 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16614 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16619 = 4'b0000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16624 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16629 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16634 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16639 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16644 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16649 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16654 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16659 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16664 = 18'b000000000000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16669 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16674 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16679 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16684 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16689 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16694 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16699 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16704 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16709 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16714 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16719 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16724 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16729 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16734 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16739 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16744 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16749 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16754 = 8'b00000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16759 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16764 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16769 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16774 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16779 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16784 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16789 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16794 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16799 = 5'b00000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16804 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16809 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16814 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16819 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16824 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16829 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16834 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16839 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16844 = 2'b00;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16849 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16854 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16859 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16864 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16869 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16874 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16879 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16884 = 9'b000000000;
    UUT.dut.u_cmd._witness_.anyinit_procdff_16889 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16172 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16177 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16182 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16187 = 9'b000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16202 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16207 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16212 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16217 = 4'b0000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16222 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16227 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16232 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16237 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16242 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16247 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16252 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16257 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.dut.u_otb._witness_.anyinit_procdff_16262 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    UUT.f_started = 1'b0;
    UUT.dut.ct_a = 4'b0000;
    UUT.dut.ct_b = 4'b1000;
    UUT.dut.u_otb.f_data_entry = 4'b0000;

    // state 0
    PI_src = 2'b00;
    PI_ar_rd_gnt = 8'b00000000;
    PI_araddr = 18'b000000000000000000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_rready = 3'b000;
    PI_pc_err = 1'b0;
    PI_arresp = 2'b00;
    PI_arvalid = 1'b0;
    PI_arid = 8'b00000000;
    PI_ar_port_id = 5'b00000;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_rst_n = 1'b0;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_src <= 2'b01;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b11;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b10000000;
      PI_ar_port_id <= 5'b10000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 2
    if (cycle == 1) begin
      PI_src <= 2'b10;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 3
    if (cycle == 2) begin
      PI_src <= 2'b00;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000001;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 4
    if (cycle == 3) begin
      PI_src <= 2'b01;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 5
    if (cycle == 4) begin
      PI_src <= 2'b01;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 6
    if (cycle == 5) begin
      PI_src <= 2'b01;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 7
    if (cycle == 6) begin
      PI_src <= 2'b01;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 8
    if (cycle == 7) begin
      PI_src <= 2'b00;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b111;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    // state 9
    if (cycle == 8) begin
      PI_src <= 2'b00;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_araddr <= 18'b000000000000000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_rready <= 3'b000;
      PI_pc_err <= 1'b0;
      PI_arresp <= 2'b00;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_ar_port_id <= 5'b00000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_rst_n <= 1'b1;
    end

    genclock <= cycle < 9;
    cycle <= cycle + 1;
  end
endmodule
