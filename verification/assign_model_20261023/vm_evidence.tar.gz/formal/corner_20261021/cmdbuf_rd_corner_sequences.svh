// 以下状态只跟踪较长 cover 的发生过程，不是 DUT 或约束。
// 所有启动、推进都由真实握手或端口推导的事务记录触发；没有 cover implication。
    reg [3:0] h_prev_due_slot; // 上一采样拍四拍 MEM 日历到期槽号，配合 h_prev_m 使用。
    reg [8:0] h_failed_once; // 各事务是否已出现至少一次仲裁失败，新 AR 复用该槽时清零。
    reg [8:0] h_failed_before_success; // 各事务成功发射时记录其此前是否曾仲裁失败。
    reg [1:0] h_rr012_phase; // 连续三源响应 0/1/2 的覆盖阶段：0 等 0，1 等 1，2 等 2。
    reg [1:0] h_error_sandwich_phase; // XAU0 正常/错误/正常相邻响应的覆盖阶段 0/1/2。
    reg h_rr_gap_seen; // 一次 R 之后是否已出现无响应间隙，下一次 R 后清零。
    reg h_seen_reject; // 是否曾出现有 req 但仲裁失败，供后续恢复场景 cover。
    reg h_seen_partial_ready; // 是否曾出现部分而非全部来源 rready 有效。
    reg [17:0] h_prev_raddr_full; // 最近一次真实 R 返回事务的原始完整地址。
    wire h_hotspot;                        // 至少三条待发命令访问当前请求所在 Bank。
    wire signed [31:0] h_same_bank_count;   // pending 中与 m_attempt_e 的 Bank 相同的条数。
    wire signed [31:0] h_bank_prefix [0:9]; // 扫描前 k 个槽得到的同 Bank 待发条数。
    genvar hs;                             // 编译展开用的逻辑槽扫描索引。
    // 只比较 Bank [5:3]，不比较 half；描述热点覆盖，不改变窗口或发射候选。
    assign h_bank_prefix[0] = 0;
    generate for (hs=0; hs<9; hs=hs+1) begin : history_bank_count
        assign h_bank_prefix[hs+1] = h_bank_prefix[hs] +
            ((pending[hs] && m_addr[hs][5:3]==m_addr[m_attempt_e][5:3]) ? 32'sd1 : 32'sd0);
    end endgenerate
    assign h_same_bank_count = h_bank_prefix[9];
    assign h_hotspot = h_same_bank_count>=3;
    integer hf; // 时序循环的槽索引，用于记录失败及失败后成功。
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            h_prev_due_slot<=0;h_failed_once<=0;h_failed_before_success<=0;
            h_rr012_phase<=0;h_error_sandwich_phase<=0;
            h_rr_gap_seen<=0;h_seen_reject<=0;h_seen_partial_ready<=0;h_prev_raddr_full<=0;
        end else begin
            h_prev_due_slot<=mem_capture_slot;
            if(r_fire) h_prev_raddr_full<=m_addr[rsp_e];
            if(req!=0&&!issue_fire) h_seen_reject<=1;
            if(rready!=0&&rready!=7) h_seen_partial_ready<=1;
            for(hf=0;hf<9;hf=hf+1) begin
                if(ar_fire&&alloc_e==hf) begin
                    h_failed_once[hf]<=0;h_failed_before_success[hf]<=0;
                end else begin
                    if(m_attempt&&m_attempt_e==hf&&!issue_fire) h_failed_once[hf]<=1;
                    if(issue_fire&&m_attempt_e==hf) h_failed_before_success[hf]<=h_failed_once[hf];
                end
            end
            // 连续三拍三源都可响应：第一次 RR 从 0 选择，随后 1、2。
            case(h_rr012_phase)
                0: if(m_rr==0&&eligible==7&&rvalid==1)h_rr012_phase<=1;
                1: h_rr012_phase<=(eligible==7&&rvalid==2)?2'd2:2'd0;
                default: h_rr012_phase<=0;
            endcase
            // 至少一次 R 之后插入无响应拍，随后再响应。起点正确性由 A_RR_CHOICE 检查。
            if(r_fire)h_rr_gap_seen<=0;
            else if(h_prev_r)h_rr_gap_seen<=1;
            // XAU0 三次真实响应为正常/错误/正常；每次均核对全负载。
            // 由于 A_XAU_R_* 检查接收顺序，这三次响应对应同源 AR 的相邻三项。
            if(rvalid[0]) begin
                case(h_error_sandwich_phase)
                    0: if(h_response_matches&&rresp==0) h_error_sandwich_phase<=1;
                    1: h_error_sandwich_phase<=(h_response_matches&&rresp!=0)?2'd2:2'd0;
                    default:h_error_sandwich_phase<=0;
                endcase
            end
        end
    end
