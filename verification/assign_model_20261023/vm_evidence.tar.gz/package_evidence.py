from pathlib import Path
import hashlib,json,subprocess,tarfile
ROOT=Path(__file__).resolve().parent
BUILD=ROOT/'build'
audit=json.loads((ROOT/'equivalence/source_audit.json').read_text())
formal=json.loads((BUILD/'formal/results.json').read_text())
replay=json.loads((BUILD/'replay_all/summary.json').read_text())
sim=[]
for p in sorted((BUILD/'simulation').glob('*.json')):
    d=json.loads(p.read_text())
    if 'checks' in d:sim.append(dict(name=p.stem,**d))
log=(ROOT/'equivalence/comb_equivalence.log').read_text()
assert 'SAT proof finished - no model found: SUCCESS!' in log
assert all(r['status'].startswith('PASS') for r in formal)
assert all(x['status']=='pass' and x['checks_failed']==0 for x in sim)
assert len(sim)==32 and not replay['failed'] and replay['traces']==576
source_files=[ROOT/x['path'] for x in audit['files']]+[ROOT/'rtl'/n for n in ('cmdbuf_rd.sv','cmdbuf_rd_cmd.sv','cmdbuf_rd_otb.sv')]
source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
summary=dict(status='PASS',scope='当前生效 formal 参考模型的 assign 改写与中文注释；RTL 未改动。',
    vm_run_directory=str(ROOT),source_audit=audit,
    combinational_equivalence=dict(status='PASS',outputs=65,state_domain=audit['comb_equivalence_state_domain'],
        note='任意二值输入与共享状态，在参考数组索引合法的范围内比较旧/新组合函数；正式 SVA 的 assume 未修改。'),
    sby=dict(bmc_depth=10,bmc_assert_instances=156,normal_assume_instances=11,
        unbounded_proved=['A_REQ_ONEHOT','A_R_ONEHOT','A_R_READY'],
        newly_searched_cover_instances=sum(x['counts']['cover'] for x in formal if x['mode']=='cover'),
        jobs=[{k:v for k,v in x.items() if k not in ('covers','reached_lines')} for x in formal]),
    simulation=dict(cases=len(sim),cycles=sum(x['cycles'] for x in sim),checks=sum(x['checks'] for x in sim),failed=[]),
    native_replay=dict(traces=replay['traces'],cycles=replay['cycles'],failed=replay['failed'],
        corner_cover_labels=len([x for x in replay['native_cover_labels'] if x.startswith('C_CC_')]),
        source=replay['source'],guided_historical_witness='ENT-12; replay is not an unguided re-proof'),
    limits=['156 个 assert 的完整集合仅完成 10 拍 BMC；只有列出的 3 个端口属性有无界证明。',
            '本轮运行工具是 SBY/Yosys/Verilator；未在目标 FormalMC 2024 上执行。',
            '不新增复位或 X/Z 测试；工具通过一次复位初始化 RTL 与检查器。'],
    source_sha256=source_hashes)
(ROOT/'final_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Preserve inputs, logs and executable trace evidence, excluding generated tool binaries/databases.
items=set()
for folder in ('equivalence','rtl','formal','simulation','build/replay_all','build/simulation'):
    items.update(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ('inputs.tar.gz','run_validation.py','run_replay.py','package_evidence.py','summary.json','final_summary.json','run.log','replay.log'):
    items.add(ROOT/name)
items.update(BUILD.glob('*.log'))
items.add(BUILD/'formal/results.json');items.add(BUILD/'formal/property_inventory.json')
for folder in (BUILD/'formal').iterdir():
    if not folder.is_dir():continue
    items.update(p for p in folder.iterdir() if p.is_file())
    for name in ('status','logfile.txt'):
        p=folder/'run'/name
        if p.exists():items.add(p)
    items.update((folder/'run/engine_0').glob('trace*.vcd'))
    items.update((folder/'run/engine_0').glob('*.log'))
manifest={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(items)}
(ROOT/'evidence_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(ROOT/'compact_evidence.tar.gz','w:gz') as tar:
    for p in sorted(items):tar.add(p,arcname=str(p.relative_to(ROOT)))
    tar.add(ROOT/'evidence_manifest.json',arcname='evidence_manifest.json')
print(json.dumps(dict(status='PASS',files=len(items),archive_bytes=(ROOT/'compact_evidence.tar.gz').stat().st_size,
                     simulation=summary['simulation'],native_replay=summary['native_replay'])),flush=True)
