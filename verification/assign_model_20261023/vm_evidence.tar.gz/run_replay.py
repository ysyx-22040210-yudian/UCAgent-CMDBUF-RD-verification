from pathlib import Path
import hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parent
PRIOR=Path('/root/cmdbuf_rd/corner_sva_20261021_v1/build')
TOOLS=Path('/home/ucagent-lab/portable-distributions/UCAgent-Studio-0.3.1-linux-x86_64/oss-cad-suite/bin')
env=os.environ.copy();env['PATH']=str(TOOLS)+os.pathsep+env['PATH'];env['LIBRARY_PATH']='/usr/lib/gcc/x86_64-redhat-linux/4.8.5'
args=[str(TOOLS/'verilator'),'--cc','--exe','--build','--assert','--coverage-user','--top-module','cmdbuf_rd_formal','--prefix','Vcmdbuf_rd',
      '--Mdir',str(ROOT/'build/replay_current'),'-o','replay','-j','2','--language','1800-2017','-Wno-WIDTHEXPAND','-Wno-WIDTHTRUNC',
      '-f','formal/corner_20261021/native.f',str(ROOT/'formal/corner_20261021/replay.cpp')]
with (ROOT/'build/replay_build.log').open('w') as f:
    p=subprocess.run(['/bin/bash','-c','source /opt/rh/devtoolset-11/enable && exec "$@"','build-replay']+args,cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'replay build'
with (ROOT/'build/replay.log').open('w') as f:
    p=subprocess.run(['python3','formal/corner_20261021/replay.py','--formal',str(PRIOR/'formal'),'--formal',str(PRIOR/'formal_retry'),'--formal',str(PRIOR/'formal_guided'),
        '--sim','build/replay_current/replay','--output','build/replay_all'],cwd=str(ROOT),env=env,stdout=f,stderr=subprocess.STDOUT)
    assert p.returncode==0,'replay failed'
summary=json.loads((ROOT/'build/replay_all/summary.json').read_text())
summary['source']='Existing positive SBY witnesses, replayed on the current native unlowered checker; guided ENT12 witness retains its historical provenance.'
summary['inputs_sha256']={}
for result in summary['results']:
    p=Path(result['trace']);summary['inputs_sha256'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
(ROOT/'build/replay_all/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'traces':summary['traces'],'cycles':summary['cycles'],'failures':len(summary['failed']),
                  'corner_cover_labels':len([x for x in summary['native_cover_labels'] if x.startswith('C_CC_')])}),flush=True)
