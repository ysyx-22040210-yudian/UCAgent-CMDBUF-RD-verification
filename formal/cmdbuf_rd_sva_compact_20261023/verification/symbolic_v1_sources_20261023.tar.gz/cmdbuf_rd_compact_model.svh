// 精简模型：针对全部输出口建立数量与来源检查，不重建 CMDBUF/OTB 的九条事务。
// watch_* 是检查器的任意固定参数，不是 DUT 输入，不得固定为 0，也不得绑定当前输出。
// 对每个可能的 watch 值，balance=历史输入匹配次数-历史输出匹配次数。
// 输出匹配 watch 时要求拍初 balance>0，等价于该值在未消费多重集合中至少还有一份。
// 这是完整字段相等比较，不是随机抽样、截低位或哈希；字段之间仍不要求属于同一命令。
// 所有组合逻辑采用 assign；下面的 always 仅维护跨拍计数和少量历史。

    wire ar_fire; // 按 src 对应 ready 真正接受一条 AR。
    wire r_fire; // 本拍任一 R 实际握手，单拍最多一条由协议断言检查。
    wire issue_fire; // req 与两个 grant 同 Bank 成功，才算消费一条待发命令。
    wire watched_source_valid; // watch_src 是 0/1/2 时有效；取 3 不约束 DUT，只关闭该源相关前件。
    wire watched_rvalid; // 本拍 R 是否返回给任意固定的被观察来源。
    wire watched_rfire; // 本拍该来源 R 是否实际握手。
    // 只有对应来源的 ready 有效才接收；非法 src 不访问越界数组位。
    assign ar_fire = arvalid && src<2'd3 && ((src<2'd3) ? arready[src] : 1'b0);
    // 单独观察握手，不根据期望的响应次序推进模型。
    assign r_fire = |(rvalid & rready);
    // 必须在同一 Bank 位同时得到两种 grant，失败请求不扣待发数。
    assign issue_fire = |(req & ar_rd_gnt & rw_rd_gnt);
    // 参数全取值保留，包括无意义的编码 3；不能把真实输入来源也约束成 watch_src。
    assign watched_source_valid = watch_src<2'd3;
    // 直接取被观察来源的 valid，不需要重建 RR，也不需要对 rvalid 做优先编码。
    assign watched_rvalid = watched_source_valid ? rvalid[watch_src] : 1'b0;
    // 消费标记同时考虑该来源 ready；rvalid/ready 的一致性另有精确断言。
    assign watched_rfire = watched_source_valid ? (rvalid[watch_src] && rready[watch_src]) : 1'b0;

    // 1. 精确控制账本：这里只需 3 个来源计数、待发计数、完成计数和四拍事件日历。
    reg [3:0] occupied [0:2]; // 各源已接收 AR 减已回收 R，合法范围 0..7。
    reg [3:0] waiting; // 拍初未成功发射数量，合法范围 0..9。
    reg [3:0] completed; // 拍初已捕获 MEM 但未返回 R 的总数，合法范围 0..9。
    reg [3:0] due; // 成功事件四拍移位；N 成功，N+4 采样到 due[3]。
    wire mem_due; // 唯一合法 MEM 捕获拍；非到期拍不消费 MEM 数据和 pc_err。
    wire [4:0] pending_now; // 本拍待发输出，含当前 AR 加一和成功发射减一，扩位可发现下溢。
    wire [4:0] occupied_next [0:2]; // 扣当前 R、加当前 AR 后的各源占用，保留额外位。
    wire [4:0] after_r [0:2]; // 本拍 R 已扣除、AR 尚未加入的准入计算数量。
    wire [4:0] shared_part [0:2]; // 每源超过一项保留空间的共享消耗。
    wire [3:0] reserve_part [0:2]; // 空来源也占一项预算，防止预留被其他来源耗尽。
    wire [6:0] total_after_r; // 回收后的总占用，供 arready 判断是否有物理空间。
    wire [6:0] shared_after_r; // 回收后的共享空间使用量，最大允许六项。
    wire [5:0] total; // 拍初总占用，不通过 DUT 物理 entry 位图计算。
    wire [5:0] reserved_total; // 总占用加空来源首项保留，不超过九。
    wire [2:0] expected_ready; // 三源本拍准确准入结果，不依赖当前 src/arvalid。
    wire [4:0] completed_after_r; // 只扣当前 R 的已捕获数量，不能借用当前 MEM 数据。
    wire [4:0] completed_next; // 加入本拍 MEM 捕获后的下拍完成数量。
    genvar s; // 展开三个来源的简单算术，非事务槽索引。
    // 到期事件只来自双 grant 成功的四拍历史。
    assign mem_due = due[3];
    // pending_cnt 是本拍组合数量，不能晚一拍，也不能在失败 req 时扣减。
    assign pending_now = {1'b0,waiting}+{4'b0,ar_fire}-{4'b0,issue_fire};
    generate for (s=0; s<3; s=s+1) begin : admission
        // 先扣当前 R，因此允许九项全满时回收和接收同拍发生。
        assign after_r[s] = {1'b0,occupied[s]}-{4'b0,(rvalid[s] && rready[s])};
        // 单来源第一项使用保留空间，其余部分才计入共享六项。
        assign shared_part[s] = after_r[s]!=0 ? after_r[s]-5'd1 : 5'd0;
        // 原先为空的来源保留一项，即使另两个来源仍在持续输入。
        assign reserve_part[s] = occupied[s]!=0 ? occupied[s] : 4'd1;
        // 有总空间且有本源可用预算时 ready=1；三个位可以同时为 1。
        assign expected_ready[s] = rst_n && total_after_r<7'd9 &&
                                   (after_r[s]==0 || shared_after_r<7'd6);
        // 再加本拍该源 AR；扩位的结果独立检查后才截取保存。
        assign occupied_next[s] = after_r[s]+{4'b0,(ar_fire && src==s)};
    end endgenerate
    // 对回收后的数量求和，判断本拍物理可分配空间。
    assign total_after_r = {2'b0,after_r[0]}+{2'b0,after_r[1]}+{2'b0,after_r[2]};
    // 对超出首项预留的部分求和，准确处理 7/0/0、4/4/0 等边界。
    assign shared_after_r = {2'b0,shared_part[0]}+{2'b0,shared_part[1]}+{2'b0,shared_part[2]};
    // 当前总量由三个独立来源账本得到。
    assign total = {2'b0,occupied[0]}+{2'b0,occupied[1]}+{2'b0,occupied[2]};
    // 预算检查与是否有请求无关，不能让一个来源侵占其他来源的首项。
    assign reserved_total = {2'b0,reserve_part[0]}+{2'b0,reserve_part[1]}+{2'b0,reserve_part[2]};
    // R 只能消费拍初已完成的记录；当前到期 MEM 不提供同拍旁路资格。
    assign completed_after_r = {1'b0,completed}-{4'b0,r_fire};
    // 保存当前捕获后，最早下一采样拍才可返回该数据。
    assign completed_next = completed_after_r+{4'b0,mem_due};

    // 2. 任意值账本：五个四位计数替代五套九项查找表，没有槽分配、删除或 payload RAM。
    // 下标固定含义：0=下游命令地址；1=同源 ID；2=同源 port；3=同源低地址；4=全局数据。
    reg [3:0] balance [0:4]; // 各任意固定值尚未消费的出现次数；不是五条命令。
    wire [4:0] balance_next [0:4]; // 扩位计算可发现 0-1 或超过容量，避免截断掩盖错误。
    wire [4:0] put_match; // 当前输入是否增加对应任意值的一个出现次数。
    wire [4:0] take_match; // 当前成功发射或 R 握手是否消费对应值一次。
    wire command_query; // 当前 req/arb_addr 是否联合等于 watch_cmd。
    wire id_query; // 当前响应是否属于 watch_src 且 rid==watch_id。
    wire port_query; // 当前响应是否属于 watch_src 且 port==watch_port。
    wire low_addr_query; // 当前响应是否属于 watch_src 且 raddr==watch_low_addr。
    wire data_query; // 当前有效响应的完整 128 位数据是否等于 watch_data。
    reg command_fresh; // 上一采样拍刚接收了一个 watch_cmd，当前仍处于 C2，不能作为 C3 命令。
    reg command_idle_prev; // 上一采样拍 watch_cmd 的 Bank/half 是否空闲。
    wire [3:0] watched_occupied; // 被观察来源当前占用；watch_src=3 时默认零。
    genvar v; // 五个任意值计数器展开编号，与 CMDBUF entry 无关。
    // watch_cmd[14:3] 对应 araddr[17:6]，[2:0] 对应 Bank；请求向量直接查位，无优先编码。
    assign command_query = req[watch_cmd[2:0]] && arb_addr==watch_cmd[14:3];
    // 每个 R 字段独立比较；此规则不证明 ID 与其他字段属于同一命令。
    assign id_query = watched_rvalid && rid==watch_id;
    // 同源 port 值出现过且未消费即可，不要求和 rid 命中相同事务。
    assign port_query = watched_rvalid && r_port_id==watch_port;
    // 检查完整三位低地址，不再保存九个低地址副本。
    assign low_addr_query = watched_rvalid && raddr==watch_low_addr;
    // 完整 128 位相等；这里没有截位或哈希碰撞，但不绑定 source/ID。
    assign data_query = (|rvalid) && rdata==watch_data;
    // 只按实际 AR 接收增加待发地址的出现次数。
    assign put_match[0] = ar_fire && araddr[17:3]==watch_cmd;
    // 只有当前匹配命令真正双 grant 成功才扣一次，失败重试保留数量。
    assign take_match[0] = issue_fire && command_query;
    // 同源 ID 输入事件，允许同一 ID 重复多次，不添加唯一性 assume。
    assign put_match[1] = ar_fire && src==watch_src && arid==watch_id;
    // R 实际握手才消费一个相同来源、相同 ID 的出现次数。
    assign take_match[1] = watched_rfire && rid==watch_id;
    // 同源 port 输入独立累计。
    assign put_match[2] = ar_fire && src==watch_src && ar_port_id==watch_port;
    // 同源 port 输出独立消费。
    assign take_match[2] = watched_rfire && r_port_id==watch_port;
    // 同源三位低地址输入独立累计。
    assign put_match[3] = ar_fire && src==watch_src && araddr[2:0]==watch_low_addr;
    // 同源低地址输出独立消费。
    assign take_match[3] = watched_rfire && raddr==watch_low_addr;
    // 数据仅在四拍到期时计入；无 MEM-valid 口，不能每拍都累计数据。
    assign put_match[4] = mem_due && mem_rdata==watch_data;
    // 全局 R 实际消费一次相同数据，重复数据的其他出现次数继续保留。
    assign take_match[4] = r_fire && rdata==watch_data;
    generate for (v=0; v<5; v=v+1) begin : value_count
        // 同拍输入输出相抵；资格断言检查拍初 balance，因此不允许当前输入给当前输出兜底。
        assign balance_next[v] = {1'b0,balance[v]}+{4'b0,put_match[v]}-{4'b0,take_match[v]};
    end endgenerate
    // 来源参数越界时不读取 occupied[3]；合法来源仍由 Formal 任意选择并检查。
    assign watched_occupied = watched_source_valid ? occupied[watch_src] : 4'd0;

    // 3. rresp：两个 pc 数量边界加一个被观察来源的越界数量，不保存逐事务错误表。
    reg [3:0] outside; // watch_src 中尚未被 11 响应消费的地址越界标记数量。
    wire [4:0] outside_next; // 当前 AR 越界标记加一、同源 R=11 减一后的扩位值。
    reg [3:0] bad_low; // 未消费 MEM 返回中 pc_err=1 的可能数量下界。
    reg [3:0] bad_high; // 未消费 MEM 返回中 pc_err=1 的可能数量上界。
    wire [3:0] bad_low_after_r; // 消费当前响应后的 pc=1 下界。
    wire [4:0] bad_high_after_r; // 消费当前响应后的 pc=1 上界，不能超过剩余完成数量。
    wire [4:0] bad_low_next; // 加入当前 MEM 的 pc_err 后的下界，扩位检查范围。
    wire [4:0] bad_high_next; // 加入当前 MEM 的 pc_err 后的上界。
    wire captured_bad; // 只有到期并且 pc_err=1 才增加一个坏数据标记。
    // 11 响应必须能消费同源的一个越界标记；不证明该标记和本拍 rid 配对。
    assign outside_next = {1'b0,outside}+{4'b0,(ar_fire && src==watch_src && arresp==2'b11)}
                                        -{4'b0,(watched_rfire && rresp==2'b11)};
    // 01 必须消费一个坏标记；11 可以消费坏标记，也可因地址错误优先遮住正常标记。
    assign bad_low_after_r = r_fire && rresp!=2'b00 && bad_low!=0 ? bad_low-4'd1 : bad_low;
    // 01 的上界减一；00 或 11 后，上界至多等于剩余完成数。
    assign bad_high_after_r = !r_fire ? {1'b0,bad_high} :
        (rresp==2'b01 ? (bad_high!=0 ? {1'b0,bad_high}-5'd1 : 5'd0) :
                       ({1'b0,bad_high}>completed_after_r ? completed_after_r : {1'b0,bad_high}));
    // 非捕获拍的 pc_err 不进入错误账本。
    assign captured_bad = mem_due && pc_err;
    // 当前捕获的数据只能增加下一拍的可能坏数据数量。
    assign bad_low_next = {1'b0,bad_low_after_r}+{4'b0,captured_bad};
    // 上下界同时加同一个新 pc 标记，保留区间精度。
    assign bad_high_next = bad_high_after_r+{4'b0,captured_bad};

    integer i; // 时序循环索引，只更新三个来源和五个计数，不扫描事务 entry。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            waiting<=0; completed<=0; due<=0; command_fresh<=0; command_idle_prev<=0;
            outside<=0; bad_low<=0; bad_high<=0;
            for (i=0; i<3; i=i+1) occupied[i]<=0;
            for (i=0; i<5; i=i+1) balance[i]<=0;
        end else begin
            // 所有扩位 next 值都另有 assert，不能以截断或饱和吞掉错误。
            waiting<=pending_now[3:0]; completed<=completed_next[3:0];
            due<={due[2:0],issue_fire};
            for (i=0; i<3; i=i+1) occupied[i]<=occupied_next[i][3:0];
            for (i=0; i<5; i=i+1) balance[i]<=balance_next[i][3:0];
            // 上拍新命令需要经历当前 C2；多条相同地址中的成熟项仍可参与 C3。
            command_fresh<=put_match[0];
            // 直接保存观察地址半区的上一拍状态；不以请求当拍的忙状态撤销 req。
            command_idle_prev<=!rd_mem_status[watch_cmd[2:0]][watch_cmd[3]];
            outside<=outside_next[3:0];
            bad_low<=bad_low_next[3:0]; bad_high<=bad_high_next[3:0];
        end
    end

    // 4. cover 的少量进度记录，assert 作业未引用时可由工具移除。
    reg previous_r; // 上一拍发生 R，用于连续响应见证。
    reg previous_issue; // 上一拍发射成功，用于连续发射见证。
    reg previous_watch_failure; // 上一拍任意观察地址发射失败，用于相同地址下一拍重试见证。
    reg [4:0] accepted; // 累计接收数饱和于 16，仅见证超过九条命令的周转。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin previous_r<=0; previous_issue<=0; previous_watch_failure<=0; accepted<=0; end
        else begin
            previous_r<=r_fire; previous_issue<=issue_fire;
            previous_watch_failure<=command_query && !issue_fire;
            if (ar_fire && accepted<5'd16) accepted<=accepted+5'd1;
        end
    end
