// 检查器单独接入；必须同时正确提供任意且固定的 watch_* 参数。
+incdir+.
cmdbuf_rd_compact_sva.sv
