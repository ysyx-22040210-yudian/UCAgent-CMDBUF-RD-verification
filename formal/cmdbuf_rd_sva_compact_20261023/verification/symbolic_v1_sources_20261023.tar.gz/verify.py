#!/usr/bin/env python3
"""核查全输出属性、模型结构、计数抽象以及交付文件签名。

这里的枚举核查用于验证抽象算法，不代替实际 SVA / RTL 的 formal 结果。
"""
import hashlib,itertools,json,re
from pathlib import Path
import run
HERE=Path(__file__).resolve().parent

def check_multiset():
    # 取三个不同值，穷举九项以内的重复次数以及同拍加入/消费。
    # 对所有观察值检查拍初计数，必须恰好等价于在未消费集合中找到该值。
    cases=0
    for counts in itertools.product(range(10),repeat=3):
        if sum(counts)>9:continue
        bag=[v for v,n in enumerate(counts) for _ in range(n)]
        for put,take in itertools.product([None,0,1,2],repeat=2):
            permitted=take is None or take in bag
            watched_checks=all(take!=watch or counts[watch]>0 for watch in range(3))
            assert watched_checks==permitted
            if not permitted:continue
            result=list(bag)
            if take is not None:result.remove(take)
            if put is not None:result.append(put)
            if len(result)>9:continue
            for watch in range(3):
                assert counts[watch]+int(put==watch)-int(take==watch)==result.count(watch)
            cases+=1
    return cases

def check_interval():
    # rresp=11 隐藏 pc_err 时允许消费正常或异常标记；上下界必须覆盖且仅覆盖可行数量。
    cases=0
    for total in range(10):
        for lo in range(total+1):
            for hi in range(lo,total+1):
                for response in (None,0,1,3):
                    if response is not None and not total:continue
                    possible=set()
                    for bad in range(lo,hi+1):
                        if response is None:possible.add(bad)
                        elif response==0 and bad<total:possible.add(bad)
                        elif response==1 and bad>0:possible.add(bad-1)
                        elif response==3:
                            if bad>0:possible.add(bad-1)
                            if bad<total:possible.add(bad)
                    permitted=response is None or response==3 or (response==0 and lo<total) or (response==1 and hi>0)
                    assert bool(possible)==permitted
                    if not possible:continue
                    after=total-int(response is not None)
                    l=lo-1 if response is not None and response!=0 and lo>0 else lo
                    h=hi if response is None else max(hi-1,0) if response==1 else min(hi,after)
                    for incoming in (0,1):
                        expected={x+incoming for x in possible}
                        assert expected==set(range(l+incoming,h+incoming+1))
                        cases+=1
    return cases

def main():
    scope=json.loads((HERE/'scope.json').read_text(encoding='utf-8'))
    props=run.catalog(run.source())
    counts={k:sum(p['instances'] for p in props if p['kind']==k) for k in ('assert','assume','cover')}
    assert counts==scope['counts']
    assert set(scope['outputs'])=={'arready','pending_cnt','req','arb_addr','rvalid','rid','r_port_id','raddr','rresp','rdata'}
    expected={p['label']:p for p in scope['properties']}
    for p in props:assert p['expression']==expected[p['label']]['expression'],p['label']
    assert {p['label'] for p in props if p['kind']=='assume'}=={'E03_SRC','E04_ARRESP','E05_ZERO_READY','E06_SUCCESS_BUSY'}
    # 所有 assert 必须恰好归属一个默认输出组；分组时仍然只是 assert，没有提升为 assume。
    assert all(p['group'] in run.DEFAULT_GROUPS for p in props if p['kind']=='assert')
    assignments=0
    for name in ('cmdbuf_rd_compact_sva.sv','cmdbuf_rd_compact_model.svh','symbolic_values.v'):
        text=(HERE/name).read_text(encoding='utf-8');code=re.sub(r'//[^\n]*','',text)
        assert not re.search(r'\balways_comb\b|always\s*@\s*\(?\s*\*',code),name
        assert not re.search(r'\b(started|active|bit)\b',code),name
        assert not re.search(r'\b(dut|u_cmd|u_otb)\s*\.',code),name
        for i,line in enumerate(text.splitlines()):
            if re.match(r'\s*assign\s+',line):
                assert i and re.match(r'\s*//',text.splitlines()[i-1])
                assert re.search('[\u4e00-\u9fff]',text.splitlines()[i-1])
                assignments+=1
    # 原生参数约束只影响六个额外观察参数，不能约束真实 DUT 输入或强迫某个输出命中。
    native=(HERE/'native_symbolic_top.sv').read_text(encoding='utf-8')
    assert native.count('assume property')==1 and '$stable({watch_cmd,watch_src,watch_id,watch_port,watch_low_addr,watch_data})' in native
    assert not re.search(r'\binitial\b',re.sub(r'//[^\n]*','',native))
    checked=0
    if (HERE/'bundle_manifest.json').exists():
        for name,meta in json.loads((HERE/'bundle_manifest.json').read_text(encoding='utf-8'))['files'].items():
            p=HERE/name
            assert p.is_file() and hashlib.sha256(p.read_bytes()).hexdigest()==meta['sha256'],name
            checked+=1
    print(json.dumps(dict(status='PASS',counts=counts,output_groups=len(scope['outputs']),commented_assign_statements=assignments,
        multiset_transitions=check_multiset(),pc_interval_transitions=check_interval(),source_files_checked=checked),ensure_ascii=False))
if __name__=='__main__':main()
