// 原生 SVA 接入模板：与 formal_top.sv 二选一。目标 FormalMC 2024 仍需实机编译。
`default_nettype none
module cmdbuf_rd_native_formal (
    input wire clk,
    input wire rst_n,
    input wire arvalid,
    output wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    output wire [2:0] rvalid,
    input wire [2:0] rready,
    output wire [127:0] rdata,
    output wire [7:0] rid,
    output wire [4:0] r_port_id,
    output wire [2:0] raddr,
    output wire [1:0] rresp,
    output wire [7:0] req,
    output wire [11:0] arb_addr,
    output wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt,
    // Bank-major unpacked array: status[bank][half], 0=idle, 1=busy.
    input wire [1:0] rd_mem_status [7:0],
    input wire [127:0] mem_rdata,
    input wire pc_err,
    input wire [7:0] rw_rd_gnt,
    input wire [14:0] watch_cmd,
    input wire [1:0] watch_src,
    input wire [7:0] watch_id,
    input wire [4:0] watch_port,
    input wire [2:0] watch_low_addr,
    input wire [127:0] watch_data
);
    cmdbuf_rd dut (.*);
    // 只约束额外检查器参数在本轮非复位运行段保持固定，不限制任何真实 DUT 输入。
    // 第一拍释放复位可选择任意值；之后保持，避免用复位零值意外固定观察参数。
    CFG_WATCH_CONSTANT: assume property (@(posedge clk) disable iff (!rst_n)
        $past(rst_n) |-> $stable({watch_cmd,watch_src,watch_id,watch_port,watch_low_addr,watch_data}));
    cmdbuf_rd_compact_sva checks (.*);
endmodule
`default_nettype wire
