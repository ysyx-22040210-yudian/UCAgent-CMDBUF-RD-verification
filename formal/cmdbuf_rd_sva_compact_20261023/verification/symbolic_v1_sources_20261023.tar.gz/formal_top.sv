// SBY 接入：read_slang 先读空壳，再由 read_verilog -formal 读取
// symbolic_values.v，生成六组真实 $anyconst。不能只给信号加 anyconst 属性。
// 任意参数不赋初值，尤其不能被归零；run.py 会核查生成后的驱动及位宽。
`default_nettype none
// 此空壳只供 SystemVerilog 前端解析接口；run.py 必须用真实实现替换它。
(* blackbox *) module cmdbuf_rd_symbolic_values (
    output wire [14:0] watch_cmd,
    output wire [1:0] watch_src,
    output wire [7:0] watch_id,
    output wire [4:0] watch_port,
    output wire [2:0] watch_low_addr,
    output wire [127:0] watch_data
);
endmodule
module cmdbuf_rd_formal (
    input wire clk,
    input wire rst_n,
    input wire arvalid,
    output wire [2:0] arready,
    input wire [17:0] araddr,
    input wire [1:0] src,
    input wire [7:0] arid,
    input wire [4:0] ar_port_id,
    input wire [1:0] arresp,
    output wire [2:0] rvalid,
    input wire [2:0] rready,
    output wire [127:0] rdata,
    output wire [7:0] rid,
    output wire [4:0] r_port_id,
    output wire [2:0] raddr,
    output wire [1:0] rresp,
    output wire [7:0] req,
    output wire [11:0] arb_addr,
    output wire [3:0] pending_cnt,
    input wire [7:0] ar_rd_gnt,
    // Bank-major unpacked array: status[bank][half], 0=idle, 1=busy.
    input wire [1:0] rd_mem_status [7:0],
    input wire [127:0] mem_rdata,
    input wire pc_err,
    input wire [7:0] rw_rd_gnt
);
    cmdbuf_rd dut (.*);
    // 任意固定的 {araddr[17:6],Bank}，检查 req 与 arb_addr；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [14:0] watch_cmd;
    // 任意固定 XAU 编码，只观察字段来源，不约束 DUT 的 src；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [1:0] watch_src;
    // 任意固定 8 位 ID；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [7:0] watch_id;
    // 任意固定 5 位 port_id；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [4:0] watch_port;
    // 任意固定三位返回低地址；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [2:0] watch_low_addr;
    // 任意固定完整数据值，不作截位或哈希；Yosys 任意常数，所有可能取值都参与反例搜索。
    wire [127:0] watch_data;
    cmdbuf_rd_symbolic_values symbolic_parameters (.*);
    cmdbuf_rd_compact_sva checks (.*);
endmodule
`default_nettype wire
