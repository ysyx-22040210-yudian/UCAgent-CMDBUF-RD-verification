// 顶层 cmdbuf_rd_formal；这是 SystemVerilog 前端文件清单，不是完整 SBY 执行命令。
// 使用 run.py：read_slang 后必须 read_verilog -formal symbolic_values.v 替换参数空壳。
// 只读取本清单会留下参数空壳，不能据此声称完成证明；run.py 会审计实际 $anyconst 驱动。
+define+SYNTHESIS
+incdir+.
rtl/cmdbuf_rd.sv
rtl/cmdbuf_rd_cmd.sv
rtl/cmdbuf_rd_otb.sv
cmdbuf_rd_compact_sva.sv
formal_top.sv
