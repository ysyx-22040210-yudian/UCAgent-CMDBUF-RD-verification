// CMDBUF RD 全输出口精简检查器：每种负载只保留任意值的出现次数，不保存九条事务。
// 阅读顺序：本文件的端口与属性 -> compact_model 中的数量更新 -> 两种顶层的任意参数接入。
// 本模块只观察 DUT 顶层连线。watch_* 是额外的检查器参数，与 DUT 输入完全分开。
// 这些参数必须在一个非复位运行段中任意且固定；formal_top.sv 使用 Yosys anyconst。
// native_symbolic_top.sv 使用自由输入和只针对参数的稳定性 assume，供原生 SVA 工具集成。
// assert 的反例搜索可选择任意 watch 值；证明成功才覆盖该字段的所有取值，不是抽样比较。
// 各字段独立做多重集合计数：仍不证明单 XAU 保序、RR、五项窗口及不同字段的事务配对。
// 无效负载不检查；没有 started/active、输入唯一性、仲裁公平或强迫输出命中的 assume。
// [EXACT] 局部规则精确；[RELAXED] 按已授权的字段独立匹配；[MODEL_SELF_CHECK] 检查模型自洽。
`default_nettype none
module cmdbuf_rd_compact_sva (
    input wire clk, // 采样时钟
    input wire rst_n, // 低有效复位；属性统一 disable iff
    input wire arvalid, // 上游共享请求有效
    input wire [2:0] arready, // DUT 三源接收资格
    input wire [17:0] araddr, // 上游完整地址
    input wire [1:0] src, // 上游来源 0/1/2
    input wire [7:0] arid, // 上游 ID，允许重复
    input wire [4:0] ar_port_id, // 上游 port_id
    input wire [1:0] arresp, // 上游地址状态：00/11
    input wire [2:0] rvalid, // DUT 响应对象，独热或零
    input wire [2:0] rready, // 上游响应接收资格
    input wire [127:0] rdata, // DUT 返回数据，检查任意值输入/输出数量
    input wire [7:0] rid, // DUT 返回 ID，检查同源任意 ID 数量
    input wire [4:0] r_port_id, // DUT 返回 port，检查同源任意 port 数量
    input wire [2:0] raddr, // DUT 返回低地址，检查同源任意低地址数量
    input wire [1:0] rresp, // DUT 返回状态，采用字段数量可行性检查
    input wire [7:0] req, // DUT 下游请求，最多一位为 1
    input wire [11:0] arb_addr, // DUT 下游地址，原地址 [17:6]
    input wire [3:0] pending_cnt, // DUT 本拍待发计数，含本拍接收减本拍成功
    input wire [7:0] ar_rd_gnt, // 下游仲裁 grant
    input wire [7:0] rw_rd_gnt, // 下游仲裁为读的 grant
    input wire [1:0] rd_mem_status [7:0], // 下游 Bank-major 二维状态，0 空闲
    input wire [127:0] mem_rdata, // MEM 合并返回数据，仅成功后第四拍采样
    input wire pc_err, // MEM 返回的奇偶校验标记
    // 任意固定的 {araddr[17:6],Bank}，检查 req 与 arb_addr。
    input wire [14:0] watch_cmd,
    // 任意固定 XAU 编码，只观察字段来源，不约束 DUT 的 src。
    input wire [1:0] watch_src,
    // 任意固定 8 位 ID。
    input wire [7:0] watch_id,
    // 任意固定 5 位 port_id。
    input wire [4:0] watch_port,
    // 任意固定三位返回低地址。
    input wire [2:0] watch_low_addr,
    // 任意固定完整数据值，不作截位或哈希。
    input wire [127:0] watch_data
);

    `include "cmdbuf_rd_compact_model.svh"

    // 1. DUT 环境契约，仍只有四类，展开共 11 个实例。
    // [EXACT] [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 有效 AR 来源必须为 0/1/2。
    E03_SRC: assume property (
        @(posedge clk) disable iff (!rst_n)
        arvalid |-> src<2'd3
    );

    // [EXACT] [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 有效 AR 的地址状态仅允许正常和越界。
    E04_ARRESP: assume property (
        @(posedge clk) disable iff (!rst_n)
        arvalid |-> (arresp==2'b00 || arresp==2'b11)
    );

    // [EXACT] [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 全源 ready 为零时无有效 AR。
    E05_ZERO_READY: assume property (
        @(posedge clk) disable iff (!rst_n)
        arready==0 |-> !arvalid
    );

    genvar b; // 八个 Bank 的成功当拍忙状态契约。
    generate for (b=0;b<8;b=b+1) begin : status_contract
        // [EXACT] [NO_REF_MODEL_ENV] [NO_REF_MODEL_PORTS] 成功当拍目标 Bank/half 为忙，不要求另一半区忙。
        E06_SUCCESS_BUSY: assume property (
            @(posedge clk) disable iff (!rst_n)
            (req[b] && ar_rd_gnt[b] && rw_rd_gnt[b]) |-> rd_mem_status[b][arb_addr[0]]
        );

    end endgenerate

    // 2. 不依赖事务参考模型的端口规则。
    // [EXACT] [NO_REF_MODEL_PORTS] req 独热或零，一个共享地址只能请求一个 Bank。
    A_S_REQ_ONEHOT: assert property (
        @(posedge clk) disable iff (!rst_n)
        (req & (req-8'd1))==0
    );

    // [EXACT] [NO_REF_MODEL_PORTS] rvalid 独热或零，单拍共享 R 最多返回给一个来源。
    A_S_R_ONEHOT: assert property (
        @(posedge clk) disable iff (!rst_n)
        (rvalid & (rvalid-3'd1))==0
    );

    // [EXACT] [NO_REF_MODEL_PORTS] 只在对应 rready 为 1 时拉高 rvalid。
    A_S_R_READY: assert property (
        @(posedge clk) disable iff (!rst_n)
        (rvalid & ~rready)==0
    );

    // [EXACT] [NO_REF_MODEL_PORTS] 有效 rresp 只允许 00/01/11。
    A_S_RRESP_CODE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (|rvalid) |-> (rresp==0 || rresp==1 || rresp==3)
    );

    // 3. arready / pending_cnt / rvalid 的数量义务，逐输出组可独立证明。
    // [EXACT] [NO_REF_MODEL_HISTORY] arready 精确包含当前 R 回收及各源首项保留。
    A_S_READY: assert property (
        @(posedge clk) disable iff (!rst_n)
        arready==expected_ready
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] 总占用不得超过九项。
    A_S_TOTAL: assert property (
        @(posedge clk) disable iff (!rst_n)
        total<=6'd9
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] 空来源至少保留一项，其他来源不可侵占。
    A_S_RESERVATION: assert property (
        @(posedge clk) disable iff (!rst_n)
        reserved_total<=6'd9
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] pending_cnt 等于本拍 AR 加入、成功发射扣除后的数量。
    A_S_PENDING: assert property (
        @(posedge clk) disable iff (!rst_n)
        {1'b0,pending_cnt}==pending_now
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] 待发计数不能上溢或下溢。
    A_S_PENDING_RANGE: assert property (
        @(posedge clk) disable iff (!rst_n)
        pending_now<=5'd9
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] 成功发射不能凭空消费当前尚未存在的命令。
    A_S_ISSUE_NONEMPTY: assert property (
        @(posedge clk) disable iff (!rst_n)
        issue_fire |-> waiting!=0
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] 有效 R 必须有此前捕获的 MEM 返回，当前到期不能同拍旁路。
    A_S_R_CAPTURED: assert property (
        @(posedge clk) disable iff (!rst_n)
        (|rvalid) |-> completed!=0
    );

    // [EXACT] [NO_REF_MODEL_HISTORY] MEM/R 总量保持守恒且不越界。
    A_S_COMPLETED_RANGE: assert property (
        @(posedge clk) disable iff (!rst_n)
        completed_next<=5'd9
    );

    genvar x; // 三个来源占用独立展开，不重建接收 FIFO。
    generate for (x=0;x<3;x=x+1) begin : sources
        // [EXACT] [NO_REF_MODEL_HISTORY] 每源本拍更新后的占用不超过七，扩位检查不允许截断掩盖错误。
        A_S_SOURCE_LIMIT: assert property (
            @(posedge clk) disable iff (!rst_n)
            occupied_next[x]<=5'd7
        );

        // [EXACT] [NO_REF_MODEL_HISTORY] 当前有效 R 只能返回给有未完成命令的来源。
        A_S_SOURCE_NONEMPTY: assert property (
            @(posedge clk) disable iff (!rst_n)
            rvalid[x] |-> occupied[x]!=0
        );

    end endgenerate

    // 4. req/arb_addr 联合来源检查：任意地址计数 + 一拍新命令标记 + 上拍空闲状态。
    // [RELAXED] [REF_MODEL] 当前请求的完整下游地址及 Bank 必须有成熟待发记录；相同地址可重复。
    A_S_COMMAND_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        command_query |-> balance[0]>{3'b0,command_fresh}
    );

    // [RELAXED] [NO_REF_MODEL_HISTORY] 访问半区上一拍为空闲；请求当拍可以为忙。不检查最老五项资格。
    A_S_COMMAND_PREVIOUS_IDLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        command_query |-> command_idle_prev
    );

    // 5. 四种 R 负载分别检查，完整字段相等，但不要求字段之间属于同一条命令。
    // [RELAXED] [REF_MODEL] 同源 rid 必须有尚未消费的相同 AR ID。
    A_S_RID_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        id_query |-> balance[1]!=0
    );

    // [RELAXED] [REF_MODEL] 同源 port_id 必须有尚未消费的相同 AR port_id。
    A_S_RPORT_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        port_query |-> balance[2]!=0
    );

    // [RELAXED] [REF_MODEL] 同源 raddr 必须有尚未消费的相同 AR 低地址。
    A_S_RADDR_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        low_addr_query |-> balance[3]!=0
    );

    // [RELAXED] [REF_MODEL] rdata 的完整 128 位值必须有此前捕获且未消费的 MEM 数据。
    A_S_RDATA_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        data_query |-> balance[4]!=0
    );

    // 6. rresp 检查合法来源与 pc 标记可行性；不保存逐命令错误表。
    // [RELAXED] [REF_MODEL] 11 至少能消费该源一份地址越界标记。
    A_S_ADDRESS_ERROR_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (watched_rvalid && rresp==3) |-> outside!=0
    );

    // [RELAXED] [REF_MODEL] 00/01 至少能消费该源一份正常地址标记。
    A_S_NORMAL_ADDRESS_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        (watched_rvalid && rresp!=3) |-> watched_occupied>outside
    );

    // [RELAXED] [REF_MODEL] 00 仍有可能消费一个 pc_err=0 的 MEM 返回。
    A_S_PC_CLEAN_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        ((|rvalid) && rresp==0) |-> bad_low<completed
    );

    // [RELAXED] [REF_MODEL] 01 仍有可能消费一个 pc_err=1 的 MEM 返回。
    A_S_PC_BAD_AVAILABLE: assert property (
        @(posedge clk) disable iff (!rst_n)
        ((|rvalid) && rresp==1) |-> bad_high!=0
    );

    // 7. 计数扩位与自洽检查。它们保持 assert，不作为 DUT 输出约束或证明前提。
    // [EXACT] [MODEL_SELF_CHECK] 任意值的下一拍数量不能下溢或超过九，禁止计数回绕导致假通过。
    M_S_REQUEST_NEXT: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance_next[0]<=5'd9
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意值的下一拍数量不能下溢或超过九，禁止计数回绕导致假通过。
    M_S_ID_NEXT: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance_next[1]<=5'd9
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意值的下一拍数量不能下溢或超过九，禁止计数回绕导致假通过。
    M_S_PORT_NEXT: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance_next[2]<=5'd9
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意值的下一拍数量不能下溢或超过九，禁止计数回绕导致假通过。
    M_S_ADDRESS_NEXT: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance_next[3]<=5'd9
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意值的下一拍数量不能下溢或超过九，禁止计数回绕导致假通过。
    M_S_DATA_NEXT: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance_next[4]<=5'd9
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意地址的待发次数不大于全体待发数。
    M_S_COMMAND_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance[0]<=waiting
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意 ID 出现次数不大于该源占用。
    M_S_ID_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance[1]<=watched_occupied
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意 port 出现次数不大于该源占用。
    M_S_PORT_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance[2]<=watched_occupied
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意低地址出现次数不大于该源占用。
    M_S_ADDR_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance[3]<=watched_occupied
    );

    // [EXACT] [MODEL_SELF_CHECK] 任意数据出现次数不大于全体已捕获数量。
    M_S_DATA_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        balance[4]<=completed
    );

    // [EXACT] [MODEL_SELF_CHECK] 地址越界标记次数不大于该源占用且不会回绕。
    M_S_OUTSIDE_BALANCE: assert property (
        @(posedge clk) disable iff (!rst_n)
        outside<=watched_occupied && outside_next<=9
    );

    // [EXACT] [MODEL_SELF_CHECK] pc=1 数量区间保持非空且不超过完成总量。
    M_S_PC_INTERVAL: assert property (
        @(posedge clk) disable iff (!rst_n)
        bad_low_next<=bad_high_next && bad_high_next<=completed_next
    );

    // 8. cover 同时命中任意参数相关前件，避免只观察无关输入而把蕴含空真当覆盖。
    // [RELAXED] [REF_MODEL] 任意来源参数确实观察到 AR。
    C_S_SOURCE_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        ar_fire && src==watch_src
    );

    // [RELAXED] [REF_MODEL] 任意下游地址确实成功发射。
    C_S_COMMAND_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        issue_fire && command_query
    );

    // [RELAXED] [REF_MODEL] 任意 ID 确实在 R 消费。
    C_S_ID_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        watched_rfire && rid==watch_id
    );

    // [RELAXED] [REF_MODEL] 任意 port 确实在 R 消费。
    C_S_PORT_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        watched_rfire && r_port_id==watch_port
    );

    // [RELAXED] [REF_MODEL] 任意低地址确实在 R 消费。
    C_S_ADDRESS_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        watched_rfire && raddr==watch_low_addr
    );

    // [RELAXED] [REF_MODEL] 任意完整数据值确实在 R 消费。
    C_S_DATA_MATCH: cover property (
        @(posedge clk) disable iff (!rst_n)
        r_fire && data_query
    );

    // [RELAXED] [REF_MODEL] 任意数据最高位可为一，防止参数被初始化成全零。
    C_S_DATA_HIGH_BIT: cover property (
        @(posedge clk) disable iff (!rst_n)
        r_fire && data_query && watch_data[127]
    );

    // [RELAXED] [REF_MODEL] 相同数据的两次出现被分别计数。
    C_S_DUPLICATE_DATA: cover property (
        @(posedge clk) disable iff (!rst_n)
        r_fire && data_query && balance[4]>=2
    );

    // [RELAXED] [REF_MODEL] 奇偶校验错误响应。
    C_S_PC_ERROR: cover property (
        @(posedge clk) disable iff (!rst_n)
        r_fire && rresp==1
    );

    // [RELAXED] [REF_MODEL] 同源地址越界响应。
    C_S_ADDRESS_ERROR: cover property (
        @(posedge clk) disable iff (!rst_n)
        watched_rfire && rresp==3
    );

    // [RELAXED] [REF_MODEL] 九项全满同进同出。
    C_S_FULL_REUSE: cover property (
        @(posedge clk) disable iff (!rst_n)
        total==9 && ar_fire && r_fire
    );

    // [RELAXED] [REF_MODEL] AR、发射成功、MEM、R 四事件同拍。
    C_S_FOUR_EVENTS: cover property (
        @(posedge clk) disable iff (!rst_n)
        ar_fire && issue_fire && mem_due && r_fire
    );

    // [RELAXED] [REF_MODEL] 失败后紧邻重试相同任意地址。
    C_S_RETRY: cover property (
        @(posedge clk) disable iff (!rst_n)
        previous_watch_failure && command_query
    );

    // [RELAXED] [REF_MODEL] 连续成功发射。
    C_S_ISSUE_STREAK: cover property (
        @(posedge clk) disable iff (!rst_n)
        previous_issue && issue_fire
    );

    // [RELAXED] [REF_MODEL] 连续响应。
    C_S_RESPONSE_STREAK: cover property (
        @(posedge clk) disable iff (!rst_n)
        previous_r && r_fire
    );

    // [RELAXED] [REF_MODEL] 超过九条命令后仍有生命周期周转。
    C_S_TURNOVER: cover property (
        @(posedge clk) disable iff (!rst_n)
        accepted>=10 && r_fire
    );

endmodule
`default_nettype wire
