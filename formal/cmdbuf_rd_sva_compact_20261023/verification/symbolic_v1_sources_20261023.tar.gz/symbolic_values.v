// 仅供 Yosys 原生 read_verilog -formal 读取，不能改用 read_slang。
// 六个参数由求解器选择任意取值，整个证明轨迹保持不变。
// 这里没有初始赋值，也没有限制任何 DUT 输入；FormalMC 使用 native_symbolic_top.sv。
`default_nettype none
module cmdbuf_rd_symbolic_values (
    output wire [14:0] watch_cmd,      // 联合命令键：完整下游地址及 Bank。
    output wire [1:0] watch_src,       // 观察哪个 XAU；3 编码不匹配任何通道。
    output wire [7:0] watch_id,        // 任意完整 ID。
    output wire [4:0] watch_port,      // 任意完整 port_id。
    output wire [2:0] watch_low_addr,  // 任意完整低地址。
    output wire [127:0] watch_data    // 任意完整数据值，保留全部 128 位。
);
    (* anyconst *) reg [14:0] arbitrary_cmd; // 下游地址与 Bank 的任意联合值。
    (* anyconst *) reg [1:0] arbitrary_src; // 任意来源参数，无复位赋值。
    (* anyconst *) reg [7:0] arbitrary_id; // 任意完整 ID 参数。
    (* anyconst *) reg [4:0] arbitrary_port; // 任意完整 port 参数。
    (* anyconst *) reg [2:0] arbitrary_low_addr; // 任意三位低地址参数。
    (* anyconst *) reg [127:0] arbitrary_data; // 任意完整 128 位数据参数。
    // 将实际任意常数驱动到检查器；六路均保持原位宽。
    assign watch_cmd = arbitrary_cmd;
    // 来源只选择检查器观察对象，不改变 DUT 的 src。
    assign watch_src = arbitrary_src;
    // ID 全位传递，不作截位。
    assign watch_id = arbitrary_id;
    // port 全位传递，不作截位。
    assign watch_port = arbitrary_port;
    // 低地址三位全部传递。
    assign watch_low_addr = arbitrary_low_addr;
    // 完整数据值全部传递，不作哈希。
    assign watch_data = arbitrary_data;
endmodule
`default_nettype wire
