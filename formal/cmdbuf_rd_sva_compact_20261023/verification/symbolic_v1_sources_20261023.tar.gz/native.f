// 顶层 cmdbuf_rd_native_formal；自由参数 + 稳定性约束，不与 sby.f 同时编译。
+define+SYNTHESIS
+incdir+.
rtl/cmdbuf_rd.sv
rtl/cmdbuf_rd_cmd.sv
rtl/cmdbuf_rd_otb.sv
cmdbuf_rd_compact_sva.sv
native_symbolic_top.sv
