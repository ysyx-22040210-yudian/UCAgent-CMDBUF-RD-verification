#!/usr/bin/env python3
"""Independent output-group proofs for the compact symbolic-count checker.

Keep all established environment assumptions. Unselected assertions and covers
are removed only in execution copies; no assertion is promoted into an assume.
Default: one job for each output group so unused DUT/model logic can be removed.
Use --group all only for a combined cross-check; combining groups can be slower.
"""
import argparse,concurrent.futures,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
from property_catalog import properties,lower_overlapping_implications
HERE=Path(__file__).resolve().parent
WATCH_WIDTHS={'watch_cmd':15,'watch_src':2,'watch_id':8,'watch_port':5,'watch_low_addr':3,'watch_data':128}
REQUIRED_WATCH={
    'ports':[], 'admission':[], 'pending':[], 'response':[],
    'request':['watch_cmd'], 'id':['watch_src','watch_id'],
    'port':['watch_src','watch_port'], 'address':['watch_src','watch_low_addr'],
    'status':['watch_src'], 'data':['watch_data'],
    'all':list(WATCH_WIDTHS), 'cover':list(WATCH_WIDTHS),
}
DEFAULT_GROUPS=['ports','admission','pending','request','response','id','port','address','status','data','cover']

def audit_symbolic(path,required):
    """拒绝把未驱动/X/常数化的观察值当作合法的符号参数证明。"""
    if not path.exists():return dict(ok=False,error='Missing elaborated netlist: '+str(path))
    modules=json.loads(path.read_text())['modules'];found={};cells=[]
    for module,info in modules.items():
        drivers=[]
        for name,cell in info.get('cells',{}).items():
            if cell['type']=='$anyconst':
                width=int(cell['parameters']['WIDTH'],2)
                drivers.append(cell['connections']['Y'])
                cells.append(dict(module=module,cell=name,width=width))
        for name in required:
            net=info.get('netnames',{}).get(name)
            if net and len(net['bits'])==WATCH_WIDTHS[name] and all(isinstance(b,int) for b in net['bits']) and net['bits'] in drivers and 'init' not in net.get('attributes',{}):
                found[name]=dict(module=module,width=len(net['bits']),uninitialized_anyconst=True)
    return dict(ok=all(n in found for n in required),required=required,found=found,anyconst_cells=cells)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def source():
    return (HERE/'cmdbuf_rd_compact_sva.sv').read_text(encoding='utf-8').replace('`include "cmdbuf_rd_compact_model.svh"',(HERE/'cmdbuf_rd_compact_model.svh').read_text(encoding='utf-8'))
def catalog(text):
    scope={p['label']:p for p in json.loads((HERE/'scope.json').read_text(encoding='utf-8'))['properties']}
    result=properties(text)
    for p in result:p.update(instances=scope[p['label']]['instances'],group=scope[p['label']]['group'])
    return result
def selected(text,group,mode):
    for p in reversed(catalog(text)):
        keep=p['kind']=='assume' or (p['kind']=='assert' and (group in ('all','cover') or p['group']==group)) or (p['kind']=='cover' and mode=='cover')
        if not keep:text=text[:p['start']]+'\n'.join('// Unselected: '+x for x in text[p['start']:p['end']].split('\n'))+text[p['end']:]
    return text
def job(cfg,out):
    dest=out/cfg['group'];dest.mkdir(parents=True,exist_ok=False)
    native=source();sel=selected(native,cfg['group'],cfg['mode']);exe,lowering=lower_overlapping_implications(sel)
    (dest/'native_checker.sv').write_text(native,encoding='utf-8');(dest/'cmdbuf_rd_compact_sva.sv').write_text(exe,encoding='utf-8')
    files=['cmdbuf_rd.sv','cmdbuf_rd_cmd.sv','cmdbuf_rd_otb.sv','cmdbuf_rd_compact_sva.sv','formal_top.sv']
    hashes={}
    for name in files:
        if name=='cmdbuf_rd_compact_sva.sv':continue
        path=HERE/'rtl'/name if name.startswith('cmdbuf_rd') else HERE/name
        shutil.copyfile(path,dest/name);hashes[str(path.relative_to(HERE))]=sha(path)
    shutil.copyfile(HERE/'symbolic_values.v',dest/'symbolic_values.v')
    for name in ('cmdbuf_rd_compact_sva.sv','cmdbuf_rd_compact_model.svh','scope.json','run.py','property_catalog.py','symbolic_values.v'):hashes[name]=sha(HERE/name)
    hashes.update(executed_sha256=sha(dest/'cmdbuf_rd_compact_sva.sv'),native_sha256=sha(dest/'native_checker.sv'),
        initialization='Real reset simulation once, rst_n unconstrained afterwards; watch_* remain anyconst, never assigned 0 or given init attributes.')
    (dest/'inputs.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
    (dest/'lowering.json').write_text(json.dumps(lowering,indent=2)+'\n',encoding='utf-8')
    props=catalog(sel);(dest/'selected_properties.json').write_text(json.dumps(props,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    sby='[options]\nmode {mode}\ndepth {depth}\ntimeout {timeout}\n\n[engines]\n{engine}\n\n'.format(**cfg)
    sby+='[script]\nread_slang --top cmdbuf_rd_formal --no-implicit-memories -D SYNTHESIS '+' '.join(files)+'\n'
    sby+='read_verilog -formal symbolic_values.v\nwrite_json symbolic_elaborated.json\n'
    sby+='prep -top cmdbuf_rd_formal -flatten\nasync2sync\ndffunmap\nchformal -lower\n'
    sby+='sim -clock clk -resetn rst_n -rstlen 1 -n 1 -w -vcd reset_initialization.vcd\n'
    sby+='stat -width\nwrite_json initialized.json\n\n[files]\n'+'\n'.join(files+['symbolic_values.v'])+'\n'
    (dest/'run.sby').write_text(sby,encoding='utf-8')
    start=time.time()
    with (dest/'console.log').open('w') as f:p=subprocess.run(['sby','run.sby'],cwd=str(dest),stdout=f,stderr=subprocess.STDOUT)
    st=dest/'run/status';status=st.read_text().strip() if st.exists() else 'NO_STATUS'
    # 前端展开后检查全部参数；优化和建立初态后检查该输出组实际依赖的参数。
    before=audit_symbolic(dest/'run/src/symbolic_elaborated.json',list(WATCH_WIDTHS))
    after=audit_symbolic(dest/'run/src/initialized.json',REQUIRED_WATCH[cfg['group']])
    audit=dict(ok=before['ok'] and after['ok'],elaborated=before,initialized=after)
    (dest/'symbolic_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
    engine_status=status
    if not audit['ok']:status='INVALID_SYMBOLIC_PARAMETERS'
    result=dict(cfg,status=status,returncode=p.returncode,seconds=round(time.time()-start,2),
        counts={k:sum(x['instances'] for x in props if x['kind']==k) for k in ('assert','assume','cover')},engine_status=engine_status,symbolic_audit_ok=audit['ok'],anyconst_cells=after.get('anyconst_cells',[]))
    (dest/'result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result),flush=True)
    return result
def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--tools',type=Path)
    ap.add_argument('--group',action='append',choices=['ports','admission','pending','request','response','id','port','address','status','data','all','cover'])
    ap.add_argument('--depth',type=int,default=10);ap.add_argument('--cover-depth',type=int,default=32);ap.add_argument('--timeout',type=int,default=180);ap.add_argument('--jobs',type=int,default=3)
    ap.add_argument('--prove-groups',action='store_true',help='Use PDR for selected non-cover groups; default is BMC except ports')
    ap.add_argument('--engine',choices=['smtbmc yices','abc bmc3'],default='smtbmc yices');a=ap.parse_args()
    if a.tools:os.environ['PATH']=str(a.tools)+os.pathsep+os.environ.get('PATH','')
    assert {x['label'] for x in catalog(source()) if x['kind']=='assume'}=={'E03_SRC','E04_ARRESP','E05_ZERO_READY','E06_SUCCESS_BUSY'}
    a.output.mkdir(parents=True,exist_ok=False);jobs=[]
    for g in a.group or DEFAULT_GROUPS:
        mode='cover' if g=='cover' else 'prove' if g=='ports' or a.prove_groups else 'bmc'
        jobs.append(dict(group=g,mode=mode,depth=a.cover_depth if mode=='cover' else a.depth,timeout=a.timeout,engine='abc pdr' if mode=='prove' else 'smtbmc yices' if mode=='cover' else a.engine))
    with concurrent.futures.ThreadPoolExecutor(max_workers=a.jobs) as pool:results=list(pool.map(lambda c:job(c,a.output),jobs))
    (a.output/'results.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    return int(any(not x['status'].startswith('PASS') for x in results))
if __name__=='__main__':raise SystemExit(main())
