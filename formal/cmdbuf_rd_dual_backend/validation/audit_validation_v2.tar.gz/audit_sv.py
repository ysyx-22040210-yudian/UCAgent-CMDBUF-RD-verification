"""Independently lint exported SystemVerilog without running a formal solver."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/root/cmdbuf_rd/portable_20261012')
PACKAGE = ROOT / 'package'
OUT = ROOT / 'audit_compile'
OUT.mkdir(exist_ok=True)
manifest = json.loads((PACKAGE / 'manifest.json').read_text())
results = []
for job in manifest['jobs']:
    source = PACKAGE / job['formalmc']['sources'][0]
    raw = source.read_bytes()
    text = raw.decode('utf-8')
    top = re.search(r'(?m)^module\s+(\w+)\s*\(', text).group(1)
    argv = ['/opt/verilator-5.024/bin/verilator', '--lint-only', '--assert',
            '--top-module', top, '-Wno-fatal', str(source)]
    logfile = OUT / (job['id'] + '.log')
    with logfile.open('wb') as handle:
        try:
            process = subprocess.run(argv, stdout=handle, stderr=subprocess.STDOUT, timeout=60)
            code = process.returncode
        except subprocess.TimeoutExpired:
            code = 'timeout'
    log = logfile.read_text(errors='replace')
    row = {'job': job['id'], 'source': str(source.relative_to(PACKAGE)),
           'source_sha256': hashlib.sha256(raw).hexdigest(),
           'unchanged_after_lint': raw == source.read_bytes(), 'exit_code': code,
           'warnings': dict(collections.Counter(re.findall(r'%Warning-([A-Z0-9_]+)', log))),
           'errors': re.findall(r'%Error[^\n]*', log), 'argv': argv,
           'log_sha256': hashlib.sha256(logfile.read_bytes()).hexdigest()}
    results.append(row)
    print(json.dumps({'job': job['id'], 'exit_code': code, 'warnings': row['warnings']}), flush=True)
summary = {'scope': 'Independent Verilator syntax/elaboration check only; not FormalMC or SBY proof.',
           'jobs': results, 'all_parsed': all(r['exit_code'] == 0 and r['unchanged_after_lint'] for r in results)}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'jobs': len(results), 'all_parsed': summary['all_parsed']}))
