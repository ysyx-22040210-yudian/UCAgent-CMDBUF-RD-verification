`ifndef VERILATOR
module testbench;
  reg [4095:0] vcdfile;
  reg clock;
`else
module testbench(input clock, output reg genclock);
  initial genclock = 1;
`endif
  reg genclock = 1;
  reg [31:0] cycle = 0;
  reg [3:0] PI_portable_symbol_0008;
  wire [0:0] PI_clk = clock;
  reg [17:0] PI_araddr;
  reg [7:0] PI_ar_rd_gnt;
  reg [1:0] PI_portable_symbol_0002;
  reg [7:0] PI_portable_symbol_0006;
  reg [7:0] PI_rw_rd_gnt;
  reg [2:0] PI_portable_symbol_0004;
  reg [15:0] PI_rd_mem_status;
  reg [1:0] PI_src;
  reg [0:0] PI_rst_n;
  reg [1:0] PI_arresp;
  reg [0:0] PI_pc_err;
  reg [2:0] PI_rready;
  reg [127:0] PI_mem_rdata;
  reg [4:0] PI_portable_symbol_0005;
  reg [127:0] PI_portable_symbol_0000;
  reg [1:0] PI_portable_symbol_0003;
  reg [4:0] PI_ar_port_id;
  reg [0:0] PI_arvalid;
  reg [7:0] PI_arid;
  reg [3:0] PI_portable_symbol_0007;
  reg [17:0] PI_portable_symbol_0001;
  cmdbuf_rd_wrapper UUT (
    .portable_symbol_0008(PI_portable_symbol_0008),
    .clk(PI_clk),
    .araddr(PI_araddr),
    .ar_rd_gnt(PI_ar_rd_gnt),
    .portable_symbol_0002(PI_portable_symbol_0002),
    .portable_symbol_0006(PI_portable_symbol_0006),
    .rw_rd_gnt(PI_rw_rd_gnt),
    .portable_symbol_0004(PI_portable_symbol_0004),
    .rd_mem_status(PI_rd_mem_status),
    .src(PI_src),
    .rst_n(PI_rst_n),
    .arresp(PI_arresp),
    .pc_err(PI_pc_err),
    .rready(PI_rready),
    .mem_rdata(PI_mem_rdata),
    .portable_symbol_0005(PI_portable_symbol_0005),
    .portable_symbol_0000(PI_portable_symbol_0000),
    .portable_symbol_0003(PI_portable_symbol_0003),
    .ar_port_id(PI_ar_port_id),
    .arvalid(PI_arvalid),
    .arid(PI_arid),
    .portable_symbol_0007(PI_portable_symbol_0007),
    .portable_symbol_0001(PI_portable_symbol_0001)
  );
`ifndef VERILATOR
  initial begin
    if ($value$plusargs("vcd=%s", vcdfile)) begin
      $dumpfile(vcdfile);
      $dumpvars(0, testbench);
    end
    #5 clock = 0;
    while (genclock) begin
      #5 clock = 0;
      #5 clock = 1;
    end
  end
`endif
  initial begin
`ifndef VERILATOR
    #1;
`endif
    UUT._0006_ = 1'b0;
    UUT._0067_ = 1'b1;
    UUT._0069_ = 1'b1;
    UUT._0070_ = 1'b1;
    UUT._0071_ = 1'b1;
    UUT._0072_ = 1'b1;
    UUT._0073_ = 1'b1;
    UUT._0074_ = 1'b1;
    UUT._0075_ = 1'b1;
    UUT._0076_ = 1'b1;
    UUT._0077_ = 1'b1;
    UUT._0078_ = 1'b1;
    UUT._0079_ = 1'b1;
    UUT._0089_ = 4'b0000;
    UUT._0091_ = 4'b0000;
    UUT._0092_ = 4'b0000;
    UUT._0093_ = 4'b0000;
    UUT._0094_ = 4'b0000;
    UUT._0104_ = 9'b000000000;
    UUT._0105_ = 9'b000000000;
    UUT._0106_ = 9'b000000000;
    UUT._0108_ = 2'b00;
    UUT._0109_ = 1'b0;
    UUT._0110_ = 4'b0000;
    UUT._0111_ = 3'b000;
    UUT._0113_ = 4'b0000;
    UUT._0114_ = 4'b0000;
    UUT._0115_ = 4'b0000;
    UUT._0116_ = 18'b000000000000000000;
    UUT._0117_ = 18'b000000000000000000;
    UUT._0118_ = 18'b000000000000000000;
    UUT._0119_ = 18'b000000000000000000;
    UUT._0120_ = 18'b000000000000000000;
    UUT._0121_ = 18'b000000000000000000;
    UUT._0122_ = 18'b000000000000000000;
    UUT._0123_ = 18'b000000000000000000;
    UUT._0124_ = 18'b000000000000000000;
    UUT._0125_ = 2'b00;
    UUT._0126_ = 2'b00;
    UUT._0127_ = 2'b00;
    UUT._0128_ = 2'b00;
    UUT._0129_ = 2'b00;
    UUT._0130_ = 2'b00;
    UUT._0131_ = 2'b00;
    UUT._0132_ = 2'b00;
    UUT._0133_ = 2'b00;
    UUT._0161_ = 9'b000000000;
    UUT._0162_ = 9'b000000000;
    UUT._0163_ = 9'b000000000;
    UUT._0164_ = 9'b000000000;
    UUT._0165_ = 9'b000000000;
    UUT._0166_ = 9'b000000000;
    UUT._0167_ = 9'b000000000;
    UUT._0168_ = 9'b000000000;
    UUT._0169_ = 9'b000000000;
    UUT._0309_ = 1'b0;
    UUT.uc_reset_count = 1'b0;

    // state 0
    PI_portable_symbol_0008 = 4'b0000;
    PI_araddr = 18'b000000000000000000;
    PI_ar_rd_gnt = 8'b00000000;
    PI_portable_symbol_0002 = 2'b00;
    PI_portable_symbol_0006 = 8'b00000000;
    PI_rw_rd_gnt = 8'b00000000;
    PI_portable_symbol_0004 = 3'b000;
    PI_rd_mem_status = 16'b0000000000000000;
    PI_src = 2'b00;
    PI_rst_n = 1'b0;
    PI_arresp = 2'b00;
    PI_pc_err = 1'b0;
    PI_rready = 3'b000;
    PI_mem_rdata = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_portable_symbol_0005 = 5'b00000;
    PI_portable_symbol_0000 = 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
    PI_portable_symbol_0003 = 2'b00;
    PI_ar_port_id = 5'b00000;
    PI_arvalid = 1'b0;
    PI_arid = 8'b00000000;
    PI_portable_symbol_0007 = 4'b0000;
    PI_portable_symbol_0001 = 18'b000000000000000000;
  end
  always @(posedge clock) begin
    // state 1
    if (cycle == 0) begin
      PI_portable_symbol_0008 <= 4'b0000;
      PI_araddr <= 18'b000000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0002 <= 2'b00;
      PI_portable_symbol_0006 <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0004 <= 3'b000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_src <= 2'b01;
      PI_rst_n <= 1'b1;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_rready <= 3'b000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0005 <= 5'b00000;
      PI_portable_symbol_0000 <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0003 <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_arvalid <= 1'b1;
      PI_arid <= 8'b00000000;
      PI_portable_symbol_0007 <= 4'b0000;
      PI_portable_symbol_0001 <= 18'b000000000000000000;
    end

    // state 2
    if (cycle == 1) begin
      PI_portable_symbol_0008 <= 4'b0000;
      PI_araddr <= 18'b000000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0002 <= 2'b00;
      PI_portable_symbol_0006 <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0004 <= 3'b000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_src <= 2'b00;
      PI_rst_n <= 1'b1;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_rready <= 3'b000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0005 <= 5'b00000;
      PI_portable_symbol_0000 <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0003 <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_portable_symbol_0007 <= 4'b0000;
      PI_portable_symbol_0001 <= 18'b000000000000000000;
    end

    // state 3
    if (cycle == 2) begin
      PI_portable_symbol_0008 <= 4'b0000;
      PI_araddr <= 18'b000000000000000000;
      PI_ar_rd_gnt <= 8'b00000001;
      PI_portable_symbol_0002 <= 2'b00;
      PI_portable_symbol_0006 <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0004 <= 3'b000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_src <= 2'b00;
      PI_rst_n <= 1'b1;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_rready <= 3'b000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0005 <= 5'b00000;
      PI_portable_symbol_0000 <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0003 <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_portable_symbol_0007 <= 4'b0000;
      PI_portable_symbol_0001 <= 18'b000000000000000000;
    end

    // state 4
    if (cycle == 3) begin
      PI_portable_symbol_0008 <= 4'b0000;
      PI_araddr <= 18'b000000000000000000;
      PI_ar_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0002 <= 2'b00;
      PI_portable_symbol_0006 <= 8'b00000000;
      PI_rw_rd_gnt <= 8'b00000000;
      PI_portable_symbol_0004 <= 3'b000;
      PI_rd_mem_status <= 16'b0000000000000000;
      PI_src <= 2'b00;
      PI_rst_n <= 1'b1;
      PI_arresp <= 2'b00;
      PI_pc_err <= 1'b0;
      PI_rready <= 3'b000;
      PI_mem_rdata <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0005 <= 5'b00000;
      PI_portable_symbol_0000 <= 128'b00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
      PI_portable_symbol_0003 <= 2'b00;
      PI_ar_port_id <= 5'b00000;
      PI_arvalid <= 1'b0;
      PI_arid <= 8'b00000000;
      PI_portable_symbol_0007 <= 4'b0000;
      PI_portable_symbol_0001 <= 18'b000000000000000000;
    end

    genclock <= cycle < 4;
    cycle <= cycle + 1;
  end
endmodule
