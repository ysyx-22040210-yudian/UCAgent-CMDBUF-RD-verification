#!/usr/bin/env python3
"""Read-only reconciliation of fresh normalized-model runs, including parser fixes.

Historical receipts are never rewritten. Only a new derived summary is created.
"""
import hashlib,json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path('/root/cmdbuf_rd/portable_20261012');PKG=ROOT/'package'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((PKG/'manifest.json').read_text());byid={j['id']:j for j in manifest['jobs']};observations=[];selected={}
    cancellation_path=ROOT/'normalized_validation/cancellation_z3.json'
    cancellations=[json.loads(cancellation_path.read_text())] if cancellation_path.is_file() else []
    for receipt_path in sorted((ROOT/'normalized_validation').glob('*/results.json')):
        receipt=json.loads(receipt_path.read_text())
        for original_row in receipt['runs']:
            jid=original_row['job_id'];job=byid[jid];runroot=receipt_path.parent/jid
            model=runroot/'inputs/model.sv';current=PKG/'jobs'/jid/'formalmc/model.sv'
            if not model.is_file():continue
            matched=sha(model)==sha(current)
            statusfile=runroot/'work/status';raw=statusfile.read_text().strip() if statusfile.is_file() else 'missing';status=raw.split()[0]
            xml=runroot/'work/validate.xml';found=[]
            if xml.is_file():
                for tc in ET.parse(xml).findall('.//testcase'):
                    kind=tc.get('type','').lower()
                    if kind not in ('assert','cover'):continue
                    found.append({'label':tc.get('id'),'kind':kind,'failure':tc.find('failure') is not None,'skipped':tc.find('skipped') is not None})
            expected={p['formalmc_label'] for p in job['properties'] if p['kind']==('assert' if job['mode']=='prove' else 'cover')}
            actual={p['label'] for p in found if not p['failure'] and not p['skipped']}
            ok=matched and original_row['exit_code']==0 and status=='PASS' and expected<=actual
            row={'job_id':jid,'current_source_matches':matched,'model_sha256':sha(model),'receipt':str(receipt_path),'receipt_sha256':sha(receipt_path),
                 'run_directory':str(runroot),'backend_status_raw':raw,'returncode':original_row['exit_code'],
                 'properties':found,'expected_properties':sorted(expected),'missing':sorted(expected-actual),
                 'xml_sha256':sha(xml) if xml.is_file() else None,'passed':ok,
                 'original_collection_status':original_row['status'],'collection_note':'XML file follows config stem validate.xml; type case normalized. Original solver artifacts and earlier receipt are unmodified.'}
            row['cancellations']=[r for r in cancellations if str(runroot).endswith('/'+r['run'])]
            observations.append(row)
            if matched:
                # An inconclusive/cancelled retry cannot invalidate an existing
                # proof of byte-identical inputs. A real falsification is never
                # discarded and must instead make the aggregate fail.
                previous=selected.get(jid)
                if previous is None or ok or (status=='FAIL') or not previous['passed']:
                    selected[jid]=row
    falsified=[r for r in observations if r['current_source_matches'] and r['backend_status_raw'].split()[0]=='FAIL']
    report={'schema_version':1,'suite':'generated_formalmc_models_cross_checked_with_SBY','formalmc_executed':False,
            'manifest_sha256':sha(PKG/'manifest.json'),'jobs_expected':len(byid),'jobs_observed':len(selected),
            'jobs_passed':sum(r['passed'] for r in selected.values()),'all_passed':not falsified and len(selected)==len(byid) and all(r['passed'] for r in selected.values()),
            'falsified_runs':falsified,'cancellations':cancellations,'selected_runs':[selected[k] for k in sorted(selected)],'observations':observations}
    path=ROOT/'normalized_validation/summary.json';path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('selected_runs','observations')}))
if __name__=='__main__':main()
