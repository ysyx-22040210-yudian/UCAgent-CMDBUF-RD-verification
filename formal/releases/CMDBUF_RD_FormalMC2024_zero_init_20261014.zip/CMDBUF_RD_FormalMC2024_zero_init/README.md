# CMDBUF RD FormalMC 2024 零初值候选包

[PDF 补充说明](documents/FormalMC2024零初值适配补充说明.pdf) / [Word 编辑版](documents/FormalMC2024零初值适配补充说明.docx)。

本次记录见 verification_20261014/；真实 FormalMC 2024 尚未执行。
